# Primož – evidenca vozil + administracija

Projekt ima tri dele:

| Mapa | Kaj je |
|---|---|
| `primoz-app/` | **Primož app** – aplikacija za uporabnike (vozila, servisi, opomniki, skener šasije/tablic). Podrobnosti: `primoz-app/NAVODILA.md` |
| `primoz-admin/` | **Primož Admin** – tvoja aplikacija: računi, naprave, zaklepanje, sporočila, varnostna opozorila |
| `supabase/` | Strežnik (baza + pravila). Poženeš enkrat v Supabase |

---

## 1. Kako deluje

**Primož app (uporabniki)**
* Registracije ni. Račune ustvarjaš samo ti v Primož Admin.
* Prijava (e-pošta + geslo) zahteva internet. Potem uporabnik **ostane prijavljen za vedno**, dokler ga ne onemogočiš ali odjaviš.
* Ob vsakem odprtju in vsakih 5 minut (ko je internet) aplikacija preveri račun. Zaklep, onemogočenje ali prepoved naprave začnejo veljati takoj ob naslednjem preverjanju.
* Brez interneta deluje največ **30 dni** od zadnje potrditve (nastavljivo). Nato le enkrat potrebuje internet – ponovna prijava ni potrebna.
* Ob odprtju se pokaže tvoje **sporočilo čez večino zaslona** z gumbi, ki jih izbereš ti (Potrdi, Zavrni, V redu, Kasneje, Odpri povezavo, lasten gumb …). Zapre se samo z gumbom; gumb Nazaj ga ne zapre.

**Primož Admin (ti)**
* **Opozorila** – poskusi vdora v živo, z napravo, IP-jem in strojnim ID-jem napadalca. En dotik: *Prepovej to napravo* ali *Onemogoči račun*. Obvestilo na telefon tudi, ko je aplikacija zaprta (preverjanje vsakih ~15 min).
* **Računi** – ustvari (s samodejnim močnim geslom in gumbom *Kopiraj podatke za prijavo*), uredi, onemogoči z razlogom, novo geslo, izbriši. Pri vsakem računu vidiš **vse naprave**: model, Android, različico aplikacije, prvo/zadnjo uporabo, IP, root/emulator.
* **Naprave** – preimenuj, odjavi na daljavo, **prepovej** (tudi po ponovni namestitvi), **izbriši podatke na napravi** (izgubljen/ukraden telefon), odstrani.
* **Sporočila** – naslov, besedilo, vrsta (obvestilo/opozorilo/pomembno), do 4 gumbi, prejemniki (vsi ali izbrani računi), »pokaži ob vsakem odprtju«, »velja do«, predogled. Vidiš, **kdo je kliknil kaj in kdaj**, lahko ga pošlješ znova, ustaviš ali izbrišeš.
* **Nastavitve** – zakleni aplikacijo za vse (s sporočilom), dni brez interneta, »samo uradna aplikacija«, seznam prepovedanih naprav in uvoz kataloga vozil iz Excela.

Dodajanje, urejanje in brisanje delujejo enako kot v Primož app: **+** za dodajanje, vrstico povlečeš v levo za *Uredi / Izbriši*, na podrobnostih ✏️ in 🗑.

---

## 2. Zaščita pred vdorom

| Napad | Zaščita |
|---|---|
| Ugibanje gesla | Po 5 napačnih geslih je račun zaklenjen 15 min (tudi za pravilno geslo); po 20 napačnih poskusih z enega omrežja je omrežje zaklenjeno 15 min. Od 3. napačnega gesla dobiš opozorilo. |
| Ugibanje, kateri računi obstajajo | Enak odgovor in enak čas za neobstoječ račun in napačno geslo. |
| Deljeno ali ukradeno geslo | Opozorilo »Prijava z nove naprave«. Napravo prepoveš z enim dotikom. Neobvezno: največ N naprav na račun. |
| Kraja seje / prestrezanje prometa | Ob prijavi telefon ustvari 256-bitni ključ, shranjen kot **neizvozljiv** (JavaScript ga ne more prebrati). Vsak zahtevek je podpisan (HMAC-SHA256) in ima števec. Ponovljen ali ponarejen zahtevek se zavrne, ti pa dobiš opozorilo. Samo HTTPS; uporabniško nameščeni certifikati za prestrezanje niso zaupani. |
| Napadalec po prepovedi znova namesti aplikacijo | Prepoved velja za strojni ID naprave (ostane enak po ponovni namestitvi) – za vse račune. |
| Predelan APK | Aplikacija pošlje SHA-256 podpisa APK. Z vklopljeno »Samo uradna aplikacija« se predelane različice zaklenejo. Zaznava tudi root, emulator in razhroščevanje (opozorilo). |
| Dostop do baze mimo aplikacije | Tabele so zaprte (RLS, brez pravic). Dostopne so samo funkcije, ki preverjajo podpis oziroma admina. Gesla so shranjena kot bcrypt. |
| Prevzem admina | Geslo + **obvezna 2FA koda** (Google/Microsoft Authenticator) + **PIN** ob vsakem odprtju. Po 5 napačnih PIN-ih sledi odjava. Brez posnetkov zaslona (FLAG_SECURE). Admin funkcije brez 2FA ne delujejo – to preveri baza, ne aplikacija. |
| Kopiranje telefona / varnostna kopija | Izklopljeno: seja in ključ se ne preneseta na drug telefon. |
| Prestavljena ura (izogibanje 30-dnevnemu roku) | Zaznano, potrebna je povezava, ti dobiš opozorilo. |

**Pošteno o mejah:**
* Nobena aplikacija ni 100-odstotno neprebojna. Podatki o vozilih so shranjeni na telefonu. Kdor ima root dostop do odklenjenega telefona, jih lahko prebere. Zaklep na daljavo začne veljati, ko se telefon poveže z internetom (zato velja rok 30 dni).
* Strojni ID lahko spremeni le ponastavitev telefona na tovarniške nastavitve. Takrat napadalec spet potrebuje pravilno geslo in ti dobiš opozorilo o novi napravi.

**Preverjeno s testi:** 80 testov strežnika (napadi in pravila), 33 testov Primož app in 41 testov Primož Admin, vsi uspešni. Preizkušeni so bili tudi vsi obstoječi testi evidence vozil.

---

## 3. Enkratna nastavitev strežnika (≈ 10 minut)

### 3.1 Supabase projekt
1. Na **supabase.com** → *New project* → ime `primoz-app`, regija **Central EU (Frankfurt)**, geslo baze: *Generate a password*, plan **Free**.
2. Ko je projekt pripravljen: **SQL Editor** → *New query* → prilepi celotno vsebino `supabase/1-schema.sql` → **Run**. Uspeh: »Success. No rows returned«.
   Nato na enak način poženi še `supabase/4-katalog-posodobitve.sql`. Pri že delujočem projektu poženi samo to četrto skripto.
3. **Project Settings → API**: kopiraj **Project URL** in ključ **anon / publishable**. Vpiši ju v obe datoteki:
   * `primoz-app/.env.production`
   * `primoz-admin/.env.production`
   ```
   VITE_SUPABASE_URL=https://xxxxxxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJ… ali sb_publishable_…
   ```
   (Ključ je namenoma javen. Ključa **service_role / secret** nikoli ne vpisuj v aplikacijo.)

### 3.2 Admin račun
1. Zgradi in namesti **Primož Admin** (poglavje 4).
2. V aplikaciji tapni **»Prva nastavitev? Ustvari admin račun«**, vpiši svojo e-pošto in geslo (vsaj 10 znakov).
3. Potrdi račun s povezavo v e-sporočilu od Supabase.
4. Supabase → SQL Editor → poženi `supabase/2-admin.sql` (če nisi uporabil primozsvetelj@gmail.com, v datoteki zamenjaj e-pošto).
5. V Primož Admin se prijavi. Aplikacija zahteva **2FA**: tapni *Odpri aplikacijo za avtentikacijo* (ali skeniraj QR / vpiši ključ), vpiši 6-mestno kodo, nato nastavi **PIN**.
6. Supabase → **Authentication → Sign In / Providers → Email** → izklopi **Allow new users to sign up**. S tem nihče več ne more ustvariti admin računa. Vsak tak račun je sicer brez pravic, ker ni v tabeli administratorjev.

> **Shrani rezervno kodo 2FA:** ključ, ki ga vidiš ob nastavitvi 2FA, si zapiši na varno. Če izgubiš telefon z aplikacijo za avtentikacijo, faktor izbrišeš v Supabase → Authentication → Users → tvoj uporabnik → MFA.

### 3.3 Zaščita podpisa (ko imajo vsi uradni APK)
V Primož Admin → Nastavitve vklopi **Samo uradna aplikacija** (ali poženi `supabase/3-zascita-podpisa.sql`).

### 3.4 Da se brezplačen strežnik ne ustavi
Brezplačen Supabase projekt se ustavi po 7 dneh brez prometa. Ker aplikacije preverjajo račun ob vsakem odprtju, se to v praksi ne zgodi. Za vsak primer je zraven GitHub opravilo **Supabase keep-alive**, ki strežnik pokliče enkrat na dan.

### 3.5 Uvoz kataloga vozil
1. V **Primož Admin → Nastavitve → Katalog vozil** izberi datoteko `.xlsx`.
2. Datoteka mora imeti list `Specifikacije` in stolpca `Znamka` ter `Model`. Podprti so tudi vsi tehnični stolpci iz priloženega kataloga.
3. Aplikacija najprej naloži vse dele v začasno območje in šele nato z eno varno operacijo zamenja katalog. Če se prenos prekine, obstoječi katalog ostane nespremenjen.
4. Status preverjenosti in opozorila iz Excela se ohranijo in so vidni pri izbranem vozilu.

---

## 4. Gradnja APK (obe aplikaciji naenkrat)

### GitHub Actions (priporočeno)
1. Na github.com ustvari **zasebni** repozitorij in vanj naloži vsebino te mape (brez `node_modules`).
2. Zavihek **Actions** → »Build Android APK« → **Run workflow**.
3. Po ~8 minutah prenesi artefakta **primoz-app-apk** in **primoz-admin-apk**.

Opravilo izdela tudi `primoz-app-update` in `primoz-admin-update`. To sta paketa spletnega dela aplikacij za prihodnje samodejne posodobitve.

Naslov in ključ Supabase lahko namesto v `.env.production` vpišeš v GitHub → Settings → Secrets and variables → Actions → **Variables**: `SUPABASE_URL` in `SUPABASE_ANON_KEY`.

### Android Studio
```bash
cd primoz-app   # ali primoz-admin
npm install
npm run build
npx cap sync android
npx cap open android
```

Obe aplikaciji sta podpisani z istim ključem `android/primoz-release.jks`:
```
SHA-256: 53:CE:2D:C9:EC:AE:F0:5B:23:68:1B:D8:89:7B:CC:60:AF:10:6F:7E:89:B3:52:60:C0:F7:D3:61:E9:9A:DE:6C
Paketa:  si.onebase.primoz (uporabniki), si.onebase.primoz.admin (admin)
```
Ključa ne izgubi. Repozitorij naj bo zaseben.

### Posodobitve brez ponovne namestitve
Različici 1.2.0 (Primož app) in 1.1.0 (Primož Admin) prvič vključita varen nalagalnik posodobitev. Zato moraš **ti dve različici še enkrat namestiti kot običajna APK-ja**. Nato lahko prihodnje spremembe spletnega dela pridejo samodejno:
1. paket `*-update.zip` naloži v javno dostopen HTTPS naslov (na primer v javni Supabase Storage bucket),
2. njegov SHA-256 in URL vpiši v tabelo `app_updates`,
3. aplikacija paket prenese v ozadju, ga uporabi ob naslednjem zagonu in se ob napaki samodejno vrne na vgrajeno različico.

Spremembe nativnih Android dovoljenj ali dodatkov še vedno zahtevajo nov APK. V tabelo ne vpisuj paketa, dokler oba APK-ja nove osnovne različice nista uspešno preizkušena.

---

## 5. Pogosta vprašanja
* **Uporabnik je pozabil geslo** → Admin → Računi → račun → *Novo geslo* → *Kopiraj* in mu ga pošlji (vklopljeno »ob prijavi naj ga spremeni«).
* **Telefon je izgubljen** → račun → naprava → *Izbriši podatke na napravi* (zgodi se ob naslednji povezavi), nato *Prepovej napravo*.
* **Nekdo poskuša vdreti** → dobiš obvestilo → Opozorila → dogodek → *Prepovej to napravo*. Če je imel pravilno geslo: *Novo geslo* z vklopljenim »Odjavi vse naprave«.
* **Vzdrževanje** → Nastavitve → Zaklep aplikacije → sporočilo → *Zakleni za vse*.
* **Admin je izgubil telefon** → na novem telefonu namesti Primož Admin, prijava + 2FA (rezervni ključ) + nov PIN. Stari telefon brez PIN-a ne odpre aplikacije.
