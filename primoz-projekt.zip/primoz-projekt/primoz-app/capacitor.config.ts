import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'si.onebase.primoz',
  appName: 'Primož app',
  webDir: 'dist',
  backgroundColor: '#0B0B10',
  android: {
    backgroundColor: '#0B0B10',
    // razhroščevanje WebView (chrome://inspect) izklopljeno tudi v debug buildih
    webContentsDebuggingEnabled: false,
    allowMixedContent: false,
  },
  plugins: {
    SystemBars: {
      insetsHandling: 'css',
      initialViewportFitValueHint: 'cover',
      style: 'DARK',
    },
    SplashScreen: {
      launchShowDuration: 600,
      backgroundColor: '#0B0B10',
      showSpinner: false,
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_notify',
      iconColor: '#8154FF',
    },
    Keyboard: {
      resize: 'native',
    },
    SocialLogin: {
      providers: { google: true, facebook: false, apple: false, twitter: false },
    },
  },
};

export default config;
