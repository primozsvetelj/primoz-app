import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// Spletni predogled (en sam HTML) – samo za preizkus v brskalniku
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  base: './',
  resolve: { alias: { 'onnxruntime-web/wasm': '/home/claude/primoz-app/tools/ort-stub.ts' } },
  build: { outDir: '/home/claude/scratch/preview', emptyOutDir: true, assetsInlineLimit: 100000000, chunkSizeWarningLimit: 5000 },
});
