package si.onebase.primoz;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Widgets")
public class WidgetsPlugin extends Plugin {
    @PluginMethod
    public void refresh(PluginCall call) {
        TodayRemindersWidget.updateAll(getContext());
        call.resolve(new JSObject());
    }
}
