package si.onebase.primoz;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

public class AddVehicleWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_action);
            views.setTextViewText(R.id.widget_action_title, "Dodaj vozilo");
            views.setTextViewText(R.id.widget_action_hint, "Hitro odpri obrazec za novo vozilo");
            views.setOnClickPendingIntent(R.id.widget_action_root, WidgetUtils.open(context, "add-vehicle", 300));
            manager.updateAppWidget(id, views);
        }
    }
}
