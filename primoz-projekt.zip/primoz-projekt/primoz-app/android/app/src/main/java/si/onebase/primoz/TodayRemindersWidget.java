package si.onebase.primoz;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONArray;

public class TodayRemindersWidget extends AppWidgetProvider {
    static void update(Context context, AppWidgetManager manager, int id) {
        SharedPreferences prefs = context.getSharedPreferences("CapacitorStorage", Context.MODE_PRIVATE);
        String raw = prefs.getString("widget_today", "[]");
        StringBuilder text = new StringBuilder();
        try {
            JSONArray rows = new JSONArray(raw);
            for (int i = 0; i < Math.min(rows.length(), 4); i++) {
                if (i > 0) text.append("\n");
                text.append(rows.optString(i));
            }
        } catch (Exception ignored) {}
        if (text.length() == 0) text.append("Danes ni opomnikov");
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_today);
        views.setTextViewText(R.id.widget_today_list, text.toString());
        views.setOnClickPendingIntent(R.id.widget_today_root, WidgetUtils.open(context, "today", 100));
        views.setOnClickPendingIntent(R.id.widget_add_service, WidgetUtils.open(context, "add-service", 101));
        manager.updateAppWidget(id, views);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, TodayRemindersWidget.class));
        for (int id : ids) update(context, manager, id);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }
}
