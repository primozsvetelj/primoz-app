package si.onebase.primoz;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Debug;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.security.MessageDigest;

/**
 * Podatki o celovitosti aplikacije za strežnik:
 * SHA-256 podpisnega certifikata APK (predelan APK ima drug podpis),
 * razhroščevanje, root in emulator.
 */
@CapacitorPlugin(name = "Integrity")
public class IntegrityPlugin extends Plugin {

    @PluginMethod
    public void getInfo(PluginCall call) {
        Context ctx = getContext();
        JSObject r = new JSObject();
        r.put("cert", certSha256(ctx));
        r.put("debuggable", (ctx.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0 || Debug.isDebuggerConnected());
        r.put("rooted", isRooted());
        r.put("emulator", isEmulator());
        r.put("installer", installer(ctx));
        call.resolve(r);
    }

    @SuppressWarnings("deprecation")
    static String certSha256(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = pi.signingInfo.hasMultipleSigners() ? pi.signingInfo.getApkContentsSigners() : pi.signingInfo.getSigningCertificateHistory();
            } else {
                sigs = pm.getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNATURES).signatures;
            }
            if (sigs == null || sigs.length == 0) return "";
            byte[] d = MessageDigest.getInstance("SHA-256").digest(sigs[sigs.length - 1].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static boolean isRooted() {
        if (Build.TAGS != null && Build.TAGS.contains("test-keys")) return true;
        String[] paths = {"/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su", "/vendor/bin/su", "/su/bin/su",
            "/data/local/su", "/data/local/bin/su", "/data/local/xbin/su", "/system/app/Superuser.apk", "/system/bin/.ext/su",
            "/data/adb/magisk", "/sbin/.magisk", "/system/xbin/daemonsu"};
        for (String p : paths) if (new File(p).exists()) return true;
        return false;
    }

    static boolean isEmulator() {
        String fp = Build.FINGERPRINT == null ? "" : Build.FINGERPRINT;
        String model = Build.MODEL == null ? "" : Build.MODEL;
        String hw = Build.HARDWARE == null ? "" : Build.HARDWARE;
        String product = Build.PRODUCT == null ? "" : Build.PRODUCT;
        return fp.startsWith("generic") || fp.contains("emulator") || fp.contains("unknown")
            || model.contains("google_sdk") || model.contains("Emulator") || model.contains("Android SDK built for")
            || hw.contains("goldfish") || hw.contains("ranchu") || product.contains("sdk_gphone") || product.equals("sdk")
            || Build.MANUFACTURER.contains("Genymotion");
    }

    @SuppressWarnings("deprecation")
    static String installer(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                String s = ctx.getPackageManager().getInstallSourceInfo(ctx.getPackageName()).getInstallingPackageName();
                return s == null ? "" : s;
            }
            String s = ctx.getPackageManager().getInstallerPackageName(ctx.getPackageName());
            return s == null ? "" : s;
        } catch (Exception e) {
            return "";
        }
    }
}
