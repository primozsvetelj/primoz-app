// Spletni predogled: brez ONNX runtime (prevelik za en HTML). Skener na telefonu deluje normalno.
const unavailable = () => { throw new Error('skeniranje ni na voljo v spletnem predogledu – deluje v Android aplikaciji'); };
export const env = { wasm: {} as Record<string, unknown> };
export class Tensor { constructor() { unavailable(); } }
export const InferenceSession = { create: async () => unavailable() };
export default { env, Tensor, InferenceSession };
