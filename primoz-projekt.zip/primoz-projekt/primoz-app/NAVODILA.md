# Primož app – evidenca vozil (Android)

Aplikacija je narejena po Figma datoteki »Primož App — Evidenca vozil (UI Design)«: temna tema, Roboto, barvne spremenljivke »Barve« in tekstovni slogi so prevzeti 1 : 1 (`src/theme.css`).

**Tehnologija:** React + TypeScript (vmesnik) v Capacitor 8 (prava Android aplikacija, APK). Podatki so shranjeni lokalno na telefonu (IndexedDB/Dexie) in delujejo brez interneta.

---

## 1. Prijava in APK
* **Prijava**: račun ti ustvari administrator v aplikaciji Primož Admin. Registracije ni. Prijava zahteva internet, nato ostaneš prijavljen. Vse o računih, zaklepanju, sporočilih in zaščiti je v `../NAVODILA.md`.
* **APK**: navodila za gradnjo obeh aplikacij so v `../NAVODILA.md` (poglavje 4).

---

## 2. Izvoz podatkov

### Na računalnik – Nastavitve → Izvoz podatkov
| Format | Kaj dobiš |
|---|---|
| CSV | 4 datoteke (vozila, servisi, opomniki, tekočine), ločilo `;`, UTF-8 – Excel jih odpre pravilno |
| Excel | En `.xlsx` z zavihki |
| PDF | Pregledno poročilo (s šumniki) |
| JSON kopija | Popolna kopija – lahko jo uvoziš nazaj (Varnostna kopija → Uvozi iz datoteke) |

Obdobje: zadnji mesec / letos / vse. Datoteke se shranijo v **Dokumenti/PrimozApp** na telefonu (vidno prek USB kabla na računalniku), z gumbom **Deli** pa jih pošlješ kamorkoli (e-pošta, Quick Share, Drive, OneDrive …).

### V oblak – Nastavitve → Varnostna kopija (Google Drive, inkrementalno)
* Vsak zapis ima čas zadnje spremembe; izbrisi se hranijo kot »tombstone«.
* **Ustvari kopijo zdaj** naloži **samo zapise, ki so bili dodani, spremenjeni ali izbrisani po zadnji uspešni kopiji** – kot datoteko `delta-<datum-čas>.json` v mapo *Primož App* na tvojem Google Drive. Če ni sprememb, se nič ne naloži.
* Zaslon prikazuje, koliko sprememb čaka na nalaganje.
* **Obnovi iz kopije** prebere vse delte po vrsti in jih združi (novejša sprememba obvelja) – deluje tudi na novem telefonu.
* **Samodejna kopija**: enkrat dnevno ob odprtju aplikacije (brez pojavnih oken).
* Aplikacija ima dostop samo do datotek, ki jih je ustvarila sama (scope `drive.file`).

#### Google Drive je že nastavljen
* Google račun: **primozsvetelj@gmail.com**, Google Cloud projekt »My Project 816« (ID `rosy-rider-512612-m7`).
* Google Drive API je vklopljen, zaslon za soglasje »Primoz app« (način Testing), testni uporabnik primozsvetelj@gmail.com.
* OAuth Android client: paket `si.onebase.primoz`, SHA-1 zgoraj.
* OAuth Web client ID (že vpisan v `src/lib/sync.ts` in `.env`): `835365871524-i24iqiqj36175ag1pcieukp2ecakq4h8.apps.googleusercontent.com`
* Za dodatne Google račune jih dodaj v Google Cloud → Google Auth Platform → Audience → Test users (do 100 uporabnikov). Ker je aplikacija v načinu Testing, Google ob prijavi pokaže opozorilo »Google tega ni preveril« → klikni Nadaljuj.
* Če kdaj zamenjaš podpisni ključ, v Android clientu posodobi SHA-1.

Dokler Client ID ni vpisan, aplikacija na zaslonu Varnostna kopija to jasno pove, izvoz na računalnik in JSON kopija pa delujeta.

---

## 3. Kaj aplikacija zna
* **Enotno dodajanje, urejanje in brisanje** – povsod enak vzorec:
  * **Dodaj**: gumb **+** (v glavi seznama) oz. »Dodaj …« na kartici.
  * **Uredi / Izbriši v seznamu**: vrstico **povleci v levo** → *Uredi* (vijolično) / *Izbriši* (rdeče). Velja za vozila, servise in opomnike (Domov, Koledar, podrobnosti vozila), olja in tekočine ter lastne vrste servisov/tekočin.
  * **Na zaslonu podrobnosti**: v glavi ✏️ (uredi) in rdeč 🗑 (izbriši) – vozilo, servis, opomnik. Spodnji gumb je samo glavno dejanje (Ponovi / Opravljeno).
  * **V obrazcu za urejanje**: rdeč 🗑 v glavi; po brisanju se zapre obrazec in tudi podrobnosti izbrisanega zapisa.
  * Vsako brisanje: potrditveno okno → obvestilo **»Razveljavi«** (5 s).
  * Izjema: **Lastna polja** – vrstico tapneš → list z *Izbriši* / *Shrani* (ker vrstice premikaš z vlečenjem ⋮⋮, poteg v levo tu ni primeren).
* **Skeniranje šasije (VIN) in registrske** – v obrazcu vozila ikona ⌗ ob polju:
  * Kamera s polnim zaslonom, okvir za poravnavo, svetilka, zajem ali fotografija iz galerije.
  * Prepoznava teče **na telefonu brez interneta** (PP-OCRv4 model + pravila za VIN in slovenske tablice).
  * VIN: 17 znakov brez I/O/Q, preverjanje kontrolne številke, popravek zamenljivih znakov (O→0, I→1 …), preverjanje proizvajalca (WMI) in zadnjih 4 števk.
  * Tablica: območja CE GO KK KP KR LJ MB MS NM PO SG, samodejno oblikovanje (npr. »LJ MI-788«), tudi osebne tablice.
  * Rezultat se pred uporabo pokaže v urejevalnem polju (z oznako zanesljivosti in drugimi možnostmi) – vedno preveri.
* **Vozila**: dodaj/uredi/izbriši (z razveljavitvijo), iskanje po imenu ali registraciji, preverjanje VIN (17 znakov), letnika in podvojenih registracij, kopiranje posameznega podatka ali vseh naenkrat.
* **Olja in tekočine**: knjižnica vrst + lastne vrste (»Uredi moje vrste« → preimenuj/izbriši), poteg vrstice v levo → Uredi/Izbriši, vir »Iz baze« / »Moje«.
* **Izbira vozila z iskanjem** (Nov servis, Nov opomnik, Nova tekočina): v polje Vozilo vpišeš črke in takoj dobiš zadetke po imenu in priimku, registraciji, znamki/modelu ali vrsti vozila (npr. »kombi«, »ce ft«, »novak«); Enter izbere prvi zadetek.
* **Servisi**: vrste servisa (knjižnica + nove, »Uredi moje vrste« → preimenuj/izbriši), barva (Dolg/Hitri servis), datum v koledarju → spodnji list za uro, ponovi servis.
* **Opomniki**: ponovitev (enkrat/mesečno/letno), opomni me (na dan, 1 dan prej, 7 dni prej) → **sistemska Android obvestila**; »Opravljeno« premakne ponavljajoči opomnik na naslednji termin.
* **Koledar**: pike pod dnevi z dogodki, filtri Vse/Servisi/Opomniki, seznam dogodkov izbranega dne.
* **Domov**: prihajajoči opomniki in servisi. **Kreiraj**: hitre akcije + nedavno uporabljeno (Ponovi).
* **Lastna polja** (dostop iz podrobnosti vozila → Dodaj svoje polje in iz Kreiraj; v Nastavitvah jih ni več, kot v Figmi): besedilo/številka/datum, vklop/izklop vidnosti, razvrščanje z vlečenjem, vrednost za vsako vozilo.
* **Globalno iskanje** (vozila, servisi, opomniki) s filtri.
* **Račun**: prijava s strežniškim računom (ustvari ga admin). Nastavitve → Spremeni geslo; ime in e-pošto ureja admin, sliko in telefon nastaviš sam. Če admin račun onemogoči, napravo prepove ali zaklene aplikacijo, se prikaže zaklenjen zaslon; ob ponovni omogočitvi se aplikacija sama odklene. Sporočila admina se prikažejo ob odprtju.
* Android: sistemski gumb Nazaj (zapre list/dialog, gre nazaj, na korenu zapre app), vsak zavihek ohrani svoj sklad zaslonov, rob-do-roba prikaz s pravilnimi odmiki, ikona in zagonski zaslon, vibracija ob dotiku, samo pokončna orientacija.

## 4. Rezultati testiranja

**Skener (OCR), slike s spleta (Wikimedia Commons / Openverse):**
| Test | Rezultat |
|---|---|
| Šasije (VIN) – 37 različnih fotografij (več ni bilo prosto dostopnih) | **31/37 popolnoma pravilno**, 95,7 % pravilnih znakov |
| Registrske – 70 izrezov tablic | **70/70** |
| Registrske – 70 popačenih (zamegljeno, temno, zasukano, šum) | **70/70** |
| Kamera v aplikaciji (simulirana kamera, VIN + tablica) | pravilno vpisano v obrazec |

6 neuspelih VIN fotografij je fizično težkih: odsev, delno odrezana številka, slika 150 px, vtisnjene številke v kovini, dvoumni D/0, C/6, S/8. V takem primeru aplikacija pokaže opozorilo »Nizka zanesljivost« ali »kontrolne številke ni mogoče potrditi« in znak popraviš ročno. Nasvet: približaj telefon, da številka zapolni okvir, vklopi svetilko pri vtisnjenih številkah.

**Aplikacija (avtomatski testi v brskalniku):** registracija/admin, vozila, tekočine, servisi, opomniki, koledar, iskanje, izvoz CSV/Excel/PDF/JSON, inkrementalna kopija (samo spremembe) in obnova na drugi napravi, 29 preverjanj dodaj/uredi/izbriši/razveljavi – vse uspešno, brez napak v konzoli.

## 5. Odstopanja od Figme (namerna)
* V podrobnostih vozila je dodana kartica **Servisi in opomniki** (v dizajnu ni bilo seznama servisov vozila).
* Ikona v glavi podrobnosti vozila je **koš** (po specifikaciji), ne »+«.
* Dodana: prazna stanja, obvestila »Kopirano« / »Izbrisano – Razveljavi«, potrditve brisanja tekočine/servisa/opomnika, zaslon uspeha izvoza, registracija in »Pozabljeno geslo« (lokalno), vrstica »Čaka na nalaganje« in povezava z Google računom na zaslonu Varnostna kopija, format »JSON kopija«.
* Strošek/Tankanje je izpuščen (po specifikaciji ni več v Kreiraj).
* Samodejna kopija teče ob odprtju aplikacije (ne ob 3:00 ponoči – za to bi bil potreben nativni WorkManager).
* Gumba ⋮ in svinčnik na zaslonu Lastna polja sta nadomeščena z dotikom vrstice (urejanje vrednosti, imena, tipa, brisanje).
* Podrobnosti servisa/opomnika: gumb »Izbriši« je iz noge premaknjen v glavo (🗑), enako kot pri vozilu.
* Ob poljih Registrska in Šasija je ikona za skeniranje.

## 6. Struktura
```
src/lib/db.ts            podatkovni model + žigi sprememb (updatedAt, deleted)
src/lib/sync.ts          Google Drive inkrementalna kopija / obnova
src/lib/account.ts       strežniški račun, podpisani zahtevki, zaklep, sporočila
src/screens/Gate.tsx     zaklenjen zaslon, sporočilo admina, menjava gesla
src/lib/exporter.ts      CSV / Excel / PDF / JSON
src/lib/notifications.ts lokalna obvestila za opomnike
src/lib/ocr.ts           prepoznava VIN / tablic (na napravi)
src/ui/Scanner.tsx       zaslon kamere za skeniranje
src/ui/actions.tsx       enotno brisanje (potrditev + razveljavi)
public/ocr, public/ort   OCR model in runtime
src/screens/*            zasloni (po Figma flowih)
src/ui/*                 komponente (gumbi, polja, koledar, listi, navigacija)
android/                 Android projekt (Capacitor)
```
