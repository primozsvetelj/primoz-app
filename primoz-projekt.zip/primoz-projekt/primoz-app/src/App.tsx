import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { App as CapApp } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { Home, Car, Plus, CalendarDays, Settings as Cog } from 'lucide-react';
import { NavProvider, useNav, routeHasNav, type Route, type TabId } from './ui/nav';
import { ConfirmHost, ToastHost } from './ui/components';
import { ensureSeed } from './lib/db';
import { isNative, tap } from './lib/native';
import { rescheduleAll } from './lib/notifications';
import { autoBackupIfDue } from './lib/sync';
import { HomeScreen } from './screens/Home';
import { VehiclesScreen } from './screens/Vehicles';
import { VehicleDetailScreen } from './screens/VehicleDetail';
import { VehicleFormScreen } from './screens/VehicleForm';
import { FluidFormScreen } from './screens/FluidForm';
import { ServiceFormScreen } from './screens/ServiceForm';
import { ReminderFormScreen } from './screens/ReminderForm';
import { ServiceDetailScreen, ReminderDetailScreen } from './screens/EventDetail';
import { CalendarScreen } from './screens/Calendar';
import { CreateScreen } from './screens/Create';
import { SearchScreen } from './screens/Search';
import { FieldsScreen } from './screens/Fields';
import { SettingsScreen, ProfileScreen, ExportScreen, BackupScreen, PasswordScreen } from './screens/Settings';
import { LoginScreen } from './screens/Login';
import { CustomerFormScreen, CustomersScreen } from './screens/Customers';
import { LockScreen, MessageOverlay, ChangePasswordForm } from './screens/Gate';
import { check, getSession, latestUpdate, logout, type Session } from './lib/account';
import { markUpdateReady, prepareUpdate } from './lib/updater';

const TABS: { id: TabId; label: string; icon: ReactNode }[] = [
  { id: 'domov', label: 'Domov', icon: <Home size={22} /> },
  { id: 'vozila', label: 'Vozila', icon: <Car size={22} /> },
  { id: 'kreiraj', label: 'Kreiraj', icon: <Plus size={24} /> },
  { id: 'koledar', label: 'Koledar', icon: <CalendarDays size={22} /> },
  { id: 'nastavitve', label: 'Nastavitve', icon: <Cog size={22} /> },
];

function renderRoute(r: Route) {
  switch (r.name) {
    case 'search': return <SearchScreen filter={r.filter} />;
    case 'vehicle': return <VehicleDetailScreen id={r.id} />;
    case 'vehicleForm': return <VehicleFormScreen id={r.id} />;
    case 'fields': return <FieldsScreen vehicleId={r.vehicleId} />;
    case 'fluidForm': return <FluidFormScreen vehicleId={r.vehicleId} id={r.id} copyFrom={r.copyFrom} />;
    case 'serviceForm': return <ServiceFormScreen vehicleId={r.vehicleId} id={r.id} copyFrom={r.copyFrom} date={r.date} />;
    case 'service': return <ServiceDetailScreen id={r.id} />;
    case 'reminderForm': return <ReminderFormScreen vehicleId={r.vehicleId} id={r.id} date={r.date} />;
    case 'reminder': return <ReminderDetailScreen id={r.id} occ={r.occ} />;
    case 'customerForm': return <CustomerFormScreen id={r.id} />;
    case 'customers': return <CustomersScreen />;
    case 'profile': return <ProfileScreen />;
    case 'password': return <PasswordScreen />;
    case 'export': return <ExportScreen />;
    case 'backup': return <BackupScreen />;
  }
}

function TabRoot({ tab, onLogout }: { tab: TabId; onLogout: () => void }) {
  if (tab === 'domov') return <HomeScreen />;
  if (tab === 'vozila') return <VehiclesScreen />;
  if (tab === 'kreiraj') return <CreateScreen />;
  if (tab === 'koledar') return <CalendarScreen />;
  return <SettingsScreen onLogout={onLogout} />;
}

function Shell({ onLogout }: { onLogout: () => void }) {
  const { tab, stacks, setTab, push, back } = useNav();

  useEffect(() => {
    if (!isNative) return;
    const open = (url?: string) => {
      if (!url?.startsWith('primozapp://')) return;
      const action = url.replace('primozapp://', '').split(/[/?#]/)[0];
      if (action === 'today') setTab('koledar');
      if (action === 'add-service') { setTab('kreiraj'); window.setTimeout(() => push({ name: 'serviceForm' }), 0); }
      if (action === 'search-vehicles') { setTab('vozila'); window.setTimeout(() => push({ name: 'search', filter: 'vehicles' }), 0); }
      if (action === 'add-vehicle') { setTab('vozila'); window.setTimeout(() => push({ name: 'vehicleForm' }), 0); }
    };
    CapApp.getLaunchUrl().then((value) => open(value?.url));
    const listener = CapApp.addListener('appUrlOpen', ({ url }) => open(url));
    return () => { listener.then((value) => value.remove()); };
  }, [push, setTab]);

  useEffect(() => {
    if (!isNative) return;
    const h = CapApp.addListener('backButton', () => {
      if (document.querySelector('.msg-overlay')) return; // sporočila admina se zapre samo z gumbom
      if (!back()) CapApp.minimizeApp();
    });
    return () => { h.then((x) => x.remove()); };
  }, [back]);

  const stack = stacks[tab];
  const top = stack[stack.length - 1];
  const showNav = !top || routeHasNav(top);

  return (
    <div className="app">
      {/* vsak zavihek ohrani svoj sklad zaslonov (stanje in pomik ostaneta) */}
      {TABS.map((t) => (
        <div key={t.id} style={{ display: t.id === tab ? 'contents' : 'none' }}>
          <div style={{ display: stacks[t.id].length ? 'none' : 'contents' }}><TabRoot tab={t.id} onLogout={onLogout} /></div>
          {stacks[t.id].map((r, i) => (
            <div key={i + r.name} style={{ display: i === stacks[t.id].length - 1 ? 'contents' : 'none' }}>{renderRoute(r)}</div>
          ))}
        </div>
      ))}
      {showNav && (
        <nav className="bottomnav">
          {TABS.map((t) => (
            <button key={t.id} className={`navitem ${tab === t.id ? 'active' : ''}`} onClick={() => { tap(); setTab(t.id); }}>
              <span className="pill">{t.icon}</span>
              {t.label}
            </button>
          ))}
        </nav>
      )}
      <ToastHost bottom={showNav ? 156 : 96} />
      <ConfirmHost />
    </div>
  );
}

const CHECK_EVERY = 5 * 60_000;

export default function App() {
  const [state, setState] = useState<'boot' | 'login' | 'app'>('boot');
  const [session, setSession] = useState<Session | null>(null);
  const [notice, setNotice] = useState('');
  const started = useRef(false);

  const signedOut = useCallback(async (reason: 'revoked' | 'invalid' | 'wiped') => {
    if (reason === 'wiped') await ensureSeed();
    setSession(null);
    setNotice(reason === 'revoked' ? 'Administrator te je odjavil s te naprave.' : reason === 'wiped' ? 'Administrator je izbrisal podatke na tej napravi.' : '');
    setState('login');
  }, []);

  /** preveri račun pri strežniku; ob odprtju/vrnitvi osveži tudi sporočila */
  const verify = useCallback(async (open: boolean) => {
    const r = await check({ refreshMessages: open });
    if (r.kind === 'signed_out') { if (r.reason !== 'invalid' || (await getSession()) === null) await signedOut(r.reason); return; }
    setSession(r.session);
  }, [signedOut]);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    (async () => {
      await markUpdateReady();
      await ensureSeed();
      const s = await getSession();
      if (s) { setSession(s); setState('app'); } else setState('login');
      if (isNative) SplashScreen.hide().catch(() => {});
      if (s) {
        await verify(true);
        prepareUpdate(latestUpdate);
        rescheduleAll();
        autoBackupIfDue();
      }
    })();
  }, [verify]);

  useEffect(() => {
    if (state !== 'app') return;
    const t = window.setInterval(() => verify(false), CHECK_EVERY);
    const online = () => verify(false);
    window.addEventListener('online', online);
    const h = isNative ? CapApp.addListener('resume', () => { verify(true); prepareUpdate(latestUpdate); rescheduleAll(); autoBackupIfDue(); }) : null;
    const vis = () => { if (!isNative && document.visibilityState === 'visible') verify(true); };
    document.addEventListener('visibilitychange', vis);
    return () => { clearInterval(t); window.removeEventListener('online', online); h?.then((x) => x.remove()); document.removeEventListener('visibilitychange', vis); };
  }, [state, verify]);

  const doLogout = async () => { await logout(); setSession(null); setNotice(''); setState('login'); };

  if (state === 'boot') return <div className="app" />;
  if (state === 'login' || !session) {
    return <div className="app"><LoginScreen notice={notice} onDone={(s) => { setSession(s); setNotice(''); setState('app'); rescheduleAll(); }} /></div>;
  }
  if (session.status !== 'ok') {
    return <div className="app"><LockScreen session={session} onRetry={() => verify(true)} onLogout={doLogout} /></div>;
  }
  if (session.account.must_change_pw) {
    return (
      <div className="app"><div className="screen fade-enter"><div className="scroll" style={{ paddingTop: 60 }}>
        <div className="h-big">Nastavi geslo</div>
        <ChangePasswordForm forced onDone={async () => setSession(await getSession())} />
      </div></div></div>
    );
  }
  return (
    <NavProvider initialTab="vozila">
      <Shell onLogout={doLogout} />
      <MessageOverlay messages={session.messages} onChange={async () => setSession(await getSession())} />
    </NavProvider>
  );
}
