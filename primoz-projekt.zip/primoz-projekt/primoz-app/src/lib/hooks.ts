import { useLiveQuery } from 'dexie-react-hooks';
import { db, alive, type Vehicle, type FieldDef, type FluidType, type ServiceType, type Service, type Reminder, type Fluid } from './db';

const byOwner = (a: Vehicle, b: Vehicle) => a.owner.localeCompare(b.owner, 'sl');

export function useVehicles(): Vehicle[] | undefined {
  return useLiveQuery(async () => (await db.vehicles.toArray()).filter(alive).sort(byOwner), []);
}
export function useVehicle(id?: string): Vehicle | null | undefined {
  return useLiveQuery(async () => (id ? (await db.vehicles.get(id)) ?? null : null), [id]);
}
export function useFieldDefs(): FieldDef[] | undefined {
  return useLiveQuery(async () => (await db.fieldDefs.toArray()).filter(alive).sort((a, b) => a.order - b.order), []);
}
export function useFluidTypes(): FluidType[] | undefined {
  return useLiveQuery(async () => (await db.fluidTypes.toArray()).filter(alive).sort((a, b) => b.builtin - a.builtin || a.createdAt - b.createdAt), []);
}
export function useServiceTypes(): ServiceType[] | undefined {
  return useLiveQuery(async () => (await db.serviceTypes.toArray()).filter(alive).sort((a, b) => b.builtin - a.builtin || a.createdAt - b.createdAt), []);
}
export function useServices(): Service[] | undefined {
  return useLiveQuery(async () => {
    const vids = new Set((await db.vehicles.toArray()).filter(alive).map((v) => v.id));
    return (await db.services.toArray()).filter((s) => alive(s) && vids.has(s.vehicleId));
  }, []);
}
export function useReminders(): Reminder[] | undefined {
  return useLiveQuery(async () => {
    const vids = new Set((await db.vehicles.toArray()).filter(alive).map((v) => v.id));
    return (await db.reminders.toArray()).filter((r) => alive(r) && vids.has(r.vehicleId));
  }, []);
}
export function useFluids(vehicleId?: string): Fluid[] | undefined {
  return useLiveQuery(async () => {
    const rows = vehicleId ? await db.fluids.where('vehicleId').equals(vehicleId).toArray() : await db.fluids.toArray();
    return rows.filter(alive).sort((a, b) => a.createdAt - b.createdAt);
  }, [vehicleId]);
}
export function useMeta<T>(key: string, def: T): T {
  const v = useLiveQuery(async () => (await db.meta.get(key))?.value as T | undefined, [key]);
  return v ?? def;
}
