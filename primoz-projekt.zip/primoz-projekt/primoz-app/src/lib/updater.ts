import { Capacitor } from '@capacitor/core';
import { CapacitorUpdater } from '@capgo/capacitor-updater';

export interface UpdateManifest {
  version: string;
  url: string;
  checksum?: string;
  notes?: string;
}

let running: Promise<string | null> | null = null;

function versionParts(version: string) {
  return version.split('.').map((part) => Number(part.match(/^\d+/)?.[0] ?? 0));
}

/** Pozitivno pomeni, da je a novejša od b. */
export function compareVersions(a: string, b: string) {
  const left = versionParts(a);
  const right = versionParts(b);
  for (let i = 0; i < Math.max(left.length, right.length); i += 1) {
    const diff = (left[i] ?? 0) - (right[i] ?? 0);
    if (diff) return diff;
  }
  return 0;
}

/**
 * Prenese preverjen spletni paket in ga pripravi za naslednji zagon.
 * Vgrajena različica ostane varna rezerva; neuspel paket se samodejno povrne.
 */
export function prepareUpdate(load: () => Promise<UpdateManifest | null>, installedVersion: string) {
  if (!Capacitor.isNativePlatform()) return Promise.resolve(null);
  if (running) return running;
  running = (async () => {
    await CapacitorUpdater.notifyAppReady().catch(() => undefined);
    const manifest = await load();
    if (!manifest?.version || !manifest.url) return null;
    const current = await CapacitorUpdater.current().catch(() => null);
    const activeVersion = current?.bundle?.version && current.bundle.version !== 'builtin' ? current.bundle.version : installedVersion;
    if (compareVersions(manifest.version, installedVersion) <= 0 || compareVersions(manifest.version, activeVersion) <= 0) return null;
    const bundle = await CapacitorUpdater.download({
      version: manifest.version,
      url: manifest.url,
      ...(manifest.checksum ? { checksum: manifest.checksum } : {}),
    });
    await CapacitorUpdater.next({ id: bundle.id });
    return manifest.version;
  })().catch(() => null).finally(() => { running = null; });
  return running;
}

export function markUpdateReady() {
  if (!Capacitor.isNativePlatform()) return Promise.resolve();
  return CapacitorUpdater.notifyAppReady().then(() => undefined).catch(() => undefined);
}
