import type { Reminder, RemindBefore } from './db';

export const MONTHS = ['januar', 'februar', 'marec', 'april', 'maj', 'junij', 'julij', 'avgust', 'september', 'oktober', 'november', 'december'];
export const MONTHS_CAP = MONTHS.map((m) => m[0].toUpperCase() + m.slice(1));
export const DOW_SHORT = ['PON', 'TOR', 'SRE', 'ČET', 'PET', 'SOB', 'NED'];
export const DOW_LONG = ['Nedelja', 'Ponedeljek', 'Torek', 'Sreda', 'Četrtek', 'Petek', 'Sobota'];

const pad = (n: number) => String(n).padStart(2, '0');

export function toISO(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export function parseISO(s: string) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}
export const todayISO = () => toISO(new Date());

/** 15. 11. */
export function fmtShort(iso: string) {
  const d = parseISO(iso);
  const y = d.getFullYear() !== new Date().getFullYear() ? ` ${d.getFullYear()}` : '';
  return `${d.getDate()}. ${d.getMonth() + 1}.${y}`;
}
/** 12. 10. 2026 */
export function fmtDate(iso: string) {
  if (!iso) return '';
  const d = parseISO(iso);
  return `${d.getDate()}. ${d.getMonth() + 1}. ${d.getFullYear()}`;
}
/** Sreda, 28. 10. 2026 · 09:00 */
export function fmtDateTimeLong(iso: string, time: string) {
  const d = parseISO(iso);
  return `${DOW_LONG[d.getDay()]}, ${fmtDate(iso)}${time ? ' · ' + time : ''}`;
}
/** Sreda, 28. oktober 2026 */
export function fmtDayTitle(iso: string, withYear = true) {
  const d = parseISO(iso);
  return `${DOW_LONG[d.getDay()]}, ${d.getDate()}. ${MONTHS[d.getMonth()]}${withYear ? ' ' + d.getFullYear() : ''}`;
}
export function fmtTimestamp(ms: number) {
  if (!ms) return '—';
  const d = new Date(ms);
  const t = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const today = new Date();
  const y = new Date(); y.setDate(y.getDate() - 1);
  if (toISO(d) === toISO(today)) return `Danes, ${t}`;
  if (toISO(d) === toISO(y)) return `Včeraj, ${t}`;
  return `${d.getDate()}. ${d.getMonth() + 1}. ${d.getFullYear()}, ${t}`;
}
export function relativeDays(ms: number) {
  const days = Math.floor((startOfDay(new Date()).getTime() - startOfDay(new Date(ms)).getTime()) / 86400000);
  if (days <= 0) return 'danes';
  if (days === 1) return 'včeraj';
  if (days === 2) return 'pred 2 dnevoma';
  return `pred ${days} dnevi`;
}
function startOfDay(d: Date) { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; }

export function plural(n: number, one: string, two: string, few: string, many: string) {
  const m = n % 100;
  if (m === 1) return `${n} ${one}`;
  if (m === 2) return `${n} ${two}`;
  if (m === 3 || m === 4) return `${n} ${few}`;
  return `${n} ${many}`;
}

/** dan v mesecu, omejen na zadnji dan (31. → 30./28.) */
function clampDay(y: number, m: number, d: number) {
  const last = new Date(y, m + 1, 0).getDate();
  return new Date(y, m, Math.min(d, last));
}

/** Ali se opomnik pojavi na danem datumu (upošteva ponovitev). */
export function occursOn(r: Pick<Reminder, 'date' | 'repeat'>, iso: string) {
  if (iso < r.date) return false;
  if (r.repeat === 'once') return iso === r.date;
  const s = parseISO(r.date);
  const d = parseISO(iso);
  if (r.repeat === 'monthly') return toISO(clampDay(d.getFullYear(), d.getMonth(), s.getDate())) === iso;
  return d.getMonth() === s.getMonth() && toISO(clampDay(d.getFullYear(), s.getMonth(), s.getDate())) === iso;
}

/** Naslednja ponovitev od (vključno) danega datuma. */
export function nextOccurrence(r: Pick<Reminder, 'date' | 'repeat'>, fromISO: string): string | null {
  if (r.repeat === 'once') return r.date >= fromISO ? r.date : null;
  if (r.date >= fromISO) return r.date;
  const s = parseISO(r.date);
  const f = parseISO(fromISO);
  if (r.repeat === 'monthly') {
    for (let i = 0; i < 3; i++) {
      const c = clampDay(f.getFullYear(), f.getMonth() + i, s.getDate());
      if (toISO(c) >= fromISO) return toISO(c);
    }
  } else {
    for (let i = 0; i < 2; i++) {
      const c = clampDay(f.getFullYear() + i, s.getMonth(), s.getDate());
      if (toISO(c) >= fromISO) return toISO(c);
    }
  }
  return null;
}

/** Datum za naslednjo ponovitev po danem datumu (za »Opravljeno«). */
export function advance(r: Pick<Reminder, 'date' | 'repeat'>, afterISO: string): string | null {
  const d = parseISO(afterISO);
  d.setDate(d.getDate() + 1);
  return nextOccurrence(r, toISO(d));
}

export function remindOffsetDays(r: RemindBefore) {
  return r === '7d' ? 7 : r === '1d' ? 1 : 0;
}

/** Mreža meseca (pon–ned), 6 ali manj vrstic. */
export function monthGrid(year: number, month: number) {
  const first = new Date(year, month, 1);
  const startOffset = (first.getDay() + 6) % 7;
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: { iso: string; day: number; inMonth: boolean }[] = [];
  for (let i = startOffset; i > 0; i--) {
    const d = new Date(year, month, 1 - i);
    cells.push({ iso: toISO(d), day: d.getDate(), inMonth: false });
  }
  for (let i = 1; i <= daysInMonth; i++) cells.push({ iso: toISO(new Date(year, month, i)), day: i, inMonth: true });
  while (cells.length % 7) {
    const k = cells.length - startOffset - daysInMonth + 1;
    const d = new Date(year, month, daysInMonth + k);
    cells.push({ iso: toISO(d), day: d.getDate(), inMonth: false });
  }
  return cells;
}
