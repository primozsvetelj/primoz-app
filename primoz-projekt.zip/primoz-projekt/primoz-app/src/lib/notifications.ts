import { LocalNotifications } from '@capacitor/local-notifications';
import { Preferences } from '@capacitor/preferences';
import { registerPlugin } from '@capacitor/core';
import { db, getMeta, vehicleLabel } from './db';
import { isNative } from './native';
import { nextOccurrence, occursOn, parseISO, remindOffsetDays, todayISO, toISO } from './dates';

const Widgets = registerPlugin<{ refresh(): Promise<void> }>('Widgets');

function hashId(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h) % 2000000000 || 1;
}

export async function requestNotificationPermission() {
  if (!isNative) return true;
  try {
    const p = await LocalNotifications.checkPermissions();
    if (p.display === 'granted') return true;
    const r = await LocalNotifications.requestPermissions();
    return r.display === 'granted';
  } catch {
    return false;
  }
}

/** Ponovno načrtuje obvestila za vse aktivne opomnike (naslednja ponovitev). */
export async function rescheduleAll() {
  if (!isNative) return;
  try {
    const reminders = await db.reminders.filter((r) => !r.deleted && !r.done).toArray();
    const vehicles = new Map((await db.vehicles.toArray()).filter((v) => !v.deleted).map((v) => [v.id, v]));
    const today = todayISO();
    const widgetRows = reminders.filter((r) => occursOn(r, today)).sort((a, b) => a.time.localeCompare(b.time)).slice(0, 4).map((r) => {
      const vehicle = vehicles.get(r.vehicleId);
      return `${r.time} · ${r.title}${vehicle ? ` · ${vehicle.owner}` : ''}`;
    });
    await Preferences.set({ key: 'widget_today', value: JSON.stringify(widgetRows) });
    await Widgets.refresh().catch(() => undefined);

    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length) {
      await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
    }
    const enabled = await getMeta('notifications', true);
    if (!enabled) return;
    const perm = await LocalNotifications.checkPermissions();
    if (perm.display !== 'granted') return;

    const now = Date.now();
    const list = [];
    for (const r of reminders) {
      // poišči prvo ponovitev, katere obvestilo je še v prihodnosti
      let from = toISO(new Date());
      for (let i = 0; i < 3; i++) {
        const occ = nextOccurrence(r, from);
        if (!occ) break;
        const at = parseISO(occ);
        const [hh, mm] = (r.time || '09:00').split(':').map(Number);
        at.setHours(hh || 9, mm || 0, 0, 0);
        at.setDate(at.getDate() - remindOffsetDays(r.remind));
        if (at.getTime() > now) {
          const v = vehicles.get(r.vehicleId);
          const when = r.remind === 'day' ? 'danes' : r.remind === '1d' ? 'jutri' : 'čez 7 dni';
          list.push({
            id: hashId(r.id + occ),
            title: r.title,
            body: `${v ? v.owner + ' · ' + vehicleLabel(v) + ' · ' : ''}${when} ob ${r.time}`,
            schedule: { at, allowWhileIdle: true },
            extra: { reminderId: r.id },
          });
          break;
        }
        const n = parseISO(occ);
        n.setDate(n.getDate() + 1);
        from = toISO(n);
      }
    }
    if (list.length) await LocalNotifications.schedule({ notifications: list });
  } catch (e) {
    console.warn('Obvestila', e);
  }
}
