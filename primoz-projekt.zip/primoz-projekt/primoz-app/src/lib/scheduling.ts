import { alive, db } from './db';

/** Prvi prost 15-minutni termin od 20:00 naprej za izbrani dan. */
export async function firstAvailableEvening(date: string, excludeId?: string): Promise<string> {
  if (!date) return '20:00';
  const [services, reminders] = await Promise.all([
    db.services.where('date').equals(date).toArray(),
    db.reminders.where('date').equals(date).toArray(),
  ]);
  const occupied = new Set(
    [...services, ...reminders]
      .filter((row) => alive(row) && row.id !== excludeId)
      .map((row) => row.time),
  );
  for (let minutes = 20 * 60; minutes < 24 * 60; minutes += 15) {
    const value = `${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`;
    if (!occupied.has(value)) return value;
  }
  return '23:45';
}
