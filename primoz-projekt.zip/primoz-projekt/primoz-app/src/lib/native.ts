import { Capacitor } from '@capacitor/core';
import { Clipboard } from '@capacitor/clipboard';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

export const isNative = Capacitor.isNativePlatform();

export async function copyText(text: string) {
  try {
    if (isNative) await Clipboard.write({ string: text });
    else await navigator.clipboard.writeText(text);
  } catch {
    /* ignore */
  }
  tap();
}

export function tap() {
  if (isNative) Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
}

export interface OutFile {
  name: string;
  mime: string;
  /** besedilo (utf8) ali base64 */
  data: string;
  base64?: boolean;
}

export interface SavedFile {
  name: string;
  /** uporabniku prijazna lokacija */
  location: string;
  uri?: string;
}

const FOLDER = 'PrimozApp';

/**
 * Shrani datoteke v Dokumenti/PrimozApp na telefonu (dostopno prek USB ali upravitelja datotek).
 * Na spletu (razvoj) datoteke prenese.
 */
export async function saveFiles(files: OutFile[]): Promise<SavedFile[]> {
  const out: SavedFile[] = [];
  if (!isNative) {
    for (const f of files) {
      const blob = f.base64 ? b64ToBlob(f.data, f.mime) : new Blob([f.data], { type: f.mime });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = f.name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      out.push({ name: f.name, location: 'Prenosi' });
    }
    return out;
  }
  for (const f of files) {
    const path = `${FOLDER}/${f.name}`;
    let res;
    try {
      res = await Filesystem.writeFile({
        path, data: f.data, directory: Directory.Documents, recursive: true,
        ...(f.base64 ? {} : { encoding: Encoding.UTF8 }),
      });
      out.push({ name: f.name, location: `Dokumenti/${FOLDER}`, uri: res.uri });
    } catch {
      // rezervna pot: zasebna mapa aplikacije (vedno dovoljena), nato deljenje
      res = await Filesystem.writeFile({
        path, data: f.data, directory: Directory.Cache, recursive: true,
        ...(f.base64 ? {} : { encoding: Encoding.UTF8 }),
      });
      out.push({ name: f.name, location: 'začasna mapa (uporabi Deli)', uri: res.uri });
    }
  }
  return out;
}

/** Sistemsko deljenje (Drive, e-pošta, Quick Share, OneDrive …). */
export async function shareFiles(saved: SavedFile[], title = 'Izvoz – Primož app') {
  if (!isNative) return;
  const uris = saved.map((s) => s.uri).filter(Boolean) as string[];
  if (!uris.length) return;
  try {
    await Share.share({ title, dialogTitle: 'Deli izvoz', files: uris });
  } catch {
    /* uporabnik je preklical */
  }
}

export function b64ToBlob(b64: string, mime: string) {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}

export function arrayBufferToB64(buf: ArrayBuffer) {
  const bytes = new Uint8Array(buf);
  let s = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) s += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(s);
}

/** Izbira datoteke (uvoz JSON, slika profila). */
export function pickFile(accept: string): Promise<File | null> {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.onchange = () => resolve(input.files?.[0] ?? null);
    input.oncancel = () => resolve(null);
    input.click();
  });
}

export function fileToDataUrl(file: File, maxSize = 256): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}
