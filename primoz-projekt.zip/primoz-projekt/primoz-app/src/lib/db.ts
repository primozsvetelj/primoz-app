import Dexie, { type Table } from 'dexie';

/* ---------- Tipi (podatkovni model iz Figma »Predaja za razvoj«) ---------- */

export interface SyncMeta {
  id: string;
  createdAt: number;
  /** čas zadnje spremembe (ms) – osnova za inkrementalni izvoz v oblak */
  updatedAt: number;
  /** 1 = izbrisano (»tombstone«), da se izbris prenese tudi v oblak */
  deleted: 0 | 1;
}

export type VehicleType = 'osebni' | 'kombi' | 'motor' | 'tovorno';
export const VEHICLE_TYPES: { id: VehicleType; label: string }[] = [
  { id: 'osebni', label: 'Osebni avto' },
  { id: 'kombi', label: 'Kombi' },
  { id: 'motor', label: 'Motor' },
  { id: 'tovorno', label: 'Tovorno' },
];

export interface Vehicle extends SyncMeta {
  owner: string;
  brand: string;
  model: string;
  plate: string;
  vin: string;
  engine: string;
  year: string;
  type: VehicleType;
  /** vrednosti lastnih polj: fieldId -> vrednost */
  custom: Record<string, string>;
}

export type FieldType = 'text' | 'number' | 'date';
export interface FieldDef extends SyncMeta {
  name: string;
  type: FieldType;
  active: 0 | 1;
  order: number;
  /** ključ osnovnega polja vozila (owner, brand …) ali prazno za lastno polje */
  builtin?: string;
}

export type FluidIcon = 'oil' | 'brake' | 'gear' | 'drop';
export interface FluidType extends SyncMeta {
  name: string;
  icon: FluidIcon;
  builtin: 0 | 1;
}
export interface Fluid extends SyncMeta {
  vehicleId: string;
  typeId: string;
  description: string;
}

export type EventColor = 'violet' | 'orange';
export const COLOR_LABEL: Record<EventColor, string> = { violet: 'Dolg servis', orange: 'Hitri servis' };

export interface ServiceType extends SyncMeta {
  name: string;
  builtin: 0 | 1;
}
export interface Service extends SyncMeta {
  vehicleId: string;
  title: string;
  color: EventColor;
  typeId: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
}

export type Repeat = 'once' | 'monthly' | 'yearly';
export type RemindBefore = 'day' | '1d' | '7d';
export const REPEAT_LABEL: Record<Repeat, string> = { once: 'Enkrat', monthly: 'Mesečno', yearly: 'Letno' };
export const REMIND_LABEL: Record<RemindBefore, string> = { day: 'Na dan', '1d': '1 dan prej', '7d': '7 dni prej' };

export interface Reminder extends SyncMeta {
  vehicleId: string;
  title: string;
  color: EventColor;
  date: string;
  time: string;
  repeat: Repeat;
  remind: RemindBefore;
  done: 0 | 1;
}

export interface MetaRow {
  key: string;
  value: unknown;
}

export const SYNC_TABLES = ['vehicles', 'fieldDefs', 'fluidTypes', 'fluids', 'serviceTypes', 'services', 'reminders'] as const;
export type SyncTable = (typeof SYNC_TABLES)[number];

class PrimozDB extends Dexie {
  vehicles!: Table<Vehicle, string>;
  fieldDefs!: Table<FieldDef, string>;
  fluidTypes!: Table<FluidType, string>;
  fluids!: Table<Fluid, string>;
  serviceTypes!: Table<ServiceType, string>;
  services!: Table<Service, string>;
  reminders!: Table<Reminder, string>;
  meta!: Table<MetaRow, string>;

  constructor() {
    super('primoz-app');
    this.version(1).stores({
      vehicles: 'id, updatedAt, deleted, owner, plate',
      fieldDefs: 'id, updatedAt, deleted, order',
      fluidTypes: 'id, updatedAt, deleted',
      fluids: 'id, updatedAt, deleted, vehicleId',
      serviceTypes: 'id, updatedAt, deleted',
      services: 'id, updatedAt, deleted, vehicleId, date',
      reminders: 'id, updatedAt, deleted, vehicleId, date',
      meta: 'key',
    });
  }
}

export const db = new PrimozDB();

export function uid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return 'id-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

/* ---------- Osnovni podatki (knjižnice) – fiksni ID-ji, updatedAt = 0 ---------- */

const base = { createdAt: 0, updatedAt: 0, deleted: 0 as const };
const ord = <T extends SyncMeta>(list: T[]) => list.map((x, i) => ({ ...x, createdAt: i + 1 }));

export const BUILTIN_FIELDS: FieldDef[] = [
  { id: 'f-owner', name: 'Ime lastnika', type: 'text', active: 1, order: 0, builtin: 'owner', ...base },
  { id: 'f-brand', name: 'Znamka', type: 'text', active: 1, order: 1, builtin: 'brand', ...base },
  { id: 'f-model', name: 'Model', type: 'text', active: 1, order: 2, builtin: 'model', ...base },
  { id: 'f-plate', name: 'Registracija', type: 'text', active: 1, order: 3, builtin: 'plate', ...base },
  { id: 'f-vin', name: 'Šasija (VIN)', type: 'text', active: 1, order: 4, builtin: 'vin', ...base },
  { id: 'f-engine', name: 'Motor', type: 'text', active: 1, order: 5, builtin: 'engine', ...base },
  { id: 'f-year', name: 'Letnik', type: 'number', active: 1, order: 6, builtin: 'year', ...base },
  { id: 'f-type', name: 'Vrsta vozila', type: 'text', active: 1, order: 7, builtin: 'type', ...base },
  { id: 'f-lastservice', name: 'Zadnji servis', type: 'date', active: 1, order: 100, builtin: 'lastService', ...base },
];

const BUILTIN_FLUIDS: FluidType[] = ord([
  { id: 'ft-motor', name: 'Motorno olje', icon: 'oil', builtin: 1, ...base },
  { id: 'ft-brake', name: 'Zavorna tekočina', icon: 'brake', builtin: 1, ...base },
  { id: 'ft-gear', name: 'Olje menjalnika', icon: 'gear', builtin: 1, ...base },
  { id: 'ft-coolant', name: 'Hladilna tekočina', icon: 'drop', builtin: 1, ...base },
]);

const BUILTIN_SERVICES: ServiceType[] = ord([
  { id: 'st-oil', name: 'Menjava olja', builtin: 1, ...base },
  { id: 'st-small', name: 'Mali servis', builtin: 1, ...base },
  { id: 'st-big', name: 'Veliki servis', builtin: 1, ...base },
  { id: 'st-tyres', name: 'Gume', builtin: 1, ...base },
]);

export async function ensureSeed() {
  await db.transaction('rw', db.fieldDefs, db.fluidTypes, db.serviceTypes, async () => {
    for (const f of BUILTIN_FIELDS) if (!(await db.fieldDefs.get(f.id))) await db.fieldDefs.put(f);
    for (const f of BUILTIN_FLUIDS) if (!(await db.fluidTypes.get(f.id))) await db.fluidTypes.put(f);
    for (const s of BUILTIN_SERVICES) if (!(await db.serviceTypes.get(s.id))) await db.serviceTypes.put(s);
  });
}

/* ---------- Pisanje z žigom spremembe ---------- */

type Payload<T> = Omit<T, keyof SyncMeta> & Partial<Pick<SyncMeta, 'id'>>;

export async function save<T extends SyncMeta>(table: Table<T, string>, data: Payload<T>): Promise<T> {
  const now = Date.now();
  const existing = data.id ? await table.get(data.id) : undefined;
  const row = {
    ...(existing ?? {}),
    ...data,
    id: data.id ?? uid(),
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    deleted: 0,
  } as unknown as T;
  await table.put(row);
  return row;
}

export async function patch<T extends SyncMeta>(table: Table<T, string>, id: string, changes: Partial<T>) {
  await table.update(id, { ...changes, updatedAt: Date.now() } as never);
}

export async function softDelete<T extends SyncMeta>(table: Table<T, string>, id: string) {
  await table.update(id, { deleted: 1, updatedAt: Date.now() } as never);
}
export async function restore<T extends SyncMeta>(table: Table<T, string>, id: string) {
  await table.update(id, { deleted: 0, updatedAt: Date.now() } as never);
}

/** Izbriše vozilo skupaj s servisi, opomniki in tekočinami. Vrne seznam za razveljavitev. */
export async function deleteVehicleCascade(id: string) {
  const now = Date.now();
  const removed: { table: SyncTable; id: string }[] = [];
  await db.transaction('rw', db.vehicles, db.services, db.reminders, db.fluids, async () => {
    await db.vehicles.update(id, { deleted: 1, updatedAt: now });
    removed.push({ table: 'vehicles', id });
    for (const t of ['services', 'reminders', 'fluids'] as const) {
      const rows = await (db[t] as Table<SyncMeta, string>).where('vehicleId').equals(id).filter((r) => !r.deleted).toArray();
      for (const r of rows) {
        await (db[t] as Table<SyncMeta, string>).update(r.id, { deleted: 1, updatedAt: now });
        removed.push({ table: t, id: r.id });
      }
    }
  });
  return removed;
}

export async function undoRemoved(list: { table: SyncTable; id: string }[]) {
  const now = Date.now();
  for (const r of list) await (db[r.table] as Table<SyncMeta, string>).update(r.id, { deleted: 0, updatedAt: now });
}

/* ---------- Meta (lokalne nastavitve – se ne sinhronizirajo) ---------- */

export async function getMeta<T>(key: string, def: T): Promise<T> {
  const r = await db.meta.get(key);
  return (r?.value as T) ?? def;
}
export async function setMeta(key: string, value: unknown) {
  await db.meta.put({ key, value });
}

/* ---------- Pomožne funkcije ---------- */

export const alive = <T extends SyncMeta>(r: T) => !r.deleted;

export function vehicleLabel(v?: Vehicle) {
  if (!v) return 'Neznano vozilo';
  return [v.brand, v.model].filter(Boolean).join(' ');
}
export function vehicleTypeLabel(t: VehicleType) {
  return VEHICLE_TYPES.find((x) => x.id === t)?.label ?? '';
}
