import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { db, alive, vehicleTypeLabel, COLOR_LABEL, REPEAT_LABEL, REMIND_LABEL } from './db';
import { fmtDate, toISO } from './dates';
import { arrayBufferToB64, type OutFile } from './native';
import { fullSnapshot } from './sync';

export type ExportFormat = 'csv' | 'xlsx' | 'pdf' | 'json';
export type ExportPeriod = 'month' | 'year' | 'all';

interface Sheet { name: string; head: string[]; rows: (string | number)[][] }

async function buildSheets(period: ExportPeriod): Promise<Sheet[]> {
  const now = new Date();
  const from =
    period === 'month' ? toISO(new Date(now.getFullYear(), now.getMonth() - 1, now.getDate()))
    : period === 'year' ? `${now.getFullYear()}-01-01` : '0000-00-00';
  const inPeriod = (iso: string) => iso >= from;

  const vehicles = (await db.vehicles.toArray()).filter(alive);
  const vmap = new Map(vehicles.map((v) => [v.id, v]));
  const fields = (await db.fieldDefs.toArray()).filter((f) => alive(f) && !f.builtin).sort((a, b) => a.order - b.order);
  const ftypes = new Map((await db.fluidTypes.toArray()).map((t) => [t.id, t]));
  const stypes = new Map((await db.serviceTypes.toArray()).map((t) => [t.id, t]));
  const fluids = (await db.fluids.toArray()).filter((f) => alive(f) && vmap.has(f.vehicleId));
  const services = (await db.services.toArray()).filter((s) => alive(s) && vmap.has(s.vehicleId) && inPeriod(s.date)).sort((a, b) => a.date.localeCompare(b.date));
  const reminders = (await db.reminders.toArray()).filter((r) => alive(r) && vmap.has(r.vehicleId) && inPeriod(r.date)).sort((a, b) => a.date.localeCompare(b.date));

  const vName = (id: string) => { const v = vmap.get(id); return v ? `${v.owner} (${v.plate})` : ''; };

  return [
    {
      name: 'Vozila',
      head: ['Lastnik', 'Znamka', 'Model', 'Registracija', 'Šasija (VIN)', 'Motor', 'Letnik', 'Vrsta', ...fields.map((f) => f.name)],
      rows: vehicles.map((v) => [v.owner, v.brand, v.model, v.plate, v.vin, v.engine, v.year, vehicleTypeLabel(v.type), ...fields.map((f) => v.custom?.[f.id] ?? '')]),
    },
    {
      name: 'Servisi',
      head: ['Datum', 'Ura', 'Dogodek', 'Vrsta servisa', 'Barva', 'Vozilo'],
      rows: services.map((s) => [fmtDate(s.date), s.time, s.title, stypes.get(s.typeId)?.name ?? '', COLOR_LABEL[s.color], vName(s.vehicleId)]),
    },
    {
      name: 'Opomniki',
      head: ['Datum', 'Ura', 'Dogodek', 'Ponovitev', 'Opomni me', 'Opravljeno', 'Vozilo'],
      rows: reminders.map((r) => [fmtDate(r.date), r.time, r.title, REPEAT_LABEL[r.repeat], REMIND_LABEL[r.remind], r.done ? 'da' : 'ne', vName(r.vehicleId)]),
    },
    {
      name: 'Olja in tekočine',
      head: ['Vozilo', 'Vrsta', 'Opis', 'Vir'],
      rows: fluids.map((f) => { const t = ftypes.get(f.typeId); return [vName(f.vehicleId), t?.name ?? '', f.description, t?.builtin ? 'Iz baze' : 'Moje']; }),
    },
  ];
}

function csvCell(v: string | number) {
  const s = String(v ?? '');
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const slug = (s: string) => s.toLowerCase().replace(/č/g, 'c').replace(/š/g, 's').replace(/ž/g, 'z').replace(/[^a-z0-9]+/g, '-');

export async function buildExport(format: ExportFormat, period: ExportPeriod): Promise<OutFile[]> {
  const d = new Date();
  const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const baseName = `primoz-evidenca-${stamp}`;

  if (format === 'json') {
    const snap = await fullSnapshot();
    return [{ name: `${baseName}.json`, mime: 'application/json', data: JSON.stringify(snap, null, 1) }];
  }

  const sheets = await buildSheets(period);

  if (format === 'csv') {
    // podpičje + BOM: Excel v slovenskih nastavitvah odpre pravilno
    return sheets.map((s) => ({
      name: `${baseName}-${slug(s.name)}.csv`,
      mime: 'text/csv',
      data: '﻿' + [s.head, ...s.rows].map((r) => r.map(csvCell).join(';')).join('\r\n'),
    }));
  }

  if (format === 'xlsx') {
    const wb = XLSX.utils.book_new();
    for (const s of sheets) {
      const ws = XLSX.utils.aoa_to_sheet([s.head, ...s.rows]);
      ws['!cols'] = s.head.map((h, i) => ({ wch: Math.max(h.length, ...s.rows.map((r) => String(r[i] ?? '').length)) + 2 }));
      XLSX.utils.book_append_sheet(wb, ws, s.name.slice(0, 31));
    }
    const buf = XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer;
    return [{ name: `${baseName}.xlsx`, mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', data: arrayBufferToB64(buf), base64: true }];
  }

  // PDF
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  // vgrajena pisava z vsemi šumniki (č, š, ž, ć, đ)
  let font = 'helvetica';
  try {
    const buf = await (await fetch('fonts/DejaVuSans.ttf')).arrayBuffer();
    doc.addFileToVFS('DejaVuSans.ttf', arrayBufferToB64(buf));
    doc.addFont('DejaVuSans.ttf', 'DejaVu', 'normal');
    doc.addFont('DejaVuSans.ttf', 'DejaVu', 'bold');
    font = 'DejaVu';
  } catch { /* rezervna pisava */ }
  doc.setFont(font, 'normal');
  const t = (s: string | number) => String(s ?? '');
  doc.setFontSize(18);
  doc.text(t('Primož app – evidenca vozil'), 14, 16);
  doc.setFontSize(10);
  doc.text(t(`Izvoženo ${fmtDate(toISO(d))} · obdobje: ${period === 'month' ? 'zadnji mesec' : period === 'year' ? 'letos' : 'vse'}`), 14, 22);
  let y = 28;
  for (const s of sheets) {
    doc.setFontSize(13);
    doc.text(t(s.name), 14, y + 4);
    autoTable(doc, {
      startY: y + 7,
      head: [s.head.map(t)],
      body: s.rows.length ? s.rows.map((r) => r.map(t)) : [[t('Ni podatkov')]],
      styles: { fontSize: 8, cellPadding: 1.6, font },
      headStyles: { fillColor: [129, 84, 255] },
      margin: { left: 14, right: 14 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;
    if (y > 180) { doc.addPage(); y = 14; }
  }
  const b64 = doc.output('datauristring').split(',')[1];
  return [{ name: `${baseName}.pdf`, mime: 'application/pdf', data: b64, base64: true }];
}
