import { db, save, uid, VEHICLE_TYPES, COLOR_LABEL, REPEAT_LABEL, REMIND_LABEL, type EventColor, type Repeat, type RemindBefore, type Vehicle, type VehicleType } from './db';

type CsvRow = Record<string, string>;
type CsvKind = 'vehicles' | 'customers' | 'services' | 'reminders' | 'fluids';

export interface CsvImportResult {
  files: number;
  records: number;
  byKind: Partial<Record<CsvKind, number>>;
}

const clean = (value: string) => value.replace(/^\uFEFF/, '').trim();
const norm = (value: string) => clean(value).toLocaleLowerCase('sl').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ');

function parseCsv(text: string): CsvRow[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  const source = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (quoted) {
      if (ch === '"' && source[i + 1] === '"') { cell += '"'; i += 1; }
      else if (ch === '"') quoted = false;
      else cell += ch;
      continue;
    }
    if (ch === '"') quoted = true;
    else if (ch === ';') { row.push(cell); cell = ''; }
    else if (ch === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += ch;
  }
  if (cell || row.length) { row.push(cell.replace(/\r$/, '')); rows.push(row); }
  const headers = (rows.shift() ?? []).map(clean);
  if (!headers.length) return [];
  return rows.filter((values) => values.some((value) => clean(value))).map((values) => Object.fromEntries(headers.map((header, index) => [header, clean(values[index] ?? '')])));
}

function detect(rows: CsvRow[]): CsvKind | null {
  const headers = Object.keys(rows[0] ?? {});
  if (headers.includes('Šasija (VIN)') && headers.includes('Registracija')) return 'vehicles';
  if (headers.includes('Ime in priimek') && headers.includes('Telefon')) return 'customers';
  if (headers.includes('Vrsta servisa')) return 'services';
  if (headers.includes('Ponovitev') && headers.includes('Opomni me')) return 'reminders';
  if (headers.includes('Opis') && headers.includes('Vir') && headers.includes('Vozilo')) return 'fluids';
  return null;
}

function parseDate(value: string) {
  const iso = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return value;
  const local = value.match(/^(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})$/);
  if (!local) return '';
  return `${local[3]}-${local[2].padStart(2, '0')}-${local[1].padStart(2, '0')}`;
}

function vehicleType(value: string): VehicleType {
  return VEHICLE_TYPES.find((item) => norm(item.label) === norm(value))?.id ?? 'osebni';
}

function inverse<T extends string>(map: Record<T, string>, value: string, fallback: T): T {
  return (Object.entries(map).find(([, label]) => norm(String(label)) === norm(value))?.[0] as T | undefined) ?? fallback;
}

function vehicleForLabel(vehicles: Vehicle[], label: string) {
  const match = label.match(/^(.*)\s+\((.*)\)$/);
  const owner = norm(match?.[1] ?? label);
  const plate = norm(match?.[2] ?? '');
  return vehicles.find((vehicle) => (plate && norm(vehicle.plate) === plate) || (owner && norm(vehicle.owner) === owner));
}

async function importRows(kind: CsvKind, rows: CsvRow[]) {
  let count = 0;
  if (kind === 'customers') {
    const existing = await db.customers.toArray();
    for (const row of rows) {
      if (!row['Ime in priimek']) continue;
      const found = existing.find((item) => !item.deleted && norm(item.name) === norm(row['Ime in priimek']));
      const saved = await save(db.customers, { id: found?.id, name: row['Ime in priimek'], phone: row.Telefon ?? '', email: row['E-pošta'] ?? '' });
      if (!found) existing.push(saved);
      count += 1;
    }
  }
  if (kind === 'vehicles') {
    const existing = await db.vehicles.toArray();
    const baseHeaders = new Set(['Lastnik', 'Znamka', 'Model', 'Registracija', 'Šasija (VIN)', 'Motor', 'Moč (kW)', 'Letnik', 'Vrsta']);
    const customNames = Object.keys(rows[0] ?? {}).filter((header) => !baseHeaders.has(header));
    const fieldDefs = await db.fieldDefs.toArray();
    const customFields = new Map<string, string>();
    for (const name of customNames) {
      let field = fieldDefs.find((item) => !item.deleted && !item.builtin && norm(item.name) === norm(name));
      if (!field) {
        field = await save(db.fieldDefs, { name, type: 'text', active: 1, order: fieldDefs.length + customFields.size + 1 });
        fieldDefs.push(field);
      }
      customFields.set(name, field.id);
    }
    for (const row of rows) {
      const plate = row.Registracija ?? '';
      const vin = row['Šasija (VIN)'] ?? '';
      const found = existing.find((item) => !item.deleted && ((vin && norm(item.vin) === norm(vin)) || (plate && norm(item.plate) === norm(plate)) || (!vin && !plate && norm(`${item.owner}|${item.brand}|${item.model}`) === norm(`${row.Lastnik}|${row.Znamka}|${row.Model}`))));
      const custom = { ...(found?.custom ?? {}) };
      for (const [name, id] of customFields) custom[id] = row[name] ?? '';
      const saved = await save(db.vehicles, {
        id: found?.id, owner: row.Lastnik ?? '', brand: row.Znamka ?? '', model: row.Model ?? '', plate: plate.toUpperCase(), vin: vin.toUpperCase(),
        engine: row.Motor ?? '', powerKw: row['Moč (kW)'] ?? '', year: row.Letnik ?? '', type: vehicleType(row.Vrsta ?? ''), custom,
      });
      if (!found) existing.push(saved);
      count += 1;
    }
  }
  if (kind === 'services' || kind === 'reminders' || kind === 'fluids') {
    const vehicles = (await db.vehicles.toArray()).filter((item) => !item.deleted);
    const serviceTypes = await db.serviceTypes.toArray();
    const fluidTypes = await db.fluidTypes.toArray();
    for (const row of rows) {
      const vehicle = vehicleForLabel(vehicles, row.Vozilo ?? '');
      if (!vehicle) continue;
      if (kind === 'services') {
        const date = parseDate(row.Datum ?? '');
        if (!date) continue;
        let type = serviceTypes.find((item) => !item.deleted && norm(item.name) === norm(row['Vrsta servisa'] ?? ''));
        if (!type && row['Vrsta servisa']) { type = await save(db.serviceTypes, { name: row['Vrsta servisa'], builtin: 0 }); serviceTypes.push(type); }
        const old = (await db.services.where('vehicleId').equals(vehicle.id).toArray()).find((item) => !item.deleted && item.date === date && item.time === row.Ura && norm(item.title) === norm(row.Dogodek ?? ''));
        await save(db.services, { id: old?.id, vehicleId: vehicle.id, title: row.Dogodek ?? '', color: inverse<EventColor>(COLOR_LABEL, row.Barva ?? '', 'violet'), typeId: type?.id ?? 'st-small', date, time: row.Ura || '20:00' });
      } else if (kind === 'reminders') {
        const date = parseDate(row.Datum ?? '');
        if (!date) continue;
        const old = (await db.reminders.where('vehicleId').equals(vehicle.id).toArray()).find((item) => !item.deleted && item.date === date && item.time === row.Ura && norm(item.title) === norm(row.Dogodek ?? ''));
        await save(db.reminders, { id: old?.id, vehicleId: vehicle.id, title: row.Dogodek ?? '', color: 'violet', date, time: row.Ura || '20:00', repeat: inverse<Repeat>(REPEAT_LABEL, row.Ponovitev ?? '', 'once'), remind: inverse<RemindBefore>(REMIND_LABEL, row['Opomni me'] ?? '', 'day'), done: norm(row.Opravljeno ?? '') === 'da' ? 1 : 0 });
      } else {
        let type = fluidTypes.find((item) => !item.deleted && norm(item.name) === norm(row.Vrsta ?? ''));
        if (!type && row.Vrsta) { type = await save(db.fluidTypes, { name: row.Vrsta, icon: 'drop', builtin: 0 }); fluidTypes.push(type); }
        const old = (await db.fluids.where('vehicleId').equals(vehicle.id).toArray()).find((item) => !item.deleted && item.typeId === type?.id && norm(item.description) === norm(row.Opis ?? ''));
        await save(db.fluids, { id: old?.id, vehicleId: vehicle.id, typeId: type?.id ?? uid(), description: row.Opis ?? '' });
      }
      count += 1;
    }
  }
  return count;
}

export async function importCsvFiles(files: File[]): Promise<CsvImportResult> {
  const parsed = await Promise.all(files.map(async (file) => {
    const rows = parseCsv(await file.text());
    const kind = detect(rows);
    if (!kind) throw new Error(`Datoteka ${file.name} ni prepoznan izvoz Primož app.`);
    return { kind, rows };
  }));
  const order: CsvKind[] = ['vehicles', 'customers', 'services', 'reminders', 'fluids'];
  parsed.sort((a, b) => order.indexOf(a.kind) - order.indexOf(b.kind));
  const result: CsvImportResult = { files: files.length, records: 0, byKind: {} };
  for (const item of parsed) {
    const count = await importRows(item.kind, item.rows);
    result.records += count;
    result.byKind[item.kind] = (result.byKind[item.kind] ?? 0) + count;
  }
  return result;
}
