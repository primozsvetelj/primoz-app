/**
 * Prepoznavanje šasije (VIN) in registrske številke iz fotografije.
 * Teče v celoti na telefonu (brez interneta): PP-OCRv4 (detekcija + prepoznava
 * vrstic besedila) prek ONNX Runtime Web.
 *
 * Postopek:
 *  1. detekcija vrstic besedila (tudi poševnih / navpičnih)
 *  2. vsako vrstico izrežemo, poravnamo in preberemo (CTC)
 *  3. iz prebranega besedila izluščimo kandidate po pravilih (VIN: 17 znakov
 *     brez I, O, Q, kontrolna številka, modelno leto; tablica: slovenski format)
 *  4. kandidate iz več prehodov (velikosti, kontrast, zasuk) ocenimo in glasujemo
 */
import * as ort from 'onnxruntime-web/wasm';

export type ScanKind = 'vin' | 'plate';

export interface OcrResult {
  value: string;
  /** 0–1 */
  confidence: number;
  /** VIN: ali se kontrolna številka (9. znak) ujema */
  checkDigitOk?: boolean;
  raw: string[];
  alternatives: string[];
  ms: number;
}

/* ------------------------------------------------------------------ */
/* Modeli                                                              */
/* ------------------------------------------------------------------ */

interface Engine { det: ort.InferenceSession; rec: ort.InferenceSession; dict: string[] }
let engineP: Promise<Engine> | null = null;
const base = () => new URL('./', document.baseURI).href;

export function getEngine(): Promise<Engine> {
  if (!engineP) {
    engineP = (async () => {
      ort.env.wasm.wasmPaths = base() + 'ort/';
      ort.env.wasm.numThreads = 1;
      ort.env.wasm.proxy = false;
      const opts: ort.InferenceSession.SessionOptions = { executionProviders: ['wasm'], graphOptimizationLevel: 'all' };
      const [det, rec, keys] = await Promise.all([
        ort.InferenceSession.create(base() + 'ocr/det.onnx', opts),
        ort.InferenceSession.create(base() + 'ocr/rec.onnx', opts),
        fetch(base() + 'ocr/keys.txt').then((r) => r.text()),
      ]);
      const dict = ['', ...keys.split('\n').filter((_, i, a) => i < a.length - 1 || a[i] !== ''), ' '];
      return { det, rec, dict };
    })().catch((e) => { engineP = null; throw e; });
  }
  return engineP;
}
/** Naloži modele v ozadju, da je prvo skeniranje hitrejše. */
export function warmUp() { getEngine().catch(() => {}); }

/* ------------------------------------------------------------------ */
/* Slike                                                              */
/* ------------------------------------------------------------------ */

type Src = HTMLCanvasElement | HTMLImageElement | ImageBitmap | HTMLVideoElement;

function srcSize(src: Src) {
  return 'videoWidth' in src ? { w: src.videoWidth, h: src.videoHeight } : { w: src.width, h: src.height };
}
function toCanvas(src: Src, w?: number, h?: number) {
  const { w: sw, h: sh } = srcSize(src);
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w ?? sw));
  c.height = Math.max(1, Math.round(h ?? sh));
  const g = c.getContext('2d', { willReadFrequently: true })!;
  g.imageSmoothingQuality = 'high';
  g.drawImage(src as CanvasImageSource, 0, 0, c.width, c.height);
  return c;
}
export function cropCanvas(src: Src, x: number, y: number, w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(h));
  c.getContext('2d')!.drawImage(src as CanvasImageSource, x, y, w, h, 0, 0, c.width, c.height);
  return c;
}

/** Raztezanje kontrasta (CLAHE-light): 1. in 99. percentil svetlosti. */
function stretch(src: HTMLCanvasElement) {
  const c = toCanvas(src);
  const g = c.getContext('2d', { willReadFrequently: true })!;
  const img = g.getImageData(0, 0, c.width, c.height);
  const d = img.data;
  const hist = new Uint32Array(256);
  for (let i = 0; i < d.length; i += 4) hist[(d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8]++;
  const n = d.length / 4;
  let lo = 0, hi = 255, acc = 0;
  for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc > n * 0.01) { lo = i; break; } }
  acc = 0;
  for (let i = 255; i >= 0; i--) { acc += hist[i]; if (acc > n * 0.01) { hi = i; break; } }
  const k = 255 / Math.max(1, hi - lo);
  for (let i = 0; i < d.length; i += 4) {
    const v = Math.max(0, Math.min(255, (((d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8) - lo) * k));
    d[i] = d[i + 1] = d[i + 2] = v;
  }
  g.putImageData(img, 0, 0);
  return c;
}

/* ------------------------------------------------------------------ */
/* Detekcija vrstic (DB)                                               */
/* ------------------------------------------------------------------ */

interface Box { cx: number; cy: number; w: number; h: number; angle: number; score: number }

async function detect(e: Engine, img: HTMLCanvasElement, maxSide: number): Promise<Box[]> {
  // majhne izreze povečamo (do 3x), velike pomanjšamo
  const r = Math.min(3, maxSide / Math.max(img.width, img.height));
  const W = Math.max(32, Math.round((img.width * r) / 32) * 32);
  const H = Math.max(32, Math.round((img.height * r) / 32) * 32);
  const c = toCanvas(img, W, H);
  const px = c.getContext('2d', { willReadFrequently: true })!.getImageData(0, 0, W, H).data;
  const mean = [0.485, 0.456, 0.406], std = [0.229, 0.224, 0.225];
  const data = new Float32Array(3 * W * H);
  for (let i = 0, j = 0; i < px.length; i += 4, j++) {
    data[j] = (px[i] / 255 - mean[0]) / std[0];
    data[W * H + j] = (px[i + 1] / 255 - mean[1]) / std[1];
    data[2 * W * H + j] = (px[i + 2] / 255 - mean[2]) / std[2];
  }
  const out = await e.det.run({ [e.det.inputNames[0]]: new ort.Tensor('float32', data, [1, 3, H, W]) });
  const prob = out[e.det.outputNames[0]].data as Float32Array;
  const mask = new Uint8Array(W * H);
  for (let i = 0; i < prob.length; i++) mask[i] = prob[i] > 0.3 ? 1 : 0;
  // povezane komponente
  const seen = new Uint8Array(W * H);
  const boxes: Box[] = [];
  const stack: number[] = [];
  const sx = img.width / W, sy = img.height / H;
  for (let s = 0; s < W * H; s++) {
    if (!mask[s] || seen[s]) continue;
    const xs: number[] = [], ys: number[] = [];
    let ps = 0;
    stack.push(s); seen[s] = 1;
    while (stack.length) {
      const p = stack.pop()!;
      const x = p % W, y = (p / W) | 0;
      xs.push(x); ys.push(y); ps += prob[p];
      const nb = [p - 1, p + 1, p - W, p + W];
      for (const q of nb) {
        if (q < 0 || q >= W * H || seen[q] || !mask[q]) continue;
        if ((q === p - 1 && x === 0) || (q === p + 1 && x === W - 1)) continue;
        seen[q] = 1; stack.push(q);
      }
    }
    if (xs.length < 12) continue;
    const score = ps / xs.length;
    if (score < 0.5) continue;
    // PCA -> zasukan pravokotnik (v originalnih koordinatah)
    let mx = 0, my = 0;
    for (let i = 0; i < xs.length; i++) { mx += xs[i] * sx; my += ys[i] * sy; }
    mx /= xs.length; my /= xs.length;
    let cxx = 0, cyy = 0, cxy = 0;
    for (let i = 0; i < xs.length; i++) { const dx = xs[i] * sx - mx, dy = ys[i] * sy - my; cxx += dx * dx; cyy += dy * dy; cxy += dx * dy; }
    let ang = 0.5 * Math.atan2(2 * cxy, cxx - cyy);
    const ca = Math.cos(ang), sa = Math.sin(ang);
    let minU = 1e9, maxU = -1e9, minV = 1e9, maxV = -1e9;
    for (let i = 0; i < xs.length; i++) {
      const dx = xs[i] * sx - mx, dy = ys[i] * sy - my;
      const u = dx * ca + dy * sa, v = -dx * sa + dy * ca;
      if (u < minU) minU = u; if (u > maxU) maxU = u; if (v < minV) minV = v; if (v > maxV) maxV = v;
    }
    let bw = maxU - minU + Math.max(sx, sy), bh = maxV - minV + Math.max(sx, sy);
    const cu = (maxU + minU) / 2, cv = (maxV + minV) / 2;
    const cx = mx + cu * ca - cv * sa, cy = my + cu * sa + cv * ca;
    if (bh > bw) { const t = bw; bw = bh; bh = t; ang += Math.PI / 2; }
    // »unclip« – DB napove skrčeno območje besedila
    const dist = (bw * bh * 1.6) / (2 * (bw + bh));
    bw += 2 * dist; bh += 2 * dist;
    if (bh < 6 || bw < 10) continue;
    boxes.push({ cx, cy, w: bw, h: bh, angle: ang, score });
  }
  return boxes;
}

/** Izreže in poravna zasukano vrstico. */
function cropBox(img: HTMLCanvasElement, b: Box, flip = false) {
  const H = 48;
  const s = H / b.h;
  const W = Math.max(16, Math.min(2000, Math.round(b.w * s)));
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const g = c.getContext('2d')!;
  g.imageSmoothingQuality = 'high';
  g.translate(W / 2, H / 2);
  if (flip) g.rotate(Math.PI);
  g.scale(s, s);
  g.rotate(-b.angle);
  g.translate(-b.cx, -b.cy);
  g.drawImage(img, 0, 0);
  return c;
}

interface Line { text: string; conf: number; box?: Box }

async function recognizeLine(e: Engine, c: HTMLCanvasElement): Promise<Line> {
  const W = c.width, H = c.height;
  const px = c.getContext('2d', { willReadFrequently: true })!.getImageData(0, 0, W, H).data;
  const data = new Float32Array(3 * W * H);
  for (let i = 0, j = 0; i < px.length; i += 4, j++) {
    data[j] = (px[i] / 255 - 0.5) / 0.5;
    data[W * H + j] = (px[i + 1] / 255 - 0.5) / 0.5;
    data[2 * W * H + j] = (px[i + 2] / 255 - 0.5) / 0.5;
  }
  const out = await e.rec.run({ [e.rec.inputNames[0]]: new ort.Tensor('float32', data, [1, 3, H, W]) });
  const t = out[e.rec.outputNames[0]];
  const [, T, C] = t.dims as number[];
  const p = t.data as Float32Array;
  let text = '';
  const confs: number[] = [];
  let prev = -1;
  for (let i = 0; i < T; i++) {
    let best = 0, bv = -1;
    for (let k = 0; k < C; k++) { const v = p[i * C + k]; if (v > bv) { bv = v; best = k; } }
    if (best !== 0 && best !== prev) {
      const ch = e.dict[best] ?? '';
      // ne-latinični znaki (npr. kitajski napisi) -> ločilo
      text += /^[A-Za-z0-9\-*]$/.test(ch) ? ch.toUpperCase() : ' ';
      confs.push(bv);
    }
    prev = best;
  }
  const conf = confs.length ? (confs.reduce((a, b) => a + b, 0) / confs.length) * 100 : 0;
  return { text: text.replace(/\s+/g, ' ').trim(), conf };
}

/** Vrstice na isti višini združi (npr. VIN, razdeljen na dva dela). */
function mergeRow(lines: Line[]): Line[] {
  const withBox = lines.filter((l) => l.box && l.text);
  const out: Line[] = [];
  const used = new Set<Line>();
  const sorted = [...withBox].sort((a, b) => a.box!.cx - b.box!.cx);
  for (const a of sorted) {
    if (used.has(a)) continue;
    const row = [a];
    for (const b of sorted) {
      if (b === a || used.has(b) || row.includes(b)) continue;
      const last = row[row.length - 1].box!;
      const bb = b.box!;
      if (Math.abs(bb.cy - last.cy) < Math.min(bb.h, last.h) * 0.5 && Math.abs(bb.h - last.h) < Math.max(bb.h, last.h) * 0.5) {
        const gap = (bb.cx - bb.w / 2) - (last.cx + last.w / 2);
        if (gap > -last.h && gap < last.h * 2.5) row.push(b);
      }
    }
    if (row.length > 1) {
      row.forEach((r) => used.add(r));
      out.push({ text: row.map((r) => r.text).join(' '), conf: Math.min(...row.map((r) => r.conf)) });
    }
  }
  return out;
}

/** Celoten izrez (ali sredinski pas) prebere kot eno vrstico – ko uporabnik poravna besedilo v okvir. */
async function readDirect(e: Engine, img: HTMLCanvasElement): Promise<Line[]> {
  const out: Line[] = [];
  const bands = [[0, 1], [0.2, 0.8], [0.3, 0.7]];
  for (const [a, b] of bands) {
    const y = img.height * a, h = img.height * (b - a);
    if (img.width / h < 3) continue;
    const H = 48, W = Math.min(2000, Math.round((img.width * H) / h));
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const g = c.getContext('2d')!; g.imageSmoothingQuality = 'high';
    g.drawImage(img, 0, y, img.width, h, 0, 0, W, H);
    const l = await recognizeLine(e, c);
    if (l.text) out.push(l);
  }
  return out;
}

async function readAll(e: Engine, img: HTMLCanvasElement, maxSide: number, flip: boolean): Promise<Line[]> {
  const boxes = (await detect(e, img, maxSide)).sort((a, b) => b.w * b.h - a.w * a.h).slice(0, 40);
  const lines: Line[] = [];
  for (const b of boxes) {
    const l = await recognizeLine(e, cropBox(img, b, flip));
    if (l.text) lines.push({ ...l, box: b });
  }
  return [...lines, ...mergeRow(lines)];
}

/* ------------------------------------------------------------------ */
/* VIN                                                                */
/* ------------------------------------------------------------------ */

const VIN_CHARS = 'ABCDEFGHJKLMNPRSTUVWXYZ0123456789';
const TRANS: Record<string, number> = Object.fromEntries('ABCDEFGHJKLMNPRSTUVWXYZ'.split('').map((c, i) => [c, [1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 7, 9, 2, 3, 4, 5, 6, 7, 8, 9][i]]));
const WEIGHTS = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2];

export function vinCheckDigit(v: string) {
  let s = 0;
  for (let i = 0; i < 17; i++) {
    const c = v[i];
    const n = /\d/.test(c) ? +c : TRANS[c];
    if (n === undefined) return '?';
    s += n * WEIGHTS[i];
  }
  const r = s % 11;
  return r === 10 ? 'X' : String(r);
}
export function vinCheckOk(v: string) {
  return v.length === 17 && vinCheckDigit(v) === v[8];
}
export function isValidVinFormat(v: string) {
  return /^[A-HJ-NPR-Z0-9]{17}$/.test(v);
}

/** Pogoste zamenjave pri branju. */
const VIN_FIX: Record<string, string> = { O: '0', Q: '0', I: '1', '|': '1', '!': '1', ']': '1', '[': '1', '$': 'S', '§': 'S', '€': 'E', '&': '8', '@': '0' };
const CONFUSE: Record<string, string[]> = {
  '0': ['D', 'U'], D: ['0'], '8': ['B', '3'], B: ['8'], '5': ['S'], S: ['5'], '2': ['Z'], Z: ['2', '7'], '6': ['G', 'C'], G: ['6', 'C'], '1': ['7', 'L'], '7': ['1', 'T', 'Z'],
  '4': ['A'], A: ['4'], U: ['V', '0'], V: ['U', 'W'], W: ['V', 'H'], H: ['M', 'N', 'W'], M: ['H', 'N'], N: ['M', 'H'], T: ['7', '1'], C: ['G', '0'], '3': ['8', 'B'], L: ['1'], E: ['F'], F: ['E', 'P'], P: ['F', 'R'], R: ['P', 'K'], K: ['X', 'R'], X: ['K'], Y: ['V', 'T'], '9': ['0'],
};
const TAIL_DIGIT: Record<string, string> = { O: '0', D: '0', Q: '0', U: '0', I: '1', L: '1', T: '7', Z: '2', S: '5', B: '8', G: '6', A: '4' };
/** Znaki, ki se pojavijo kot 10. znak (modelno leto). */
const YEAR = 'ABCDEFGHJKLMNPRSTVWXY123456789';
/** Prvi znak (država/regija) – vse pogoste proizvajalce pokrije. */
const WMI_FIRST = 'ABCJKLMNPRSTUVWXYZ123456789';

/** Pogosti WMI (prvi 3 znaki) – za popravek napačno prebranih začetnih črk. */
const WMI = new Set(('WBA WBS WBY WMW WDB WDD WDC WDF W1K W1N W1V W1W WME WVW WV1 WV2 WV3 WAU WUA WP0 WP1 WF0 W0L W0V WJM WMA WKK TRU TMB TMA TMP VSS VSE VSK VS6 VF1 VF3 VF7 VF8 VR1 VR3 VR7 VNK VNV VWV UU1 U5Y U6Y ' +
  'ZFA ZFF ZAR ZAM ZHW ZCF ZDM ZD4 ZLA SAL SAJ SAR SCC SCF SFZ SHH SHS SB1 SJN SDB YV1 YV4 YS2 YS3 YK1 JTD JTN JT2 JTE JTH JHM JHL JMZ JM1 JN1 JN8 JF1 JF2 JS1 JS3 JMB JA3 JA4 JLS KMH KNA KNM KMF KPT KL1 ' +
  'NMT NM0 NM4 MAL MA1 MAT MMB MMT MMC LSJ LFP LFB LFV LNB LGX LM8 LJC LVS LVV LBV LRW LDC L6T TSM TNE TK9 XTA X7L X4X X1F XTT XUF 1HG 1FA 1FT 1FM 1G1 1GC 1GT 1C4 1D4 1J4 1LN 1N4 1VW 2HG 2FA 2GT 2T1 3VW 3N1 4US 4T1 5YJ 5FN 5UX 6MM 9BW 93Y').split(' '));
export function fixWmi(v: string) {
  if (WMI.has(v.slice(0, 3))) return v;
  for (let i = 0; i < 3; i++) {
    for (const a of [...(CONFUSE[v[i]] ?? []), ...(v[i] === 'V' ? ['W'] : []), ...(v[i] === 'M' ? ['W'] : []), ...(v[i] === 'U' ? ['V', 'W'] : [])]) {
      const t = v.slice(0, i) + a + v.slice(i + 1);
      if (WMI.has(t.slice(0, 3))) return t;
    }
  }
  // »U« je kot prvi znak redek (UU1 Dacia, U5Y/U6Y Kia) – sicer gre za »V«
  if (v[0] === 'U' && !'U56'.includes(v[1])) return 'V' + v.slice(1);
  return v;
}

function vinScore(v: string, conf: number) {
  let s = conf;
  if (!isValidVinFormat(v)) return -1;
  const na = /^[1-5]/.test(v);
  if (vinCheckOk(v)) s += na ? 0.6 : 0.35;
  else if (na) s -= 0.4;
  if (YEAR.includes(v[9])) s += 0.05; else s -= 0.15;
  if (WMI.has(v.slice(0, 3))) s += 0.12; else if (WMI_FIRST.includes(v[0])) s += 0.03;
  // »ZZZ« (EU proizvajalci) je zelo značilen
  if (/^[A-Z0-9]{3}ZZZ/.test(v)) s += 0.08;
  // zadnjih 4 znakov je pri večini proizvajalcev števk
  if (/\d{4}$/.test(v)) s += 0.08;
  return s;
}

/** Popravi en znak, da se ujema kontrolna številka (samo za VIN s kontrolno številko). */
function repairCheckDigit(v: string): string | null {
  if (vinCheckOk(v)) return v;
  const out: string[] = [];
  for (let i = 0; i < 17; i++) {
    const alts = i === 8 ? '0123456789X'.split('') : CONFUSE[v[i]] ?? [];
    for (const a of alts) {
      const t = v.slice(0, i) + a + v.slice(i + 1);
      if (isValidVinFormat(t) && vinCheckOk(t)) out.push(t);
    }
  }
  return out.length === 1 ? out[0] : null;
}

interface Line { text: string; conf: number }

function vinCandidates(lines: Line[]) {
  const cands: { v: string; s: number }[] = [];
  const fix = (t: string) => t.split('').map((c) => VIN_FIX[c] ?? c).join('').replace(/[^A-Z0-9]/g, '');
  for (const ln of lines) {
    // izvirni žetoni (velike črke, samo alfanumerično) – fix() je 1:1 preslikava
    const orig = ln.text.toUpperCase().replace(/\*/g, ' ').replace(/\b(VIN|FIN|NO)(?=[A-Z0-9]{17})/g, '$1 ')
      .split(/\s+/).map((t) => t.split('').filter((c) => /[A-Z0-9]/.test(c) || c in VIN_FIX).join('')).filter(Boolean);
    const strs = new Map<string, [number, string]>(); // niz -> [kazen, izvirnik]
    for (let i = 0; i < orig.length; i++) {
      let acc = '';
      for (let j = i; j < Math.min(orig.length, i + 4); j++) {
        acc += orig[j];
        if (acc.length >= 16 && acc.length <= 20) {
          const f = fix(acc);
          const prev = strs.get(f);
          if (!prev || prev[0] > (j - i) * 0.04) strs.set(f, [(j - i) * 0.04, acc]);
        }
        if (acc.length > 20) break;
      }
    }
    for (const [raw, [pen0, src]] of strs) {
      // »besede« (MITSUBISHI -> M1TSUB1SH1, CORPORATION) imajo veliko I/O, VIN pa nobenega
      const io = (src.match(/[IO]/g) ?? []).length;
      const pen = pen0 + (io >= 2 ? 0.3 * (io - 1) : 0);
      const conf = ln.conf / 100 - pen;
      const windows = raw.length === 17 ? [raw] : [];
      if (raw.length > 17) for (let i = 0; i + 17 <= raw.length; i++) windows.push(raw.slice(i, i + 17));
      for (let v of windows) {
        if ((v.match(/\d/g) ?? []).length < 3) continue; // VIN ima vedno nekaj števk
        // ISO 3779: zadnji 4 znaki so vedno števke -> popravi podobne črke, sicer zavrzi
        const tail = v.slice(13).split('').map((c) => TAIL_DIGIT[c] ?? c).join('');
        if (!/^\d{4}$/.test(tail)) continue;
        v = v.slice(0, 13) + tail;
        const extra = raw.length === 17 ? 0.15 : -0.08 * (raw.length - 17);
        const sc = vinScore(v, conf);
        if (sc >= 0) cands.push({ v, s: sc + extra });
        const fw = fixWmi(v);
        if (fw !== v) cands.push({ v: fw, s: vinScore(fw, conf) + extra + 0.05 });
        if (/^[1-5]/.test(v) && !vinCheckOk(v)) {
          const r = repairCheckDigit(v);
          if (r) cands.push({ v: r, s: vinScore(r, conf) + extra - 0.1 });
        }
      }
      // 16 znakov: manjka en znak – vstavi samo, če se izide kontrolna številka
      if (raw.length === 16 && /^[1-5]/.test(raw)) {
        for (let i = 0; i <= 16; i++) for (const ch of VIN_CHARS) {
          const v = raw.slice(0, i) + ch + raw.slice(i);
          if (vinCheckOk(v)) cands.push({ v, s: vinScore(v, conf) - 0.35 });
        }
      }
    }
  }
  return cands;
}

/* ------------------------------------------------------------------ */
/* Registrska številka (Slovenija + splošno)                          */
/* ------------------------------------------------------------------ */

export const SI_REGIONS = ['CE', 'GO', 'KK', 'KP', 'KR', 'LJ', 'MB', 'MS', 'NM', 'PO', 'SG'];
const DIGIT_LIKE: Record<string, string> = { O: '0', Q: '0', I: '1' };
const LETTER_LIKE: Record<string, string> = { '0': 'O', '1': 'I', '2': 'Z', '5': 'S', '8': 'B', '6': 'G', '7': 'T', '4': 'A' };
const LETTER_LIKE_SAFE: Record<string, string> = { '0': 'O' };

/** Oblikuje slovensko tablico: »LJ AB-123«. */
export function formatPlate(raw: string) {
  const s = raw.toUpperCase().replace(/[^A-Z0-9-]/g, '');
  const reg = SI_REGIONS.find((r) => s.startsWith(r));
  if (!reg) return raw.toUpperCase().replace(/\s+/g, ' ').trim();
  let rest = s.slice(2).replace(/^-+/, '');
  if (!rest.includes('-') && rest.length === 5) {
    if (/^[A-Z][A-Z0-9]\d{3}$/.test(rest)) rest = rest.slice(0, 2) + '-' + rest.slice(2);
    else if (/^\d{3}[A-Z]{2}$/.test(rest)) rest = rest.slice(0, 3) + '-' + rest.slice(3);
    else if (/^\d{2}[A-Z0-9]{3}$/.test(rest)) rest = rest.slice(0, 2) + '-' + rest.slice(2);
  }
  return `${reg} ${rest}`;
}

function plateCandidates(lines: Line[]) {
  const cands: { v: string; s: number }[] = [];
  const all = lines.map((l) => l.text).join(' ');
  const cl = (t: string) => t.toUpperCase().replace(/[^A-Z0-9-]/g, '');
  const regBoxes = lines.filter((l) => l.box && SI_REGIONS.includes(cl(l.text)));
  /** vrstica, ki ima levo ob sebi samostojno kodo regije (npr. »MB« | »GOJA33«) */
  const hasRegionLeft = (l: Line) => !!l.box && regBoxes.some((r) => r !== l && Math.abs(r.box!.cy - l.box!.cy) < l.box!.h * 0.6 && r.box!.cx < l.box!.cx && (l.box!.cx - l.box!.w / 2) - (r.box!.cx + r.box!.w / 2) < l.box!.h * 2.5);
  for (const ln of [...lines.filter((l) => !hasRegionLeft(l)), { text: all, conf: Math.min(...lines.map((l) => l.conf), 100) }]) {
    let t = ln.text.toUpperCase().replace(/[—–_=~]/g, '-').replace(/[^A-Z0-9\- ]/g, ' ').replace(/\bSLO\b/g, ' ').trim();
    t = t.replace(/^(SL0|SL|5L0)\s+/, '');
    const compact = t.replace(/\s+/g, '');
    // začetki besed – koda regije mora biti na začetku besede (ne »CORPORATION« -> »PO«)
    const starts = new Set<number>();
    { let pos = 0; for (const w of t.split(/\s+/)) { starts.add(pos); pos += w.length; } }
    // poišči kodo regije (tudi z zamenjavami 0/O, 1/I …)
    for (let i = 0; i < compact.length - 3; i++) {
      if (!starts.has(i)) continue;
      const two = compact.slice(i, i + 2).split('').map((c) => LETTER_LIKE[c] ?? c).join('');
      const reg = SI_REGIONS.find((r) => r === two);
      if (!reg) continue;
      let rest = compact.slice(i + 2);
      // grb med regijo in številko se pogosto prebere kot en odvečen znak
      const options = [rest, rest.slice(1)];
      for (let o of options) {
        o = o.replace(/^-+/, '');
        const m = o.match(/^([A-Z0-9]{1,4})-?([A-Z0-9]{1,4})/);
        if (!m) continue;
        const body = m[0];
        const len = body.replace('-', '').length;
        if (len < 4 || len > 6) continue;
        let sc = ln.conf / 100;
        if (body.includes('-')) sc += 0.25;
        if (/^[A-Z0-9]{2}-\d{3}$/.test(body) || /^\d{3}-[A-Z]{2}$/.test(body) || /^\d{2}-[A-Z0-9]{3}$/.test(body)) sc += 0.25;
        if (o === rest) sc += 0.05;
        if (i === 0) sc += 0.15;
        cands.push({ v: formatPlate(reg + body), s: sc });
      }
      // osebna tablica (brez vezaja), npr. »LJ BUHTL«
      const pers = rest.match(/^[A-Z][A-Z0-9]{3,7}$/);
      if (pers) cands.push({ v: `${reg} ${pers[0]}`, s: ln.conf / 100 - 0.05 });
      const pers2 = rest.slice(1).match(/^[A-Z][A-Z0-9]{3,7}$/);
      if (pers2) cands.push({ v: `${reg} ${pers2[0]}`, s: ln.conf / 100 - 0.12 });
    }
  }
  // regija in številka v ločenih okvirjih (npr. »LJ« | »38-0KH«)
  const clean = (t: string) => t.toUpperCase().replace(/[^A-Z0-9-]/g, '');
  const regs = lines.filter((l) => SI_REGIONS.includes(clean(l.text)) && l.box);
  for (const b of lines) {
    const body = clean(b.text);
    const personal = /^[A-Z][A-Z0-9]{3,7}$/.test(body);
    if (!b.box || !(/^[A-Z0-9]{1,3}-[A-Z0-9]{2,3}$/.test(body) || personal) || SI_REGIONS.includes(body)) continue;
    let best: Line | null = null, bd = 1e9;
    for (const r of regs) {
      const d = Math.abs(r.box!.cy - b.box.cy) / b.box.h + Math.max(0, r.box!.cx - b.box.cx) / b.box.w * 3 + Math.abs(r.box!.cx - b.box.cx) / b.box.w;
      if (d < bd) { bd = d; best = r; }
    }
    if (best) cands.push({ v: personal ? `${clean(best.text)} ${body}` : formatPlate(clean(best.text) + body), s: Math.min(best.conf, b.conf) / 100 + (personal ? 0.15 : 0.3) - Math.min(0.3, bd * 0.05) });
  }
  // tuje tablice: najdaljši smiseln niz
  if (!cands.length) {
    for (const ln of lines) {
      const t = ln.text.toUpperCase().replace(/[^A-Z0-9\- ]/g, ' ').replace(/\s+/g, ' ').trim();
      const m = t.match(/[A-Z0-9][A-Z0-9 \-]{3,10}[A-Z0-9]/);
      if (m) cands.push({ v: m[0], s: ln.conf / 100 - 0.4 });
    }
  }
  return cands;
}

/** Številke/črke na pričakovanih mestih – »LJ 6S9-SI« -> »LJ 659-SI«. */
function normalizePlateChars(v: string) {
  const [reg, rest] = v.split(' ');
  if (!rest || !SI_REGIONS.includes(reg)) return v;
  const parts = rest.split('-');
  if (parts.length !== 2) return v;
  const [a, b] = parts;
  // XX-NNN: drugi del so števke
  if (a.length === 2 && b.length === 3 && /[A-Z]/.test(a[0]) && b.split('').filter((c) => /\d/.test(c)).length >= 2) {
    return `${reg} ${a}-${b.split('').map((c) => DIGIT_LIKE[c] ?? c).join('')}`;
  }
  // NNN-XX: prvi del števke, drugi črke
  if (a.length === 3 && b.length === 2 && a.split('').filter((c) => /\d/.test(c)).length >= 2) {
    return `${reg} ${a.split('').map((c) => DIGIT_LIKE[c] ?? c).join('')}-${b.split('').map((c) => LETTER_LIKE_SAFE[c] ?? c).join('')}`;
  }
  return v;
}

/* ------------------------------------------------------------------ */
/* Glavna funkcija                                                    */
/* ------------------------------------------------------------------ */

function invertC(src: HTMLCanvasElement) {
  const c = toCanvas(src);
  const g = c.getContext('2d', { willReadFrequently: true })!;
  const img = g.getImageData(0, 0, c.width, c.height);
  for (let i = 0; i < img.data.length; i += 4) { img.data[i] = 255 - img.data[i]; img.data[i + 1] = 255 - img.data[i + 1]; img.data[i + 2] = 255 - img.data[i + 2]; }
  g.putImageData(img, 0, 0);
  return c;
}

/** Glasovanje po posameznih znakih med podobnimi 17-mestnimi kandidati. */
function consensus(cands: { v: string; s: number }[]) {
  const ranked = vote(cands).filter(([v]) => v.length === 17);
  if (ranked.length < 2) return [];
  const [best] = ranked[0];
  const near = ranked.filter(([v]) => { let d = 0; for (let i = 0; i < 17; i++) if (v[i] !== best[i]) d++; return d <= 3; });
  if (near.length < 2) return [];
  let out = '';
  for (let i = 0; i < 17; i++) {
    const m = new Map<string, number>();
    for (const [v, sc] of near) m.set(v[i], (m.get(v[i]) ?? 0) + sc);
    out += [...m.entries()].sort((a, b) => b[1] - a[1])[0][0];
  }
  if (out === best || !isValidVinFormat(out)) return [];
  const sc = vinScore(out, 0.5);
  return sc > 0 ? [{ v: out, s: sc + (vinCheckOk(out) ? 0.3 : 0) }] : [];
}

function vote(cands: { v: string; s: number }[]) {
  const by = new Map<string, number>();
  for (const c of cands) by.set(c.v, (by.get(c.v) ?? 0) + Math.max(0.01, c.s));
  return [...by.entries()].sort((a, b) => b[1] - a[1]);
}

export interface ScanOptions {
  /** ali je slika že izrez iz okvirja (true) ali cela fotografija (false) */
  cropped?: boolean;
  onProgress?: (p: number) => void;
}

export async function recognize(src: Src, kind: ScanKind, opts: ScanOptions = {}): Promise<OcrResult> {
  const t0 = performance.now();
  const e = await getEngine();
  const img = src instanceof HTMLCanvasElement ? src : toCanvas(src);
  const raw: string[] = [];
  const cands: { v: string; s: number }[] = [];
  const extract = kind === 'vin' ? vinCandidates : plateCandidates;
  const cropped = opts.cropped !== false;

  // prehodi: različne velikosti in kontrast; zasuk 180° samo če ni zadetka
  if (cropped && img.width / img.height >= 3) {
    const lines = await readDirect(e, img);
    raw.push('direct: ' + lines.map((l) => l.text).join(' / '));
    cands.push(...extract(lines).map((c) => ({ ...c, s: c.s * 0.9 })));
  }
  const passes: { im: () => HTMLCanvasElement; side: number; flip: boolean }[] = [
    { im: () => img, side: cropped ? 960 : 1280, flip: false },
    { im: () => stretch(img), side: cropped ? 1280 : 1600, flip: false },
    { im: () => img, side: cropped ? 640 : 960, flip: false },
    { im: () => img, side: cropped ? 960 : 1280, flip: true },
  ];
  const extra: typeof passes = [
    { im: () => stretch(img), side: cropped ? 1600 : 2000, flip: false },
    { im: () => invertC(stretch(img)), side: cropped ? 1280 : 1600, flip: false },
    { im: () => img, side: cropped ? 480 : 800, flip: false },
  ];
  for (let i = 0; i < passes.length; i++) {
    const p = passes[i];
    if (p.flip && cands.some((c) => c.s > 0.9)) break;
    const lines = await readAll(e, p.im(), p.side, p.flip);
    raw.push(lines.map((l) => l.text).join(' / '));
    cands.push(...extract(lines));
    opts.onProgress?.((i + 1) / passes.length);
    const ranked = vote(cands);
    if (ranked.length) {
      const [bv, bs] = ranked[0];
      const strong = kind === 'vin' ? (vinCheckOk(bv) && /^[1-5]/.test(bv)) || bs > 2.2 : bs > 2.2;
      if (i >= 1 && strong) break;
    }
  }
  // šibek rezultat -> dodatni prehodi
  if (!vote(cands)[0] || vote(cands)[0][1] < 1.6) {
    for (const p of extra) {
      const lines = await readAll(e, p.im(), p.side, p.flip);
      raw.push(lines.map((l) => l.text).join(' / '));
      cands.push(...extract(lines));
    }
  }
  if (kind === 'vin') cands.push(...consensus(cands));
  let ranked = vote(cands);
  if (kind === 'plate') ranked = vote(ranked.map(([v, s]) => ({ v: normalizePlateChars(v), s })));
  const top = ranked[0];
  const total = ranked.reduce((a, b) => a + b[1], 0) || 1;
  const value = top?.[0] ?? '';
  return {
    value,
    confidence: top ? Math.min(1, (top[1] / total) * 0.6 + Math.min(1, top[1] / 2) * 0.4) : 0,
    checkDigitOk: kind === 'vin' && value ? vinCheckOk(value) : undefined,
    raw,
    alternatives: ranked.slice(1, 4).map((r) => r[0]),
    ms: Math.round(performance.now() - t0),
  };
}
