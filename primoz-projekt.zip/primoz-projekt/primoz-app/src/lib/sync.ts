/**
 * Varnostna kopija v Google Drive – INKREMENTALNO.
 *
 * Vsak zapis ima updatedAt (ms) in deleted (tombstone). Ob kopiji se naložijo
 * samo zapisi, ki so bili dodani/spremenjeni/izbrisani po zadnji uspešni kopiji
 * (meta 'lastSyncAt'). Vsaka kopija je ena datoteka »delta-<čas>.json« v mapi
 * »Primož App« na uporabnikovem Google Drive (scope drive.file – app vidi samo
 * svoje datoteke). Obnova prebere vse delte po vrsti in jih združi
 * (zadnja sprememba zmaga).
 */
import { SocialLogin } from '@capgo/capacitor-social-login';
import type { Table } from 'dexie';
import { db, getMeta, setMeta, SYNC_TABLES, type SyncMeta, type SyncTable } from './db';
import { isNative } from './native';

// Google Cloud projekt »My Project 816« (rosy-rider-512612-m7), račun primozsvetelj@gmail.com – Web OAuth client
export const GOOGLE_WEB_CLIENT_ID: string =
  import.meta.env.VITE_GOOGLE_WEB_CLIENT_ID || '835365871524-i24iqiqj36175ag1pcieukp2ecakq4h8.apps.googleusercontent.com';
const SCOPE = 'https://www.googleapis.com/auth/drive.file';
const FOLDER_NAME = 'Primož App';
const DRIVE = 'https://www.googleapis.com/drive/v3';
const UPLOAD = 'https://www.googleapis.com/upload/drive/v3';

export interface DeltaFile {
  app: 'primoz-app';
  version: 1;
  kind: 'delta' | 'full';
  deviceId: string;
  from: number;
  to: number;
  records: Partial<Record<SyncTable, SyncMeta[]>>;
}

export class SyncError extends Error {
  constructor(message: string, public status = 0) { super(message); }
}

let initialized = false;
async function init() {
  if (initialized) return;
  if (!GOOGLE_WEB_CLIENT_ID) {
    throw new SyncError('Google Drive še ni nastavljen: v datoteko .env vpiši VITE_GOOGLE_WEB_CLIENT_ID (glej NAVODILA.md).');
  }
  await SocialLogin.initialize({ google: { webClientId: GOOGLE_WEB_CLIENT_ID, mode: 'online' } });
  initialized = true;
}

async function deviceId() {
  let id = await getMeta<string>('deviceId', '');
  if (!id) {
    id = Math.random().toString(36).slice(2, 10);
    await setMeta('deviceId', id);
  }
  return id;
}

/** Prijava v Google (interaktivno) in pridobitev dostopnega žetona za Drive. */
export async function connectGoogle(silent = false): Promise<string> {
  await init();
  const res = await SocialLogin.login({
    provider: 'google',
    options: silent
      ? { scopes: [SCOPE], style: 'bottom', filterByAuthorizedAccounts: true, autoSelectEnabled: true }
      : { scopes: [SCOPE], ...(isNative ? {} : { prompt: 'select_account' as const }) },
  });
  const r = res.result as { accessToken?: { token: string } | null; profile?: { email?: string | null } };
  const token = r.accessToken?.token;
  if (!token) throw new SyncError('Google ni vrnil dostopa do Drive. Poskusi znova in dovoli dostop.');
  await setMeta('gToken', { token, exp: Date.now() + 50 * 60 * 1000 });
  if (r.profile?.email) await setMeta('gEmail', r.profile.email);
  return token;
}

export async function disconnectGoogle() {
  try {
    await init();
    await SocialLogin.logout({ provider: 'google' });
  } catch { /* ignore */ }
  await setMeta('gToken', null);
  await setMeta('gEmail', '');
  await setMeta('driveFolderId', '');
}

async function token(interactive: boolean): Promise<string> {
  const cached = await getMeta<{ token: string; exp: number } | null>('gToken', null);
  if (cached && cached.exp > Date.now() + 60000) return cached.token;
  return connectGoogle(!interactive);
}

async function api(path: string, init: RequestInit & { tok: string }, base = DRIVE) {
  const { tok, ...rest } = init;
  const r = await fetch(base + path, { ...rest, headers: { ...(rest.headers ?? {}), Authorization: `Bearer ${tok}` } });
  if (r.status === 401) {
    await setMeta('gToken', null);
    throw new SyncError('Prijava v Google je potekla. Poskusi znova.');
  }
  if (!r.ok) throw new SyncError(`Google Drive napaka ${r.status}: ${(await r.text()).slice(0, 160)}`, r.status);
  return r;
}

async function folderId(tok: string): Promise<string> {
  const cached = await getMeta<string>('driveFolderId', '');
  if (cached) {
    try {
      const r = await api(`/files/${cached}?fields=id,trashed`, { tok });
      const j = await r.json();
      if (!j.trashed) return cached;
    } catch (e) {
      // mapo poišči/ustvari znova samo, če res ne obstaja več
      if (!(e instanceof SyncError) || (e.status !== 404 && e.status !== 403)) throw e;
    }
  }
  const q = encodeURIComponent(`name='${FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false`);
  const list = await (await api(`/files?q=${q}&fields=files(id)&spaces=drive`, { tok })).json();
  let id: string = list.files?.[0]?.id;
  if (!id) {
    const r = await api('/files?fields=id', {
      tok, method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' }),
    });
    id = (await r.json()).id;
  }
  await setMeta('driveFolderId', id);
  return id;
}

/** Zapisi, spremenjeni po zadnji kopiji. */
export async function collectChanges(since: number) {
  const records: Partial<Record<SyncTable, SyncMeta[]>> = {};
  let count = 0;
  for (const t of SYNC_TABLES) {
    const rows = await (db[t] as Table<SyncMeta, string>).where('updatedAt').above(since).toArray();
    if (rows.length) {
      records[t] = rows;
      count += rows.length;
    }
  }
  return { records, count };
}

export async function pendingCount() {
  const since = await getMeta<number>('lastSyncAt', 0);
  return (await collectChanges(since)).count;
}

function stamp(ms: number) {
  const d = new Date(ms);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

export interface BackupResult { uploaded: number; bytes: number; fileName?: string }

/** Naloži samo nove/spremenjene zapise. */
export async function backupNow(interactive = true): Promise<BackupResult> {
  const since = await getMeta<number>('lastSyncAt', 0);
  const to = Date.now();
  const { records, count } = await collectChanges(since);
  if (count === 0) {
    await setMeta('lastBackupAt', to);
    return { uploaded: 0, bytes: 0 };
  }
  const tok = await token(interactive);
  const folder = await folderId(tok);
  const delta: DeltaFile = { app: 'primoz-app', version: 1, kind: since === 0 ? 'full' : 'delta', deviceId: await deviceId(), from: since, to, records };
  const body = JSON.stringify(delta);
  const name = `delta-${stamp(to)}-${delta.deviceId}.json`;
  const boundary = 'primoz' + Math.random().toString(36).slice(2);
  const multipart =
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n` +
    JSON.stringify({ name, parents: [folder], mimeType: 'application/json', appProperties: { to: String(to) } }) +
    `\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${body}\r\n--${boundary}--`;
  await api('/files?uploadType=multipart&fields=id,size', {
    tok, method: 'POST', headers: { 'Content-Type': `multipart/related; boundary=${boundary}` }, body: multipart,
  }, UPLOAD);
  const bytes = new Blob([body]).size;
  // šele po uspešnem nalaganju premakni oznako
  await setMeta('lastSyncAt', to);
  await setMeta('lastBackupAt', to);
  await setMeta('backupBytes', (await getMeta<number>('backupBytes', 0)) + bytes);
  return { uploaded: count, bytes, fileName: name };
}

/** Združi zapise (zadnja sprememba zmaga). Ne spremeni updatedAt. */
export async function mergeRecords(records: Partial<Record<SyncTable, SyncMeta[]>>) {
  let applied = 0;
  await db.transaction('rw', SYNC_TABLES.map((t) => db[t]), async () => {
    for (const t of SYNC_TABLES) {
      const rows = records[t];
      if (!rows?.length) continue;
      const table = db[t] as Table<SyncMeta, string>;
      for (const row of rows) {
        const cur = await table.get(row.id);
        if (!cur || cur.updatedAt < row.updatedAt) {
          await table.put(row);
          applied++;
        }
      }
    }
  });
  return applied;
}

/** Obnovi iz vseh delt na Drive. */
export async function restoreFromDrive(): Promise<{ files: number; applied: number }> {
  const tok = await token(true);
  const folder = await folderId(tok);
  // lokalne spremembe, ki še niso v oblaku, morajo ostati »čakajoče«
  const pendingBefore = (await collectChanges(await getMeta<number>('lastSyncAt', 0))).count;
  const q = encodeURIComponent(`'${folder}' in parents and trashed=false and name contains 'delta-'`);
  const files: { id: string; name: string }[] = [];
  let pageToken = '';
  do {
    const r = await (await api(`/files?q=${q}&orderBy=name&pageSize=200&fields=nextPageToken,files(id,name)${pageToken ? '&pageToken=' + pageToken : ''}`, { tok })).json();
    files.push(...(r.files ?? []));
    pageToken = r.nextPageToken ?? '';
  } while (pageToken);
  files.sort((a, b) => a.name.localeCompare(b.name));
  let applied = 0;
  let maxTo = 0;
  for (const f of files) {
    const d = (await (await api(`/files/${f.id}?alt=media`, { tok })).json()) as DeltaFile;
    if (d.app !== 'primoz-app') continue;
    applied += await mergeRecords(d.records);
    maxTo = Math.max(maxTo, d.to);
  }
  if (maxTo && pendingBefore === 0) await setMeta('lastSyncAt', Math.max(maxTo, await getMeta<number>('lastSyncAt', 0)));
  return { files: files.length, applied };
}

/** Polna lokalna kopija (JSON) za računalnik. */
export async function fullSnapshot(): Promise<DeltaFile> {
  const { records } = await collectChanges(-1);
  return { app: 'primoz-app', version: 1, kind: 'full', deviceId: await deviceId(), from: 0, to: Date.now(), records };
}

/** Samodejna kopija ob zagonu: največ enkrat na 24 ur, brez pojavnih oken. */
export async function autoBackupIfDue() {
  try {
    if (!(await getMeta('autoBackup', false))) return;
    if (!(await getMeta<string>('gEmail', ''))) return;
    const last = await getMeta<number>('lastBackupAt', 0);
    if (Date.now() - last < 24 * 3600 * 1000) return;
    await backupNow(false);
  } catch (e) {
    console.warn('Samodejna kopija ni uspela', e);
  }
}
