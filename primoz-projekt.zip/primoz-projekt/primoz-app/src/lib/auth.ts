import { getMeta, setMeta } from './db';

/**
 * Lokalni podatki profila na tej napravi (slika, telefon).
 * Ime in e-pošta pripadata strežniškemu računu (src/lib/account.ts) – ureja ju administrator.
 */
export interface Profile {
  name: string;
  email: string;
  phone: string;
  avatar: string;
}

export const getProfile = () => getMeta<Profile | null>('profile', null);

export async function updateProfile(changes: Partial<Pick<Profile, 'phone' | 'avatar'>>) {
  const p = (await getProfile()) ?? { name: '', email: '', phone: '', avatar: '' };
  await setMeta('profile', { ...p, ...changes });
}
