/**
 * Strežniški račun (Supabase).
 *
 * Prijava: e-pošta + geslo (samo z internetom). Ob prijavi telefon ustvari naključen
 * 256-bitni ključ naprave, ga enkrat pošlje strežniku (HTTPS) in ga shrani kot
 * NEIZVOZLJIV CryptoKey – JavaScript ga ne more več prebrati, le podpisovati.
 * Vsak nadaljnji zahtevek je podpisan (HMAC-SHA256) in ima naraščajoč števec,
 * zato prestrežen ali ponovljen zahtevek ne deluje.
 *
 * Seja nima roka trajanja – uporabnik ostane prijavljen, dokler ga admin ne
 * onemogoči/odjavi. Brez interneta deluje največ `offlineDays` dni od zadnje potrditve.
 */
import { Capacitor, registerPlugin } from '@capacitor/core';
import { Device } from '@capacitor/device';
import { db, getMeta, setMeta } from './db';

const URL = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.replace(/\/$/, '') ?? '';
const KEY = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined) ?? '';
export const serverConfigured = !!URL && !!KEY;
export const APP_VERSION = '1.3.4';

export interface CatalogEntry {
  id: string;
  brand: string;
  model: string;
  engine_capacity: string;
  engine_name: string;
  engine_code: string;
  fuel: string;
  power: string;
  period: string;
  engine_oil_spec: string;
  engine_oil_capacity: string;
  coolant: string;
  brake_fluid: string;
  transmission_oil: string;
  ac_refrigerant: string;
  known_faults: string;
  recalls: string;
  tsb: string;
  tyre_pressure: string;
  tyre_sizes: string;
  row_status: string;
  warnings: string;
}

export interface UpdateManifest { version: string; url: string; checksum?: string; notes?: string }

export type LockStatus = 'ok' | 'disabled' | 'blocked' | 'app_locked' | 'integrity_failed' | 'offline_expired';

export interface MsgButton { id: string; label: string; style: 'primary' | 'secondary' | 'danger'; action: 'close' | 'later' | 'link' | 'exit'; url?: string }
export interface ServerMessage { id: string; title: string; body: string; kind: 'info' | 'warning' | 'important'; buttons: MsgButton[] }

export interface Session {
  deviceId: string;
  account: { id: string; email: string; name: string; must_change_pw: boolean };
  status: LockStatus;
  reason: string;
  offlineDays: number;
  /** čas strežnika in lokalni čas zadnje uspešne potrditve */
  lastOkServer: number;
  lastOkLocal: number;
  messages: ServerMessage[];
  pendingAnswers: { m: string; b: string }[];
}

interface IntegrityInfo { cert?: string; debuggable?: boolean; rooted?: boolean; emulator?: boolean; installer?: string }
const Integrity = registerPlugin<{ getInfo(): Promise<IntegrityInfo> }>('Integrity');

export class ServerError extends Error {
  constructor(public code: string, public info: Record<string, unknown> = {}) { super(code); }
}

/* ------------------------------------------------------------ omrežje */

async function rpc<T = Record<string, unknown>>(fn: string, body: unknown, timeoutMs = 15000): Promise<T> {
  if (!serverConfigured) throw new ServerError('not_configured');
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  let res: Response;
  try {
    res = await fetch(`${URL}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      // nov tip ključa (sb_publishable_…) gre samo v glavo apikey, star (JWT) tudi v Authorization
      headers: { 'Content-Type': 'application/json', apikey: KEY, ...(KEY.startsWith('sb_') ? {} : { Authorization: `Bearer ${KEY}` }) },
      body: JSON.stringify(body),
      signal: ctl.signal,
      cache: 'no-store',
      credentials: 'omit',
      referrerPolicy: 'no-referrer',
    });
  } catch {
    throw new ServerError('network');
  } finally {
    clearTimeout(t);
  }
  if (res.status >= 500 || res.status === 0) throw new ServerError('network');
  const j = await res.json().catch(() => null);
  if (!res.ok || !j) throw new ServerError('server', { status: res.status });
  return j as T;
}

export async function latestUpdate(): Promise<UpdateManifest | null> {
  const r = await rpc<UpdateManifest | null>('app_latest_update', { p_app: 'app', p_version: APP_VERSION });
  return r?.version && r.url ? r : null;
}

/* ------------------------------------------------------------ naprava */

async function installId() {
  let id = await getMeta<string>('installId', '');
  if (!id) { id = crypto.randomUUID(); await setMeta('installId', id); }
  return id;
}

export async function deviceInfo() {
  const [info, id, integrity] = await Promise.all([
    Device.getInfo().catch(() => null),
    Device.getId().catch(() => ({ identifier: '' })),
    Capacitor.isNativePlatform() ? Integrity.getInfo().catch(() => ({} as IntegrityInfo)) : Promise.resolve({} as IntegrityInfo),
  ]);
  return {
    install_id: await installId(),
    hw_id: id.identifier || undefined,
    name: info?.name ?? '',
    manufacturer: info?.manufacturer ?? '',
    model: info?.model ?? (typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 60) : ''),
    platform: info?.platform ?? 'web',
    os_version: info?.osVersion ?? '',
    app_version: APP_VERSION,
    integrity,
  };
}

/* ------------------------------------------------------------ podpisovanje */

let queue: Promise<unknown> = Promise.resolve();
/** zahtevki se pošiljajo zaporedno, da števec vedno narašča */
function serial<T>(fn: () => Promise<T>): Promise<T> {
  const p = queue.then(fn, fn);
  queue = p.catch(() => undefined);
  return p;
}

const hex = (buf: ArrayBuffer) => Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');

async function signedCall<T = Record<string, unknown>>(fn: string, action: string, x: Record<string, unknown> = {}): Promise<T> {
  return serial(async () => {
    const s = await getSession();
    const key = await getMeta<CryptoKey | null>('deviceKey', null);
    if (!s || !key) throw new ServerError('invalid_session');
    const prev = await getMeta<number>('ctr', 0);
    const ctr = Math.max(prev + 1, Date.now());
    await setMeta('ctr', ctr);
    const payload = JSON.stringify({ d: s.deviceId, c: ctr, a: action, x });
    const sig = hex(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(payload)));
    return rpc<T>(fn, { p_payload: payload, p_sig: sig });
  });
}

export async function searchCatalog(q: string, limit = 12): Promise<CatalogEntry[]> {
  const text = q.trim().slice(0, 100);
  if (!text) return [];
  const r = await signedCall<{ ok: boolean; items?: CatalogEntry[] }>('app_catalog_search', 'catalog_search', { q: text, limit });
  return r.ok ? (r.items ?? []) : [];
}

/* ------------------------------------------------------------ seja */

export const getSession = () => getMeta<Session | null>('session', null);
const saveSession = (s: Session | null) => setMeta('session', s);

export const LOGIN_ERRORS: Record<string, string> = {
  invalid_credentials: 'Napačna e-pošta ali geslo.',
  temporarily_locked: 'Preveč napačnih poskusov. Račun je začasno zaklenjen.',
  rate_limited: 'Preveč poskusov s tega omrežja. Poskusi kasneje.',
  account_disabled: 'Račun je onemogočen. Obrni se na administratorja.',
  device_blocked: 'Ta naprava je blokirana. Obrni se na administratorja.',
  device_limit: 'Za ta račun je dosežen največji dovoljeni broj naprav.',
  app_locked: 'Aplikacija je trenutno zaklenjena.',
  integrity_failed: 'Ta različica aplikacije ni originalna. Namesti uradno različico.',
  network: 'Za prijavo potrebuješ internetno povezavo.',
  not_configured: 'Strežnik še ni nastavljen.',
  server: 'Strežnik trenutno ni dosegljiv. Poskusi znova.',
  bad_request: 'Prijava ni uspela. Poskusi znova.',
};

export async function login(email: string, password: string): Promise<Session> {
  const raw = crypto.getRandomValues(new Uint8Array(32));
  const device = await deviceInfo();
  const r = await rpc<{ ok: boolean; error?: string; retry_after?: number; reason?: string; message?: string; device_id: string; account: Session['account']; server_time: number; offline_days: number; messages: ServerMessage[] }>(
    'app_login', { p_email: email.trim(), p_password: password, p_device: { ...device, secret: btoa(String.fromCharCode(...raw)) } },
  );
  if (!r.ok) {
    raw.fill(0);
    throw new ServerError(r.error ?? 'server', { retry_after: r.retry_after, reason: r.reason || r.message });
  }
  // neizvozljiv ključ – po uvozu surovih bajtov ni več mogoče prebrati
  const key = await crypto.subtle.importKey('raw', raw, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  raw.fill(0);
  await setMeta('deviceKey', key);
  await setMeta('ctr', 0);
  const s: Session = {
    deviceId: r.device_id, account: r.account, status: 'ok', reason: '', offlineDays: r.offline_days,
    lastOkServer: r.server_time, lastOkLocal: Date.now(), messages: r.messages ?? [], pendingAnswers: [],
  };
  await saveSession(s);
  return s;
}

export type CheckOutcome =
  | { kind: 'session'; session: Session; online: boolean }
  | { kind: 'signed_out'; reason: 'revoked' | 'invalid' | 'wiped' };

/** Preveri stanje pri strežniku. Brez interneta uporabi zadnje znano stanje (+ omejitev dni). */
export async function check(opts: { refreshMessages?: boolean } = {}): Promise<CheckOutcome> {
  const s = await getSession();
  if (!s) return { kind: 'signed_out', reason: 'invalid' };
  let r: { ok: boolean; error?: string; status?: string; reason?: string; account?: Session['account']; server_time?: number; offline_days?: number; messages?: ServerMessage[] };
  try {
    const integrity = Capacitor.isNativePlatform() ? await Integrity.getInfo().catch(() => undefined) : undefined;
    r = await signedCall('app_check', 'check', { app_version: APP_VERSION, ...(integrity ? { integrity } : {}) });
  } catch (e) {
    if (e instanceof ServerError && e.code === 'invalid_session') { await clearSession(); return { kind: 'signed_out', reason: 'invalid' }; }
    return { kind: 'session', session: await applyOffline(s), online: false };
  }
  if (!r.ok) {
    if (r.error === 'invalid_session' || r.error === 'replay') { await clearSession(); return { kind: 'signed_out', reason: 'invalid' }; }
    return { kind: 'session', session: await applyOffline(s), online: false };
  }
  if (r.status === 'revoked') { await clearSession(); return { kind: 'signed_out', reason: 'revoked' }; }
  if (r.status === 'wipe') { await wipeDevice(); return { kind: 'signed_out', reason: 'wiped' }; }
  const next: Session = {
    ...s,
    account: r.account ?? s.account,
    status: (r.status as LockStatus) ?? 'ok',
    reason: r.reason ?? '',
    offlineDays: r.offline_days ?? s.offlineDays,
    lastOkServer: r.server_time ?? s.lastOkServer,
    lastOkLocal: Date.now(),
    messages: opts.refreshMessages ? (r.messages ?? []) : s.messages.filter((m) => (r.messages ?? []).some((x) => x.id === m.id)),
  };
  await saveSession(next);
  if (s.reason === 'clock') reportClockTamper();
  if (next.pendingAnswers.length) flushAnswers();
  return { kind: 'session', session: next, online: true };
}

/** Brez povezave: po `offlineDays` dneh (ali če je bila ura prestavljena nazaj) zahtevaj internet. */
async function applyOffline(s: Session): Promise<Session> {
  if (s.status !== 'ok' && s.status !== 'offline_expired') return s;
  const now = Date.now();
  const tampered = now < s.lastOkLocal - 10 * 60_000;
  const expired = now - s.lastOkLocal > s.offlineDays * 86_400_000;
  const status: LockStatus = tampered || expired ? 'offline_expired' : 'ok';
  if (status !== s.status) {
    const next = { ...s, status, reason: tampered ? 'clock' : '' };
    await saveSession(next);
    return next;
  }
  return s;
}

export async function answerMessage(m: string, b: string, final: boolean) {
  const s = await getSession();
  if (!s) return;
  await saveSession({
    ...s,
    messages: final ? s.messages.filter((x) => x.id !== m) : s.messages,
    pendingAnswers: [...s.pendingAnswers, { m, b }],
  });
  await flushAnswers();
}

async function flushAnswers() {
  for (;;) {
    const s = await getSession();
    const a = s?.pendingAnswers[0];
    if (!s || !a) return;
    try {
      await signedCall('app_answer', 'answer', a);
    } catch {
      return; // ponovno ob naslednjem preverjanju
    }
    const cur = await getSession();
    if (cur) await saveSession({ ...cur, pendingAnswers: cur.pendingAnswers.slice(1) });
  }
}

export async function changePassword(oldPw: string, newPw: string) {
  const r = await signedCall<{ ok: boolean; error?: string }>('app_password', 'password', { old: oldPw, new: newPw });
  if (!r.ok) throw new ServerError(r.error ?? 'server');
  const s = await getSession();
  if (s) await saveSession({ ...s, account: { ...s.account, must_change_pw: false } });
}

export async function logout() {
  try { await signedCall('app_signout', 'signout'); } catch { /* brez povezave – seja se vseeno izbriše lokalno */ }
  await clearSession();
}

async function clearSession() {
  await setMeta('deviceKey', null);
  await setMeta('session', null);
  await setMeta('ctr', 0);
}

/** Admin je naročil izbris podatkov na tej napravi (npr. izgubljen telefon). */
async function wipeDevice() {
  try { await signedCall('app_signout', 'signout'); } catch { /* ignore */ }
  const hw = await getMeta<string>('installId', '');
  await db.transaction('rw', db.tables, async () => { for (const t of db.tables) await t.clear(); });
  try { localStorage.clear(); sessionStorage.clear(); } catch { /* ignore */ }
  if (hw) await setMeta('installId', hw);
  await setMeta('wipedAt', Date.now());
}

export async function reportClockTamper() {
  try { await signedCall('app_report', 'report', { kind: 'clock_tamper', info: new Date().toISOString() }); } catch { /* ignore */ }
}
