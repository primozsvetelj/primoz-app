import { useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import { useNav } from '../ui/nav';
import { FormDeleteButton } from '../ui/actions';
import { Screen, TopBar, Label, TextField, Button, ChipGroup, ColorPicker, MonthCalendar, TimeSheet, TimeFieldButton, VehicleSearchField } from '../ui/components';
import { db, save, getMeta, REPEAT_LABEL, REMIND_LABEL, type EventColor, type Repeat, type RemindBefore } from '../lib/db';
import { useVehicles } from '../lib/hooks';
import { parseISO, todayISO } from '../lib/dates';
import { requestNotificationPermission, rescheduleAll } from '../lib/notifications';
import { firstAvailableEvening } from '../lib/scheduling';

const opts = <T extends string>(m: Record<T, string>) => (Object.keys(m) as T[]).map((id) => ({ id, label: m[id] }));

export function ReminderFormScreen({ vehicleId: fixedVehicle, id, date: initialDate }: { vehicleId?: string; id?: string; date?: string }) {
  const { back, toast } = useNav();
  const vehicles = useVehicles() ?? [];
  const [vehicleId, setVehicleId] = useState(fixedVehicle ?? '');
  const [title, setTitle] = useState('');
  const [color, setColor] = useState<EventColor>('violet');
  const [date, setDate] = useState(initialDate ?? '');
  const [time, setTime] = useState('20:00');
  const [repeat, setRepeat] = useState<Repeat>('once');
  const [remind, setRemind] = useState<RemindBefore>('1d');
  const start = parseISO(initialDate ?? todayISO());
  const [month, setMonth] = useState({ y: start.getFullYear(), m: start.getMonth() });
  const [timeOpen, setTimeOpen] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!id) return;
    db.reminders.get(id).then((r) => {
      if (!r) return;
      setTitle(r.title); setColor(r.color); setDate(r.date); setTime(r.time); setRepeat(r.repeat); setRemind(r.remind); setVehicleId(r.vehicleId);
      const d = parseISO(r.date); setMonth({ y: d.getFullYear(), m: d.getMonth() });
    });
  }, [id]);

  useEffect(() => {
    if (!id && initialDate) firstAvailableEvening(initialDate).then(setTime);
  }, [id, initialDate]);

  const pickDate = async (value: string) => {
    setDate(value);
    setErrors((x) => ({ ...x, date: '' }));
    if (!id) setTime(await firstAvailableEvening(value));
    setTimeOpen(true);
  };


  const submit = async () => {
    const e: Record<string, string> = {};
    if (!title.trim()) e.title = 'Vpiši ime dogodka.';
    if (!vehicleId) e.vehicle = 'Izberi vozilo.';
    if (!date) e.date = 'Izberi datum.';
    setErrors(e);
    if (Object.values(e).some(Boolean)) return;
    await save(db.reminders, { id, vehicleId, title: title.trim(), color, date, time, repeat, remind, done: 0 });
    if (await getMeta('notifications', true)) await requestNotificationPermission();
    await rescheduleAll();
    toast(id ? 'Spremembe shranjene' : 'Opomnik shranjen');
    back();
  };

  return (
    <Screen>
      <TopBar close title={id ? 'Uredi opomnik' : 'Nov opomnik'} obrazec actions={<FormDeleteButton kind="reminder" id={id} label="opomnik" />} />
      <div className="scroll">
        <Label>Vozilo</Label>
        <VehicleSearchField vehicles={vehicles} value={vehicleId} onChange={(v) => { setVehicleId(v); setErrors((x) => ({ ...x, vehicle: '' })); }} error={errors.vehicle} />
        <Label>Ime dogodka v koledarju</Label>
        <TextField value={title} onChange={(v) => { setTitle(v); setErrors((x) => ({ ...x, title: '' })); }} placeholder="npr. Podaljšanje registracije" error={errors.title} />
        <Label>Barva dogodka</Label>
        <ColorPicker value={color} onChange={setColor} />
        <Label>Datum</Label>
        <MonthCalendar value={date} month={month} onMonth={setMonth} onChange={pickDate} />
        {errors.date && <div className="errtext">{errors.date}</div>}
        <Label>Ura</Label>
        <TimeFieldButton date={date} time={time} onClick={() => date ? setTimeOpen(true) : setErrors((x) => ({ ...x, date: 'Najprej izberi datum.' }))} />
        <Label>Ponovitev</Label>
        <ChipGroup value={repeat} options={opts(REPEAT_LABEL)} onChange={setRepeat} />
        <Label>Opomni me</Label>
        <ChipGroup value={remind} options={opts(REMIND_LABEL)} onChange={setRemind} />
      </div>
      <div className="footer">
        <Button icon={<Check size={20} />} onClick={submit}>{id ? 'Shrani spremembe' : 'Shrani opomnik'}</Button>
      </div>
      <TimeSheet open={timeOpen} date={date} value={time} onClose={() => setTimeOpen(false)} onConfirm={(t) => { setTime(t); setTimeOpen(false); }} />
    </Screen>
  );
}
