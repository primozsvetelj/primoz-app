import { useEffect, useState } from 'react';
import { Check, Plus, Settings2 } from 'lucide-react';
import { TypeManagerSheet } from '../ui/TypeManager';
import { useNav } from '../ui/nav';
import { FormDeleteButton } from '../ui/actions';
import { Screen, TopBar, Label, TextField, Button, Radio, Sheet, VehicleSearchField } from '../ui/components';
import { FluidGlyph } from '../ui/icons';
import { db, save, type FluidIcon } from '../lib/db';
import { useFluidTypes, useVehicles } from '../lib/hooks';

export function FluidFormScreen({ vehicleId: fixedVehicle, id, copyFrom }: { vehicleId?: string; id?: string; copyFrom?: string }) {
  const { back, toast } = useNav();
  const types = useFluidTypes() ?? [];
  const vehicles = useVehicles() ?? [];
  const [vehicleId, setVehicleId] = useState(fixedVehicle ?? '');
  const [typeId, setTypeId] = useState('');
  const [desc, setDesc] = useState('');
  const [newType, setNewType] = useState(false);
  const [newName, setNewName] = useState('');
  const [manage, setManage] = useState(false);
  const [newIcon, setNewIcon] = useState<FluidIcon>('drop');
  const [err, setErr] = useState('');

  useEffect(() => {
    const src = id ?? copyFrom;
    if (!src) return;
    db.fluids.get(src).then((f) => {
      if (!f) return;
      setTypeId(f.typeId); setDesc(f.description);
      if (!fixedVehicle) setVehicleId(f.vehicleId);
    });
  }, [id, copyFrom, fixedVehicle]);


  const submit = async () => {
    if (!vehicleId) return setErr('Izberi vozilo.');
    if (!typeId) return setErr('Izberi vrsto tekočine.');
    await save(db.fluids, { id, vehicleId, typeId, description: desc.trim() });
    toast(id ? 'Spremembe shranjene' : 'Tekočina dodana');
    back();
  };

  const addType = async () => {
    const name = newName.trim();
    if (!name) return;
    const exists = types.find((t) => t.name.toLowerCase() === name.toLowerCase());
    const t = exists ?? (await save(db.fluidTypes, { name, icon: newIcon, builtin: 0 }));
    setTypeId(t.id); setNewType(false); setNewName(''); setErr('');
    if (!exists) toast('Nova vrsta dodana v knjižnico');
  };

  return (
    <Screen>
      <TopBar close title={id ? 'Uredi tekočino' : 'Nova tekočina'} obrazec actions={<FormDeleteButton kind="fluid" id={id} label="tekočino" />} />
      <div className="scroll">
        {!fixedVehicle && (
          <>
            <Label>Vozilo</Label>
            <VehicleSearchField vehicles={vehicles} value={vehicleId} onChange={(v) => { setVehicleId(v); setErr(''); }} />
          </>
        )}
        <Label>Vrsta tekočine</Label>
        <div className="card" style={{ padding: 4, background: 'var(--bg-field)' }}>
          {types.map((t) => (
            <button key={t.id} className="row" onClick={() => { setTypeId(t.id); setErr(''); }}
              style={{ width: '100%', padding: '10px 12px', borderRadius: 10, background: typeId === t.id ? 'var(--bg-selected)' : 'transparent', textAlign: 'left', gap: 12 }}>
              <FluidGlyph icon={t.icon} size={22} />
              <span className={typeId === t.id ? 't-b15' : 't-r15'} style={{ flex: 1 }}>{t.name}</span>
              <Radio on={typeId === t.id} />
            </button>
          ))}
        </div>
        <button className="row cv t-b15" onClick={() => setNewType(true)}
          style={{ width: '100%', marginTop: 10, height: 46, border: '1px dashed var(--border)', borderRadius: 12, padding: '0 16px' }}>
          <Plus size={20} /> Dodaj novo vrsto tekočine
        </button>
        {types.some((t) => !t.builtin) && <button className="row cv t-b13" style={{ marginTop: 10, gap: 6 }} onClick={() => setManage(true)}><Settings2 size={16} />Uredi moje vrste</button>}
        <Label>Opis</Label>
        <TextField value={desc} onChange={setDesc} placeholder="npr. DOT 4" />
        {err && <div className="errtext">{err}</div>}
      </div>
      <div className="footer">
        <Button icon={id ? <Check size={20} /> : <Plus size={20} />} onClick={submit}>{id ? 'Shrani spremembe' : 'Dodaj tekočino'}</Button>
      </div>

      <TypeManagerSheet kind="fluidTypes" open={manage} onClose={() => setManage(false)} onDeleted={(tid) => { if (tid === typeId) setTypeId(''); }} />
      <Sheet open={newType} onClose={() => setNewType(false)} title="Nova vrsta tekočine"
        footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={() => setNewType(false)}>Prekliči</Button><Button style={{ flex: 1 }} icon={<Plus size={20} />} disabled={!newName.trim()} onClick={addType}>Dodaj vrsto</Button></>}>
        <Label>Ime vrste tekočine</Label>
        <TextField value={newName} onChange={setNewName} placeholder="npr. Olje diferenciala" autoFocus onEnter={addType} />
        <Label>Ikona</Label>
        <div className="chips">
          {(['oil', 'brake', 'gear', 'drop'] as FluidIcon[]).map((ic) => (
            <button key={ic} className={`chip lg ${newIcon === ic ? 'on' : ''}`} style={{ width: 52, justifyContent: 'center' }} onClick={() => setNewIcon(ic)}><FluidGlyph icon={ic} /></button>
          ))}
        </div>
        <div className="t-r13 c2" style={{ marginTop: 12 }}>Nova vrsta se shrani v knjižnico in je na voljo pri vseh vozilih.</div>
      </Sheet>
    </Screen>
  );
}
