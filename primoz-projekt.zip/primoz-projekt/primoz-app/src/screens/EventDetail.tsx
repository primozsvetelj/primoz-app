import { useLiveQuery } from 'dexie-react-hooks';
import { Pencil, Check, RotateCw, Trash2 } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, TopBar, Button } from '../ui/components';
import { useDelete } from '../ui/actions';
import { db, COLOR_LABEL, REPEAT_LABEL, REMIND_LABEL, patch, vehicleLabel, type EventColor } from '../lib/db';
import { fmtDate, fmtShort, advance, nextOccurrence, todayISO } from '../lib/dates';
import { rescheduleAll } from '../lib/notifications';

/** Enotna glava podrobnosti: svinčnik (uredi) + rdeč koš (izbriši) – kot pri vozilu. */
export function EditDelete({ label, onEdit, onDelete }: { label: string; onEdit: () => void; onDelete: () => void }) {
  return <>
    <button className="iconbtn violet" aria-label={`Uredi ${label}`} onClick={onEdit}><Pencil size={22} /></button>
    <button className="iconbtn danger" aria-label={`Izbriši ${label}`} onClick={onDelete}><Trash2 size={20} /></button>
  </>;
}

function ColorValue({ c }: { c: EventColor }) {
  return <span className="row" style={{ gap: 8, justifyContent: 'flex-end' }}><span className="dot sm" style={{ background: c === 'violet' ? 'var(--violet)' : 'var(--orange)' }} />{COLOR_LABEL[c]}</span>;
}

export function ServiceDetailScreen({ id }: { id: string }) {
  const { push, back } = useNav();
  const remove = useDelete();
  const data = useLiveQuery(async () => {
    const s = await db.services.get(id);
    if (!s) return null;
    return { s, v: await db.vehicles.get(s.vehicleId), t: await db.serviceTypes.get(s.typeId) };
  }, [id]);
  if (data === undefined) return <Screen><TopBar title="" /></Screen>;
  if (!data || data.s.deleted) return <Screen><TopBar title="Servis" /><div className="empty">Servis ne obstaja več.</div></Screen>;
  const { s, v, t } = data;

  const del = async () => { if (await remove.service(id)) back(); };

  return (
    <Screen>
      <TopBar title={s.title} actions={<EditDelete label="servis" onEdit={() => push({ name: 'serviceForm', id })} onDelete={del} />} />
      <div className="subtitle">{v?.owner} · {vehicleLabel(v)}{v?.plate ? ' · ' + v.plate : ''}</div>
      <div className="scroll">
        <div className="card" style={{ padding: '14px 16px 4px' }}>
          <div className="t-kartica" style={{ marginBottom: 4 }}>Podatki servisa</div>
          <div className="kv"><span className="k">Datum</span><span className="v">{fmtDate(s.date)}</span></div>
          <div className="kv"><span className="k">Ura</span><span className="v">{s.time}</span></div>
          <div className="kv"><span className="k">Vrsta servisa</span><span className="v">{t?.name ?? '—'}</span></div>
          <div className="kv"><span className="k">Barva</span><span className="v"><ColorValue c={s.color} /></span></div>
        </div>
        {v && (
          <button className="btn ghost s" style={{ marginTop: 12 }} onClick={() => push({ name: 'vehicle', id: v.id })}>Odpri vozilo</button>
        )}
      </div>
      <div className="footer">
        <Button icon={<RotateCw size={18} />} onClick={() => push({ name: 'serviceForm', copyFrom: id, vehicleId: s.vehicleId })}>Ponovi</Button>
      </div>
    </Screen>
  );
}

export function ReminderDetailScreen({ id, occ }: { id: string; occ?: string }) {
  const { push, back, toast } = useNav();
  const remove = useDelete();
  const data = useLiveQuery(async () => {
    const r = await db.reminders.get(id);
    if (!r) return null;
    return { r, v: await db.vehicles.get(r.vehicleId) };
  }, [id]);
  if (data === undefined) return <Screen><TopBar title="" /></Screen>;
  if (!data || data.r.deleted) return <Screen><TopBar title="Opomnik" /><div className="empty">Opomnik ne obstaja več.</div></Screen>;
  const { r, v } = data;
  const shownDate = occ ?? nextOccurrence(r, todayISO()) ?? r.date;

  const del = async () => { if (await remove.reminder(id)) back(); };

  const done = async () => {
    const prev = { date: r.date, done: r.done };
    if (r.repeat === 'once') {
      await patch(db.reminders, id, { done: 1 });
      toast('Označeno kot opravljeno', { label: 'Razveljavi', run: async () => { await patch(db.reminders, id, prev); await rescheduleAll(); } });
    } else {
      const next = advance(r, shownDate);
      if (next) await patch(db.reminders, id, { date: next });
      toast(`Opravljeno · naslednjič ${next ? fmtShort(next) : ''}`, { label: 'Razveljavi', run: async () => { await patch(db.reminders, id, prev); await rescheduleAll(); } });
    }
    await rescheduleAll();
    back();
  };

  return (
    <Screen>
      <TopBar title={r.title} actions={<EditDelete label="opomnik" onEdit={() => push({ name: 'reminderForm', id })} onDelete={del} />} />
      <div className="subtitle">{vehicleLabel(v)}{v?.plate ? ' · ' + v.plate : ''}</div>
      <div className="scroll">
        <div className="card" style={{ padding: '14px 16px 4px' }}>
          <div className="t-kartica" style={{ marginBottom: 4 }}>Podrobnosti</div>
          <div className="kv"><span className="k">Vozilo</span><span className="v">{v ? `${v.owner} · ${vehicleLabel(v)}` : '—'}</span></div>
          <div className="kv"><span className="k">Datum</span><span className="v">{fmtDate(shownDate)}</span></div>
          <div className="kv"><span className="k">Ura</span><span className="v">{r.time}</span></div>
          <div className="kv"><span className="k">Barva</span><span className="v"><ColorValue c={r.color} /></span></div>
          <div className="kv"><span className="k">Ponovitev</span><span className="v">{REPEAT_LABEL[r.repeat]}</span></div>
          <div className="kv"><span className="k">Opomni me</span><span className="v">{REMIND_LABEL[r.remind]}</span></div>
          {r.done ? <div className="kv"><span className="k">Stanje</span><span className="v" style={{ color: 'var(--success)' }}>Opravljeno</span></div> : null}
        </div>
      </div>
      <div className="footer">
        {!r.done
          ? <Button icon={<Check size={20} />} onClick={done}>Opravljeno</Button>
          : <Button variant="secondary" onClick={async () => { await patch(db.reminders, id, { done: 0 }); await rescheduleAll(); }}>Ponovno odpri</Button>}
      </div>
    </Screen>
  );
}
