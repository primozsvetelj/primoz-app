import { useEffect, useState } from 'react';
import { Check, Plus, Settings2 } from 'lucide-react';
import { TypeManagerSheet } from '../ui/TypeManager';
import { useNav } from '../ui/nav';
import { FormDeleteButton } from '../ui/actions';
import { Screen, TopBar, Label, TextField, Button, Chip, ColorPicker, MonthCalendar, TimeSheet, TimeFieldButton, Sheet, VehicleSearchField } from '../ui/components';
import { db, save, type EventColor } from '../lib/db';
import { useServiceTypes, useVehicles } from '../lib/hooks';
import { parseISO, todayISO } from '../lib/dates';
import { firstAvailableEvening } from '../lib/scheduling';

export function ServiceFormScreen({ vehicleId: fixedVehicle, id, copyFrom, date: initialDate, history = false }: { vehicleId?: string; id?: string; copyFrom?: string; date?: string; history?: boolean }) {
  const { back, toast } = useNav();
  const types = useServiceTypes() ?? [];
  const vehicles = useVehicles() ?? [];
  const [vehicleId, setVehicleId] = useState(fixedVehicle ?? '');
  const [title, setTitle] = useState('');
  const [color, setColor] = useState<EventColor>('violet');
  const [typeId, setTypeId] = useState('');
  const [date, setDate] = useState(initialDate ?? (history ? todayISO() : ''));
  const [time, setTime] = useState(() => history ? new Date().toTimeString().slice(0, 5) : '20:00');
  const start = parseISO(initialDate ?? todayISO());
  const [month, setMonth] = useState({ y: start.getFullYear(), m: start.getMonth() });
  const [timeOpen, setTimeOpen] = useState(false);
  const [newType, setNewType] = useState(false);
  const [newName, setNewName] = useState('');
  const [manage, setManage] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    const src = id ?? copyFrom;
    if (!src) return;
    db.services.get(src).then((s) => {
      if (!s) return;
      setTitle(s.title); setColor(s.color); setTypeId(s.typeId); if (id) setTime(s.time);
      if (!fixedVehicle) setVehicleId(s.vehicleId);
      if (id) { setDate(s.date); const d = parseISO(s.date); setMonth({ y: d.getFullYear(), m: d.getMonth() }); }
    });
  }, [id, copyFrom, fixedVehicle]);

  useEffect(() => {
    if (!id && initialDate) firstAvailableEvening(initialDate).then(setTime);
  }, [id, initialDate]);

  const pickDate = async (value: string) => {
    setDate(value);
    setErrors((e) => ({ ...e, date: '' }));
    if (!id) setTime(await firstAvailableEvening(value));
    setTimeOpen(true);
  };

  const vehicle = vehicles.find((v) => v.id === vehicleId);
  const pickType = (tid: string) => {
    setTypeId(tid);
    setErrors((e) => ({ ...e, type: '' }));
    if (!title.trim()) {
      const t = types.find((x) => x.id === tid);
      if (t) setTitle(`${t.name}${vehicle?.model ? ' – ' + vehicle.model : ''}`);
    }
  };

  const submit = async () => {
    const e: Record<string, string> = {};
    if (!vehicleId) e.vehicle = 'Izberi vozilo.';
    if (!title.trim()) e.title = history ? 'Vpiši, kaj si delal na vozilu.' : 'Vpiši ime dogodka.';
    if (!history && !typeId) e.type = 'Izberi vrsto servisa.';
    if (!history && !date) e.date = 'Izberi datum.';
    setErrors(e);
    if (Object.values(e).some(Boolean)) return;
    await save(db.services, {
      id,
      vehicleId,
      title: title.trim(),
      color: history ? 'violet' : color,
      typeId: history ? (typeId || types[0]?.id || 'history') : typeId,
      date: history ? (id ? date : todayISO()) : date,
      time: history ? (id ? time : new Date().toTimeString().slice(0, 5)) : time,
    });
    toast(id ? 'Spremembe shranjene' : history ? 'Popravilo dodano v zgodovino' : 'Servis shranjen');
    back();
  };

  const addType = async () => {
    const name = newName.trim();
    if (!name) return;
    const exists = types.find((t) => t.name.toLowerCase() === name.toLowerCase());
    const t = exists ?? (await save(db.serviceTypes, { name, builtin: 0 }));
    pickType(t.id); setNewType(false); setNewName('');
    if (!exists) toast('Nova vrsta dodana v knjižnico');
  };

  return (
    <Screen>
      <TopBar close title={id ? 'Uredi servis' : copyFrom ? 'Ponovi servis' : history ? 'Dodaj v zgodovino' : 'Nov servis'} obrazec actions={<FormDeleteButton kind="service" id={id} label="servis" />} />
      <div className="scroll">
        {fixedVehicle && vehicle && <div className="t-b15" style={{ margin: '4px 0 4px' }}>{vehicle.owner} · {[vehicle.brand, vehicle.model].filter(Boolean).join(' ')}{vehicle.plate ? ' · ' + vehicle.plate : ''}</div>}
        {!fixedVehicle && (
          <>
            <Label>Vozilo</Label>
            <VehicleSearchField vehicles={vehicles} value={vehicleId} onChange={(v) => { setVehicleId(v); setErrors((e) => ({ ...e, vehicle: '' })); }} error={errors.vehicle} />
          </>
        )}
        <Label>{history ? 'Kaj si danes delal na vozilu' : 'Ime dogodka v koledarju'}</Label>
        <TextField value={title} onChange={(v) => { setTitle(v); setErrors((e) => ({ ...e, title: '' })); }} placeholder={history ? 'npr. Zamenjal sem zavorne ploščice' : 'npr. Menjava olja – Golf'} error={errors.title} autoFocus={history} />
        {!history && <>
          <Label>Barva dogodka</Label>
          <ColorPicker value={color} onChange={setColor} />
          <Label>Vrsta servisa</Label>
          <div className="chips">
            <button className="chip" style={{ width: 40, height: 40, borderRadius: 20, justifyContent: 'center', padding: 0 }} aria-label="Dodaj vrsto servisa" onClick={() => setNewType(true)}><Plus size={22} /></button>
            {types.map((t) => <Chip key={t.id} lg on={typeId === t.id} onClick={() => pickType(t.id)}>{t.name}</Chip>)}
          </div>
          {errors.type && <div className="errtext">{errors.type}</div>}
          {types.some((t) => !t.builtin) && <button className="row cv t-b13" style={{ marginTop: 10, gap: 6 }} onClick={() => setManage(true)}><Settings2 size={16} />Uredi moje vrste</button>}
          <Label>Datum</Label>
          <MonthCalendar value={date} month={month} onMonth={setMonth} onChange={pickDate} />
          {errors.date && <div className="errtext">{errors.date}</div>}
          <Label>Ura</Label>
          <TimeFieldButton date={date} time={time} onClick={() => date ? setTimeOpen(true) : setErrors((e) => ({ ...e, date: 'Najprej izberi datum.' }))} />
        </>}
      </div>
      <div className="footer">
        <Button icon={<Check size={20} />} onClick={submit}>{id ? 'Shrani spremembe' : history ? 'Dodaj v zgodovino' : 'Shrani servis'}</Button>
      </div>

      {!history && <TimeSheet open={timeOpen} date={date} value={time} onClose={() => setTimeOpen(false)} onConfirm={(t) => { setTime(t); setTimeOpen(false); }} />}
      <TypeManagerSheet kind="serviceTypes" open={manage} onClose={() => setManage(false)} onDeleted={(tid) => { if (tid === typeId) setTypeId(''); }} />
      <Sheet open={newType} onClose={() => setNewType(false)} title="Nova vrsta servisa"
        footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={() => setNewType(false)}>Prekliči</Button><Button style={{ flex: 1 }} icon={<Plus size={20} />} disabled={!newName.trim()} onClick={addType}>Dodaj vrsto</Button></>}>
        <Label>Ime vrste servisa</Label>
        <TextField value={newName} onChange={setNewName} placeholder="npr. Menjava zavornih ploščic" autoFocus onEnter={addType} />
        <div className="t-r13 c2" style={{ marginTop: 12 }}>Nova vrsta se shrani v knjižnico in je na voljo pri vseh vozilih.</div>
      </Sheet>
    </Screen>
  );
}
