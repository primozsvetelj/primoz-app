import { useState } from 'react';
import { Pencil, Plus, Trash2, Copy, Wrench, Bell, ChevronRight } from 'lucide-react';
import { useNav } from '../ui/nav';
import { useDelete } from '../ui/actions';
import { Screen, TopBar, CopyBtn, SwipeRow, Sheet } from '../ui/components';
import { FluidGlyph } from '../ui/icons';
import { useFieldDefs, useFluids, useFluidTypes, useReminders, useServices, useVehicle } from '../lib/hooks';
import { vehicleTypeLabel, type FieldDef, type Vehicle, type Service } from '../lib/db';
import { copyText } from '../lib/native';
import { fmtDate, nextOccurrence, todayISO } from '../lib/dates';

const HEADER_KEYS = new Set(['owner', 'brand', 'model', 'type']);

export function fieldValue(v: Vehicle, f: FieldDef, services?: Service[]): string {
  if (f.builtin === 'lastService') {
    const last = (services ?? []).filter((s) => s.vehicleId === v.id && s.date <= todayISO()).sort((a, b) => b.date.localeCompare(a.date))[0];
    return last ? fmtDate(last.date) : '';
  }
  if (f.builtin === 'type') return vehicleTypeLabel(v.type);
  if (f.builtin === 'powerKw') return v.powerKw ? `${v.powerKw} kW` : '';
  if (f.builtin) return String((v as unknown as Record<string, string>)[f.builtin] ?? '');
  const raw = v.custom?.[f.id] ?? '';
  if (f.type === 'date' && raw) return fmtDate(raw);
  if (f.type === 'number' && raw && f.name.toLowerCase().includes('kilometr')) return `${Number(raw).toLocaleString('sl-SI')} km`;
  return raw;
}

export function VehicleDetailScreen({ id }: { id: string }) {
  const { push, back, toast } = useNav();
  const remove = useDelete();
  const v = useVehicle(id);
  const fields = useFieldDefs() ?? [];
  const fluids = useFluids(id) ?? [];
  const ftypes = useFluidTypes() ?? [];
  const services = (useServices() ?? []).filter((s) => s.vehicleId === id).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  const allServices = useServices();
  const reminders = (useReminders() ?? []).filter((r) => r.vehicleId === id && !r.done);
  const [vinCopyOpen, setVinCopyOpen] = useState(false);
  if (v === undefined) return <Screen nav><TopBar title="Podrobnosti vozila" /></Screen>;
  if (v === null || v.deleted) return <Screen nav><TopBar title="Podrobnosti vozila" /><div className="empty">Vozilo ne obstaja več.</div></Screen>;

  const dataFields = fields.filter((f) => f.builtin && !HEADER_KEYS.has(f.builtin) && f.active);
  const customFields = fields.filter((f) => !f.builtin && f.active);
  const ftMap = new Map(ftypes.map((t) => [t.id, t]));

  const copyAll = async () => {
    const lines = [
      `${v.owner} – ${[v.brand, v.model].filter(Boolean).join(' ')}`,
      ...fields.filter((f) => f.active && f.builtin !== 'owner').map((f) => [f.name, fieldValue(v, f, allServices)] as const).filter(([, val]) => val).map(([n, val]) => `${n}: ${val}`),
    ];
    await copyText(lines.join('\n'));
    toast('Vsi podatki kopirani');
  };

  const del = async () => { if (await remove.vehicle(v.id)) back(); };


  return (
    <Screen nav>
      <TopBar title="Podrobnosti vozila" actions={<>
        <button className="iconbtn violet" aria-label="Uredi vozilo" onClick={() => push({ name: 'vehicleForm', id })}><Pencil size={22} /></button>
        <button className="iconbtn danger" aria-label="Izbriši vozilo" onClick={del}><Trash2 size={20} /></button>
      </>} />
      <div className="scroll pad-fab">
        <div className="row" style={{ alignItems: 'flex-start', marginTop: 6 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="t-vozilo" style={{ lineHeight: 1.15, overflowWrap: 'anywhere' }}>{v.owner || 'Brez imena'}</div>
            <div className="t-r15 c2" style={{ marginTop: 4 }}>{[v.brand, v.model].filter(Boolean).join(' ')}{v.brand || v.model ? '  ·  ' : ''}{vehicleTypeLabel(v.type)}</div>
          </div>
          {v.plate && <span className="badge" style={{ marginTop: 8 }}>{v.plate}</span>}
        </div>

        <div className="card" style={{ padding: '14px 18px 4px', marginTop: 16 }}>
          <div className="row"><div className="t-sekcija" style={{ flex: 1 }}>Podatki vozila</div>
            <button className="iconbtn violet" aria-label="Kopiraj vse" onClick={copyAll}><Copy size={22} /></button></div>
          {dataFields.map((f) => {
            const val = fieldValue(v, f, allServices);
            return (
              <div key={f.id} className={`kv ${f.builtin === 'vin' ? 'vin-kv' : ''}`} style={{ padding: '6px 0', minHeight: 43 }}>
                <span className="k" style={{ width: 112, flex: 'none', fontSize: 15 }}>{f.name}</span>
                <span className={`t-b15 ${f.builtin === 'vin' ? 'vin-value' : ''}`} style={{ flex: 1, minWidth: 0, overflowWrap: 'anywhere' }}>{val || <span className="cdis">—</span>}</span>
                {val && f.builtin === 'vin' ? (
                  <button className="iconbtn violet" aria-label="Možnosti kopiranja šasije" onClick={() => setVinCopyOpen(true)}><Copy size={19} /></button>
                ) : val ? <CopyBtn text={val} label={`${f.name} kopirano`} /> : <span style={{ width: 32 }} />}
              </div>
            );
          })}
        </div>

        {v.catalog && (
          <div className="card" style={{ padding: '14px 18px', marginTop: 12 }}>
            <div className="t-sekcija">Tehnični podatki iz kataloga</div>
            <div className="t-r12 c2" style={{ marginTop: 3, marginBottom: 8 }}>
              {v.catalog.id} · {v.catalog.row_status || 'status ni naveden'}
            </div>
            {[
              ['Motor', [v.catalog.engine_name, v.catalog.engine_code, v.catalog.power].filter(Boolean).join(' · ')],
              ['Obdobje', v.catalog.period],
              ['Motorno olje', [v.catalog.engine_oil_spec, v.catalog.engine_oil_capacity].filter(Boolean).join(' · ')],
              ['Hladilna tekočina', v.catalog.coolant],
              ['Zavorna tekočina', v.catalog.brake_fluid],
              ['Olje menjalnika', v.catalog.transmission_oil],
              ['Klima', v.catalog.ac_refrigerant],
              ['Tlak pnevmatik', v.catalog.tyre_pressure],
              ['Dimenzije pnevmatik', v.catalog.tyre_sizes],
            ].filter(([, value]) => value).map(([label, value]) => (
              <div key={label} className="kv" style={{ padding: '6px 0', minHeight: 38 }}>
                <span className="k" style={{ width: 130, flex: 'none' }}>{label}</span>
                <span className="t-b13" style={{ flex: 1, overflowWrap: 'anywhere' }}>{value}</span>
              </div>
            ))}
            {v.catalog.warnings && <div className="t-r12" style={{ color: 'var(--orange)', marginTop: 10 }}>Opozorilo: {v.catalog.warnings}</div>}
          </div>
        )}

        <div className="card" style={{ padding: '14px 12px 8px', marginTop: 12 }}>
          <div className="row" style={{ padding: '0 6px' }}>
            <div style={{ flex: 1 }}>
              <div className="t-sekcija">Olja in tekočine</div>
              <div className="t-r12 c2" style={{ marginTop: 2 }}>Vrsta · Specifikacija · Vir</div>
            </div>
            <button className="iconbtn round" aria-label="Dodaj tekočino" onClick={() => push({ name: 'fluidForm', vehicleId: id })}><Plus size={22} /></button>
          </div>
          {fluids.length === 0 && <div className="t-r13 c2" style={{ padding: '14px 6px 8px' }}>Ni vpisanih olj ali tekočin. Dodaj jih z gumbom +.</div>}
          {fluids.map((fl, i) => {
            const t = ftMap.get(fl.typeId);
            return (
              <div key={fl.id} style={{ borderTop: i ? '1px solid var(--border)' : undefined, marginTop: i ? 0 : 8 }}>
                <SwipeRow onEdit={() => push({ name: 'fluidForm', vehicleId: id, id: fl.id })} onDelete={() => remove.fluid(fl.id)}>
                  <div className="row" style={{ padding: '10px 6px', gap: 14 }} onClick={() => push({ name: 'fluidForm', vehicleId: id, id: fl.id })}>
                    <FluidGlyph icon={t?.icon ?? 'drop'} size={26} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="t-b15">{t?.name ?? 'Tekočina'}</div>
                      <div className="t-r12 c2">{fl.description || '—'}{t && !t.builtin ? ' · uporabniški vnos' : ''}</div>
                    </div>
                    <span className="t-b13 co">{t?.builtin ? 'Iz baze' : 'Moje'}</span>
                  </div>
                </SwipeRow>
              </div>
            );
          })}
          {fluids.length > 0 && <div className="t-r12 cdis" style={{ padding: '4px 6px 2px' }}>Povleci vrstico v levo za urejanje ali brisanje.</div>}
        </div>

        <div className="card" style={{ padding: '14px 12px 8px', marginTop: 12 }}>
          <div className="row" style={{ padding: '0 6px' }}>
            <div className="t-sekcija" style={{ flex: 1 }}>Servisi in opomniki</div>
            <button className="iconbtn round" aria-label="Nov opomnik" onClick={() => push({ name: 'reminderForm', vehicleId: id })}><Bell size={20} /></button>
          </div>
          {services.length + reminders.length === 0 && <div className="t-r13 c2" style={{ padding: '14px 6px 8px' }}>Ni servisov ali opomnikov.</div>}
          {reminders.map((r) => {
            const occ = nextOccurrence(r, todayISO()) ?? r.date;
            return (
              <div key={r.id} style={{ borderTop: '1px solid var(--border)' }}>
                <SwipeRow onEdit={() => push({ name: 'reminderForm', id: r.id })} onDelete={() => remove.reminder(r.id)}>
                  <button className="row" style={{ width: '100%', padding: '10px 6px', textAlign: 'left' }} onClick={() => push({ name: 'reminder', id: r.id, occ })}>
                    <Bell size={20} color={r.color === 'orange' ? 'var(--orange)' : 'var(--violet)'} />
                    <div style={{ flex: 1, minWidth: 0 }}><div className="t-b15">{r.title}</div><div className="t-r12 c2">Opomnik · {fmtDate(occ)} · {r.time}</div></div>
                    <ChevronRight size={18} />
                  </button>
                </SwipeRow>
              </div>
            );
          })}
          {services.map((s) => (
            <div key={s.id} style={{ borderTop: '1px solid var(--border)' }}>
              <SwipeRow onEdit={() => push({ name: 'serviceForm', id: s.id })} onDelete={() => remove.service(s.id)}>
                <button className="row" style={{ width: '100%', padding: '10px 6px', textAlign: 'left' }} onClick={() => push({ name: 'service', id: s.id })}>
                  <Wrench size={20} color={s.color === 'orange' ? 'var(--orange)' : 'var(--violet)'} />
                  <div style={{ flex: 1, minWidth: 0 }}><div className="t-b15">{s.title}</div><div className="t-r12 c2">Servis · {fmtDate(s.date)} · {s.time}</div></div>
                  <ChevronRight size={18} />
                </button>
              </SwipeRow>
            </div>
          ))}
          {services.length + reminders.length > 0 && <div className="t-r12 cdis" style={{ padding: '4px 6px 2px' }}>Povleci vrstico v levo za urejanje ali brisanje.</div>}
        </div>

        <div className="card" style={{ padding: '14px 18px', marginTop: 12 }}>
          <div className="t-sekcija" style={{ marginBottom: 10 }}>Dodatna polja</div>
          {customFields.length === 0 && <div className="t-r13 c2">Ni aktivnih lastnih polj.</div>}
          <div style={{ display: 'flex', flexWrap: 'wrap', columnGap: 28, rowGap: 8 }}>
            {customFields.map((f) => (
              <span key={f.id} className="t-r15 c2">{f.name}: <span style={{ color: 'var(--text)' }}>{fieldValue(v, f) || '—'}</span></span>
            ))}
          </div>
          <button className="row cv t-b15" style={{ marginTop: 14 }} onClick={() => push({ name: 'fields', vehicleId: id })}>
            <Plus size={18} /> Dodaj svoje polje
          </button>
        </div>
      </div>
      <Sheet open={vinCopyOpen} onClose={() => setVinCopyOpen(false)} title="Kopiraj šasijo">
        <button className="listrow" style={{ width: '100%' }} onClick={async () => { await copyText(v.vin); setVinCopyOpen(false); toast('Celotna šasija kopirana'); }}>
          <div className="ico"><Copy size={20} /></div><div className="main"><div className="t1">Celotna šasija</div><div className="t2">{v.vin}</div></div>
        </button>
        <button className="listrow" style={{ width: '100%' }} onClick={async () => { await copyText(v.vin.slice(-6)); setVinCopyOpen(false); toast('Zadnjih 6 znakov kopiranih'); }}>
          <div className="ico"><Copy size={20} /></div><div className="main"><div className="t1">Zadnjih 6 znakov</div><div className="t2">{v.vin.slice(-6)}</div></div>
        </button>
      </Sheet>
      <button className="fab" onClick={() => push({ name: 'serviceForm', vehicleId: id })}><Wrench size={20} /> Dodaj servis</button>
    </Screen>
  );
}
