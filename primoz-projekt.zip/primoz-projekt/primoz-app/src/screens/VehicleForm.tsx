import { useEffect, useState } from 'react';
import { Check, User, ScanLine, Database } from 'lucide-react';
import { Scanner } from '../ui/Scanner';
import { formatPlate } from '../lib/ocr';
import { useNav } from '../ui/nav';
import { FormDeleteButton } from '../ui/actions';
import { Screen, TopBar, Label, TextField, ChipGroup, Button } from '../ui/components';
import { db, save, VEHICLE_TYPES, type Vehicle, type VehicleType } from '../lib/db';
import { searchCatalog, type CatalogEntry } from '../lib/account';

export function VehicleFormScreen({ id }: { id?: string }) {
  const { back, replace, toast } = useNav();
  const [f, setF] = useState({ owner: '', brand: '', model: '', plate: '', vin: '', engine: '', year: '', type: 'osebni' as VehicleType });
  const [existing, setExisting] = useState<Vehicle | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [scan, setScan] = useState<'vin' | 'plate' | null>(null);
  const [catalog, setCatalog] = useState<CatalogEntry | undefined>();
  const [suggestions, setSuggestions] = useState<CatalogEntry[]>([]);
  const [catalogOpen, setCatalogOpen] = useState(false);

  useEffect(() => {
    if (!id) return;
    db.vehicles.get(id).then((v) => {
      if (!v) return;
      setExisting(v);
      setF({ owner: v.owner, brand: v.brand, model: v.model, plate: v.plate, vin: v.vin, engine: v.engine, year: v.year, type: v.type });
      setCatalog(v.catalog);
    });
  }, [id]);

  useEffect(() => {
    if (!catalogOpen) return;
    const q = [f.brand, f.model, f.engine].filter(Boolean).join(' ').trim();
    if (q.length < 1) { setSuggestions([]); return; }
    let live = true;
    const timer = window.setTimeout(() => searchCatalog(q).then((rows) => { if (live) setSuggestions(rows); }).catch(() => { if (live) setSuggestions([]); }), 220);
    return () => { live = false; window.clearTimeout(timer); };
  }, [f.brand, f.model, f.engine, catalogOpen]);

  const set = (k: keyof typeof f) => (val: string) => {
    setF((p) => ({ ...p, [k]: val }));
    if (k === 'brand' || k === 'model' || k === 'engine') { setCatalog(undefined); setCatalogOpen(true); }
    setErrors((e) => ({ ...e, [k]: '' }));
  };
  const pickCatalog = (row: CatalogEntry) => {
    setCatalog(row);
    setF((p) => ({
      ...p,
      brand: row.brand,
      model: row.model,
      engine: [row.engine_name, row.engine_code].filter(Boolean).join(' · '),
      year: /^\d{4}$/.test(row.period) ? row.period : p.year,
    }));
    setCatalogOpen(false);
    setSuggestions([]);
  };

  const submit = async () => {
    const e: Record<string, string> = {};
    if (!f.owner.trim()) e.owner = 'Vpiši ime lastnika.';
    if (!f.plate.trim() && !f.vin.trim()) e.plate = 'Vpiši registrsko številko ali šasijo.';
    if (f.vin && f.vin.replace(/\s/g, '').length !== 17) e.vin = 'Šasija (VIN) ima 17 znakov.';
    if (f.year && !/^\d{4}$/.test(f.year)) e.year = 'Npr. 2021';
    else if (f.year && (+f.year < 1900 || +f.year > new Date().getFullYear() + 1)) e.year = 'Neveljaven letnik';
    if (f.plate) {
      const norm = f.plate.replace(/[\s-]/g, '').toUpperCase();
      const dup = (await db.vehicles.toArray()).find((v) => !v.deleted && v.id !== id && v.plate.replace(/[\s-]/g, '').toUpperCase() === norm);
      if (dup) e.plate = `Registracija že obstaja (${dup.owner}).`;
    }
    setErrors(e);
    if (Object.values(e).some(Boolean)) return;
    setBusy(true);
    const row = await save(db.vehicles, {
      ...(existing ?? {}),
      id,
      owner: f.owner.trim(), brand: f.brand.trim(), model: f.model.trim(),
      plate: f.plate.trim().toUpperCase(), vin: f.vin.replace(/\s/g, '').toUpperCase(), engine: f.engine.trim(), year: f.year.trim(), type: f.type,
      custom: existing?.custom ?? {}, catalog,
    });
    toast(id ? 'Spremembe shranjene' : 'Vozilo dodano');
    if (id) back(); else replace({ name: 'vehicle', id: row.id });
  };

  return (
    <Screen>
      <TopBar close title={id ? 'Uredi vozilo' : 'Novo vozilo'} actions={<FormDeleteButton kind="vehicle" id={id} label="vozilo" />} />
      <div className="subtitle">{id ? 'Posodobi podatke vozila' : 'Dodaj vozilo v svojo evidenco'}</div>
      <div className="scroll">
        <div className="card" style={{ padding: '4px 16px 18px' }}>
          <Label>Ime lastnika</Label>
          <TextField value={f.owner} onChange={set('owner')} placeholder="npr. Peter Novak" icon={<User size={20} color="var(--text-2)" />} error={errors.owner} autoCapitalize="words" />
          <div className="grid2">
            <div><Label>Znamka</Label><TextField value={f.brand} onChange={set('brand')} placeholder="npr. Volkswagen" autoCapitalize="words" /></div>
            <div><Label>Model</Label><TextField value={f.model} onChange={set('model')} placeholder="npr. Golf" autoCapitalize="words" /></div>
          </div>
          {catalogOpen && (suggestions.length > 0 || f.brand || f.model) && (
            <div className="card" style={{ padding: 4, marginTop: 6, background: 'var(--bg-field)', maxHeight: 260, overflowY: 'auto' }} role="listbox" aria-label="Predlogi vozil">
              {suggestions.length === 0 && <div className="t-r13 c2" style={{ padding: 12 }}>V katalogu ni ustreznega predloga.</div>}
              {suggestions.map((row) => (
                <button key={row.id} role="option" className="row" onMouseDown={(e) => e.preventDefault()} onClick={() => pickCatalog(row)}
                  style={{ width: '100%', padding: '10px 12px', textAlign: 'left', borderRadius: 10 }}>
                  <Database size={18} color="var(--violet)" />
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span className="t-b15" style={{ display: 'block' }}>{row.brand} {row.model}</span>
                    <span className="t-r12 c2">{[row.engine_name, row.engine_code, row.power, row.period].filter(Boolean).join(' · ') || 'Osnovni kataloški zapis'}</span>
                  </span>
                </button>
              ))}
            </div>
          )}
          {catalog && <div className="t-r12 c2" style={{ marginTop: 7 }}>Iz kataloga: {catalog.row_status || 'status ni naveden'}{catalog.warnings ? ` · ${catalog.warnings}` : ''}</div>}
          <Label>Registrska številka</Label>
          <TextField value={f.plate} onChange={set('plate')} placeholder="npr. LJ AB-123" error={errors.plate} autoCapitalize="characters"
            trailing={<button type="button" className="iconbtn violet trail" aria-label="Skeniraj registrsko" onClick={() => setScan('plate')}><ScanLine size={22} /></button>} />
          <Label>Šasija (VIN)</Label>
          <TextField value={f.vin} onChange={set('vin')} placeholder="17-mestna številka" error={errors.vin} maxLength={20} autoCapitalize="characters"
            trailing={<button type="button" className="iconbtn violet trail" aria-label="Skeniraj šasijo" onClick={() => setScan('vin')}><ScanLine size={22} /></button>} />
          <div className="t-r12 c2" style={{ marginTop: 6 }}>Namig: tapni ikono za skeniranje s kamero.</div>
          <div className="grid2">
            <div><Label>Motor</Label><TextField value={f.engine} onChange={set('engine')} placeholder="npr. 2.0 TDI" /></div>
            <div><Label>Letnik</Label><TextField value={f.year} onChange={set('year')} placeholder="2021" inputMode="numeric" maxLength={4} error={errors.year} /></div>
          </div>
          <Label>Vrsta vozila</Label>
          <ChipGroup value={f.type} options={VEHICLE_TYPES} onChange={(t) => setF((p) => ({ ...p, type: t }))} />
        </div>
      </div>
      {scan && (
        <Scanner kind={scan} onClose={() => setScan(null)}
          onResult={(v) => { if (scan === 'vin') set('vin')(v); else set('plate')(formatPlate(v)); setScan(null); toast(scan === 'vin' ? 'Šasija prebrana' : 'Registrska prebrana'); }} />
      )}
      <div className="footer">
        <Button variant="secondary" onClick={() => back()}>Prekliči</Button>
        <Button icon={<Check size={20} />} onClick={submit} loading={busy}>{id ? 'Shrani spremembe' : 'Shrani vozilo'}</Button>
      </div>
    </Screen>
  );
}
