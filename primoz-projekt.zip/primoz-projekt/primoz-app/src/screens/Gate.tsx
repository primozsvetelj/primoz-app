import { useState, type ReactNode } from 'react';
import { App as CapApp } from '@capacitor/app';
import { Ban, Lock, ShieldAlert, WifiOff, UserX, RefreshCw, Info, AlertTriangle, Megaphone, ShieldCheck } from 'lucide-react';
import { Button, Label, TextField } from '../ui/components';
import { answerMessage, changePassword, ServerError, type Session, type ServerMessage } from '../lib/account';
import { isNative } from '../lib/native';
import { fmtTimestamp } from '../lib/dates';

/* ------------------------------------------------------------ zaklenjen zaslon */

const LOCK: Record<Exclude<Session['status'], 'ok'>, { icon: ReactNode; title: string; text: string }> = {
  disabled: { icon: <UserX size={34} />, title: 'Račun je onemogočen', text: 'Administrator je onemogočil tvoj račun. Ko ga ponovno omogoči, se aplikacija sama odklene.' },
  blocked: { icon: <Ban size={34} />, title: 'Naprava je blokirana', text: 'Administrator je tej napravi prepovedal dostop do aplikacije.' },
  app_locked: { icon: <Lock size={34} />, title: 'Aplikacija je zaklenjena', text: 'Administrator je začasno zaklenil aplikacijo.' },
  integrity_failed: { icon: <ShieldAlert size={34} />, title: 'Neoriginalna aplikacija', text: 'Ta različica aplikacije je bila spremenjena ali ni uradna. Namesti uradno različico.' },
  offline_expired: { icon: <WifiOff size={34} />, title: 'Potrebna je povezava', text: 'Aplikacija mora občasno preveriti, ali tvoj račun še velja. Poveži se z internetom.' },
};

export function LockScreen({ session, onRetry, onLogout }: { session: Session; onRetry: () => Promise<void>; onLogout: () => void }) {
  const [busy, setBusy] = useState(false);
  const l = LOCK[session.status as Exclude<Session['status'], 'ok'>];
  const retry = async () => { setBusy(true); try { await onRetry(); } finally { setBusy(false); } };
  let text = l.text;
  if (session.status === 'offline_expired') {
    text = session.reason === 'clock'
      ? 'Ura na telefonu je bila prestavljena nazaj. Poveži se z internetom, da aplikacija ponovno preveri račun.'
      : `${l.text} Zadnja potrditev: ${fmtTimestamp(session.lastOkLocal)} (dovoljeno ${session.offlineDays} dni brez povezave).`;
  }
  return (
    <div className="screen fade-enter" role="alertdialog" aria-label={l.title}>
      <div className="scroll" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', paddingTop: 110 }}>
        <div style={{ width: 84, height: 84, borderRadius: 42, background: 'var(--error-bg)', color: 'var(--error)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{l.icon}</div>
        <div className="t-dialog" style={{ marginTop: 22, fontSize: 24 }}>{l.title}</div>
        <div className="t-r15 c2" style={{ marginTop: 12, lineHeight: 1.55, maxWidth: 340 }}>{text}</div>
        {session.reason && session.reason !== 'clock' && (
          <div className="card" style={{ marginTop: 18, padding: '12px 16px', maxWidth: 360, textAlign: 'left' }}>
            <div className="label" style={{ margin: 0 }}>Sporočilo administratorja</div>
            <div className="t-r15" style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{session.reason}</div>
          </div>
        )}
        <div className="t-r13 cdis" style={{ marginTop: 18 }}>{session.account.name || session.account.email}</div>
        <div style={{ width: '100%', maxWidth: 360, marginTop: 'auto', paddingTop: 30, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Button icon={<RefreshCw size={18} />} onClick={retry} loading={busy}>Preveri znova</Button>
          <Button variant="ghost" onClick={onLogout}>Odjava</Button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ sporočilo administratorja */

const KIND = {
  info: { icon: <Info size={30} />, color: 'var(--violet)', bg: 'var(--bg-selected)' },
  warning: { icon: <AlertTriangle size={30} />, color: 'var(--orange)', bg: 'var(--orange-bg)' },
  important: { icon: <Megaphone size={30} />, color: 'var(--error)', bg: 'var(--error-bg)' },
};

/** Sporočilo zasede večino zaslona; zapre se samo z enim od gumbov, ki jih je izbral admin. */
export function MessageOverlay({ messages, onChange }: { messages: ServerMessage[]; onChange: () => void }) {
  const [hidden, setHidden] = useState<string[]>([]);
  const [busy, setBusy] = useState('');
  const m = messages.find((x) => !hidden.includes(x.id));

  if (!m) return null;
  const k = KIND[m.kind] ?? KIND.info;

  const click = async (b: ServerMessage['buttons'][number]) => {
    setBusy(b.id);
    const final = b.action === 'close' || b.action === 'link';
    setHidden((h) => [...h, m.id]);
    await answerMessage(m.id, b.id, final).catch(() => {});
    setBusy('');
    if (b.action === 'link' && b.url && /^https:\/\//.test(b.url)) window.open(b.url, '_blank', 'noopener,noreferrer');
    if (b.action === 'exit' && isNative) CapApp.exitApp();
    onChange();
  };

  return (
    <div className="msg-overlay" role="dialog" aria-modal="true" aria-labelledby="msg-title">
      <div className="msg-card">
        <div className="msg-icon" style={{ color: k.color, background: k.bg }}>{k.icon}</div>
        <div id="msg-title" className="msg-title">{m.title}</div>
        <div className="msg-body">{m.body}</div>
        <div className="msg-buttons">
          {m.buttons.map((b) => (
            <Button key={b.id} variant={b.style} loading={busy === b.id} onClick={() => click(b)}>{b.label}</Button>
          ))}
        </div>
        {messages.length - hidden.length > 1 && <div className="t-r12 cdis" style={{ textAlign: 'center', marginTop: 10 }}>Še {messages.length - hidden.length - 1} sporočil/o</div>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ menjava gesla */

export function ChangePasswordForm({ forced, onDone, onCancel }: { forced?: boolean; onDone: () => void; onCancel?: () => void }) {
  const [old, setOld] = useState('');
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setErr('');
    if (pw.length < 8) return setErr('Novo geslo naj ima vsaj 8 znakov.');
    if (!/[A-Za-zČŠŽčšž]/.test(pw) || !/\d/.test(pw)) return setErr('Geslo naj vsebuje črke in številke.');
    if (pw !== pw2) return setErr('Gesli se ne ujemata.');
    if (pw === old) return setErr('Novo geslo mora biti drugačno od trenutnega.');
    setBusy(true);
    try {
      await changePassword(old, pw);
      onDone();
    } catch (e) {
      const c = e instanceof ServerError ? e.code : '';
      setErr(c === 'wrong_password' ? 'Trenutno geslo ni pravilno.' : c === 'weak_password' ? 'Geslo je prešibko.' : c === 'network' ? 'Za menjavo gesla potrebuješ internet.' : 'Menjava ni uspela.');
      setBusy(false);
    }
  };
  return (
    <>
      {forced && <div className="card row" style={{ padding: 12, gap: 10, marginTop: 8 }}><ShieldCheck size={20} color="var(--violet)" style={{ flex: 'none' }} /><span className="t-r14">Administrator zahteva, da si nastaviš svoje geslo.</span></div>}
      <Label>Trenutno geslo</Label>
      <TextField value={old} onChange={setOld} type="password" placeholder="••••••••" />
      <Label>Novo geslo</Label>
      <TextField value={pw} onChange={setPw} type="password" placeholder="vsaj 8 znakov, črke in številke" />
      <Label>Ponovi novo geslo</Label>
      <TextField value={pw2} onChange={setPw2} type="password" placeholder="••••••••" onEnter={submit} />
      {err && <div className="errtext" style={{ fontSize: 14 }}>{err}</div>}
      <div className="row" style={{ gap: 10, marginTop: 20 }}>
        {onCancel && <Button variant="secondary" style={{ flex: 1 }} onClick={onCancel}>Prekliči</Button>}
        <Button style={{ flex: 1 }} onClick={submit} loading={busy}>Shrani geslo</Button>
      </div>
    </>
  );
}
