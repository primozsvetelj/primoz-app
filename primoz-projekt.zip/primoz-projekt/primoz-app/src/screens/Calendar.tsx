import { useState } from 'react';
import { ChevronRight, CalendarPlus } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader, MonthCalendar, Chip, Empty, Button, SwipeRow } from '../ui/components';
import { useDelete } from '../ui/actions';
import { useReminders, useServices, useVehicles } from '../lib/hooks';
import { fmtDayTitle, monthGrid, occursOn, parseISO, todayISO, MONTHS_CAP, plural } from '../lib/dates';
import { vehicleLabel } from '../lib/db';

type Filter = 'all' | 'services' | 'reminders';

export function CalendarScreen() {
  const { push } = useNav();
  const remove = useDelete();
  const vehicles = useVehicles() ?? [];
  const services = useServices() ?? [];
  const reminders = useReminders() ?? [];
  const [sel, setSel] = useState(todayISO());
  const t = parseISO(sel);
  const [month, setMonth] = useState({ y: t.getFullYear(), m: t.getMonth() });
  const [filter, setFilter] = useState<Filter>('all');
  const vmap = new Map(vehicles.map((v) => [v.id, v]));

  const eventsOn = (iso: string) => [
    ...(filter !== 'reminders' ? services.filter((s) => s.date === iso).map((s) => ({ kind: 'service' as const, id: s.id, title: s.title, time: s.time, color: s.color, vehicleId: s.vehicleId })) : []),
    ...(filter !== 'services' ? reminders.filter((r) => !r.done && occursOn(r, iso)).map((r) => ({ kind: 'reminder' as const, id: r.id, title: r.title, time: r.time, color: r.color, vehicleId: r.vehicleId })) : []),
  ].sort((a, b) => a.time.localeCompare(b.time));

  const dots = new Set(monthGrid(month.y, month.m).filter((c) => eventsOn(c.iso).length).map((c) => c.iso));
  const selInMonth = (() => { const d = parseISO(sel); return d.getFullYear() === month.y && d.getMonth() === month.m; })();
  const events = selInMonth ? eventsOn(sel) : [];
  const countLabel = (n: number) => filter === 'services' ? plural(n, 'servis', 'servisa', 'servisi', 'servisov') : filter === 'reminders' ? plural(n, 'opomnik', 'opomnika', 'opomniki', 'opomnikov') : plural(n, 'dogodek', 'dogodka', 'dogodki', 'dogodkov');

  return (
    <Screen nav animate={false}>
      <SearchHeader onPlus={() => push({ name: 'reminderForm', date: selInMonth ? sel : undefined })} plusLabel="Nov opomnik" />
      <div className="scroll">
        <div className="h-big">Koledar</div>
        <MonthCalendar big showAdjacent value={sel} onChange={setSel} month={month} onMonth={setMonth} dots={dots} />
        <div className="segment" style={{ marginTop: 16 }}>
          <Chip on={filter === 'all'} onClick={() => setFilter('all')}>Vse</Chip>
          <Chip on={filter === 'services'} onClick={() => setFilter('services')}>Servisi</Chip>
          <Chip on={filter === 'reminders'} onClick={() => setFilter('reminders')}>Opomniki</Chip>
        </div>
        <div className="row" style={{ margin: '20px 0 12px' }}>
          <div className="t-sekcija" style={{ flex: 1 }}>{selInMonth ? fmtDayTitle(sel, false) : `${MONTHS_CAP[month.m]} ${month.y}`}</div>
          <span className="t-r13 c2">{selInMonth ? countLabel(events.length) : 'Izberi dan'}</span>
        </div>
        {selInMonth && events.length === 0 && (
          <Empty icon={<CalendarPlus size={28} />} title="Ta dan ni dogodkov"
            action={vehicles.length ? <div className="row"><Button size="s" variant="secondary" onClick={() => push({ name: 'serviceForm', date: sel })}>Servis</Button><Button size="s" onClick={() => push({ name: 'reminderForm', date: sel })}>Opomnik</Button></div> : undefined} />
        )}
        {events.map((e) => {
          const v = vmap.get(e.vehicleId);
          return (
            <SwipeRow key={e.kind + e.id} className="card-row"
              onEdit={() => push(e.kind === 'service' ? { name: 'serviceForm', id: e.id } : { name: 'reminderForm', id: e.id })}
              onDelete={() => (e.kind === 'service' ? remove.service(e.id) : remove.reminder(e.id))}>
            <button className="evrow" onClick={() => push(e.kind === 'service' ? { name: 'service', id: e.id } : { name: 'reminder', id: e.id, occ: sel })}>
              <span className="time">{e.time}</span>
              <span className="bar" style={{ background: e.color === 'orange' ? 'var(--orange)' : 'var(--violet)' }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="t-b16">{e.title}</div>
                <div className="t-r13 c2" style={{ marginTop: 2 }}>{v?.owner} · {vehicleLabel(v)}</div>
              </div>
              <ChevronRight size={20} />
            </button>
            </SwipeRow>
          );
        })}
        {events.length > 0 && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
      </div>
    </Screen>
  );
}
