import { ChevronRight, Wrench } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader, Empty, Button, SwipeRow } from '../ui/components';
import { useDelete } from '../ui/actions';
import { useServices, useVehicles } from '../lib/hooks';
import { fmtShort, todayISO } from '../lib/dates';
import { vehicleLabel } from '../lib/db';

export function HomeScreen() {
  const { push } = useNav();
  const remove = useDelete();
  const vehicles = useVehicles();
  const services = useServices();
  if (!vehicles || !services) return <Screen nav animate={false}><SearchHeader /></Screen>;
  const vmap = new Map(vehicles.map((v) => [v.id, v]));
  const today = todayISO();

  const history = services
    .filter((s) => s.date <= today)
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time))
    .slice(0, 5);

  return (
    <Screen nav animate={false}>
      <SearchHeader />
      <div className="scroll">
        <div className="row" style={{ marginTop: 22, marginBottom: 8 }}>
          <div className="h-sec" style={{ flex: 1, margin: 0 }}>Zgodovina popravil</div>
          {vehicles.length > 0 && <button className="iconbtn round" aria-label="Dodaj popravilo" onClick={() => push({ name: 'serviceForm', history: true })}><Wrench size={20} /></button>}
        </div>
        {history.length === 0 && (
          <Empty icon={<Wrench size={30} />} title="Ni še vpisanih popravil"
            text="Ko shraniš opravljeno popravilo, se bo prikazalo tukaj."
            action={vehicles.length ? <Button size="m" onClick={() => push({ name: 'serviceForm', history: true })}>Dodaj popravilo</Button> : undefined} />
        )}
        {history.map((s) => {
          const v = vmap.get(s.vehicleId);
          return (
            <SwipeRow key={s.id} className="card-row" onEdit={() => push({ name: 'serviceForm', id: s.id, history: true })} onDelete={() => remove.service(s.id)}>
              <button className="listrow" onClick={() => push({ name: 'serviceForm', id: s.id, history: true })}>
                <div className="ico"><Wrench size={20} /></div>
                <div className="main"><div className="t1">{s.title}</div><div className="t2">{vehicleLabel(v)}{v?.plate ? ' · ' + v.plate : ''}</div></div>
                <span className="datechip">{fmtShort(s.date)}</span>
                <ChevronRight size={20} />
              </button>
            </SwipeRow>
          );
        })}
        {history.length > 0 && <div className="swipehint">Prikazanih je zadnjih pet popravil.</div>}
      </div>
    </Screen>
  );
}
