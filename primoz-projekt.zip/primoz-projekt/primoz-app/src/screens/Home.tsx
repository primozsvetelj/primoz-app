import { Bell, ChevronRight, Wrench, CalendarCheck } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader, Empty, Button, SwipeRow } from '../ui/components';
import { useDelete } from '../ui/actions';
import { useReminders, useServices, useVehicles } from '../lib/hooks';
import { fmtShort, nextOccurrence, todayISO } from '../lib/dates';
import { vehicleLabel } from '../lib/db';

export function HomeScreen() {
  const { push, setTab } = useNav();
  const remove = useDelete();
  const vehicles = useVehicles();
  const reminders = useReminders();
  const services = useServices();
  if (!vehicles || !reminders || !services) return <Screen nav animate={false}><SearchHeader /></Screen>;
  const vmap = new Map(vehicles.map((v) => [v.id, v]));
  const today = todayISO();

  const items = [
    ...reminders
      .filter((r) => !r.done)
      .map((r) => ({ kind: 'reminder' as const, id: r.id, title: r.title, date: nextOccurrence(r, today), time: r.time, vehicleId: r.vehicleId, color: r.color }))
      .filter((x) => x.date),
    ...services
      .filter((s) => s.date >= today)
      .map((s) => ({ kind: 'service' as const, id: s.id, title: s.title, date: s.date, time: s.time, vehicleId: s.vehicleId, color: s.color })),
  ].sort((a, b) => (a.date! + a.time).localeCompare(b.date! + b.time));

  return (
    <Screen nav animate={false}>
      <SearchHeader />
      <div className="scroll">
        <div className="h-sec" style={{ marginTop: 22 }}>Prihajajoče</div>
        {items.length === 0 && (
          <Empty icon={<CalendarCheck size={30} />} title="Ni prihajajočih dogodkov"
            text={vehicles.length ? 'Dodaj opomnik ali servis in prikazal se bo tukaj.' : 'Začni tako, da dodaš svoje prvo vozilo.'}
            action={vehicles.length
              ? <Button size="m" onClick={() => push({ name: 'reminderForm' })}>Nov opomnik</Button>
              : <Button size="m" onClick={() => { setTab('vozila'); push({ name: 'vehicleForm' }); }}>Dodaj vozilo</Button>} />
        )}
        {items.map((it) => {
          const v = vmap.get(it.vehicleId);
          return (
            <SwipeRow key={it.kind + it.id} className="card-row"
              onEdit={() => push(it.kind === 'reminder' ? { name: 'reminderForm', id: it.id } : { name: 'serviceForm', id: it.id })}
              onDelete={() => (it.kind === 'reminder' ? remove.reminder(it.id) : remove.service(it.id))}>
            <button className="listrow"
              onClick={() => push(it.kind === 'reminder' ? { name: 'reminder', id: it.id, occ: it.date! } : { name: 'service', id: it.id })}>
              <div className="ico">{it.kind === 'reminder' ? <Bell size={20} /> : <Wrench size={20} />}</div>
              <div className="main">
                <div className="t1">{it.title}</div>
                <div className="t2">{vehicleLabel(v)}{v?.plate ? ' · ' + v.plate : ''}</div>
              </div>
              <span className="datechip">{it.date === today ? 'Danes' : fmtShort(it.date!)}</span>
              <ChevronRight size={20} />
            </button>
            </SwipeRow>
          );
        })}
        {items.length > 0 && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
      </div>
    </Screen>
  );
}
