import { useEffect, useState } from 'react';
import { Check, Mail, Phone, Trash2, UserRound, UsersRound } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Button, Empty, Label, Screen, SearchHeader, TextField, TopBar } from '../ui/components';
import { db, save, softDelete } from '../lib/db';
import { useCustomers } from '../lib/hooks';

export function CustomersScreen() {
  const { push } = useNav();
  const customers = useCustomers();
  return (
    <Screen nav animate={false}>
      <SearchHeader onPlus={() => push({ name: 'customerForm' })} plusLabel="Nova stranka" />
      <div className="scroll">
        <div className="h-big">Stranke</div>
        {customers && customers.length === 0 ? (
          <Empty icon={<UsersRound size={30} />} title="Ni še nobene stranke" text="Dodaj ime stranke. Telefon in e-pošta sta neobvezna."
            action={<Button size="m" onClick={() => push({ name: 'customerForm' })}>Dodaj stranko</Button>} />
        ) : customers?.map((customer) => (
          <button key={customer.id} className="listrow" style={{ width: '100%', textAlign: 'left' }} onClick={() => push({ name: 'customerForm', id: customer.id })}>
            <div className="ico" style={{ background: 'var(--bg-selected)', color: 'var(--violet)' }}><UserRound size={20} /></div>
            <div className="main">
              <div className="t1">{customer.name}</div>
              <div className="t2">{[customer.phone, customer.email].filter(Boolean).join(' · ') || 'Brez kontaktnih podatkov'}</div>
            </div>
          </button>
        ))}
      </div>
    </Screen>
  );
}

export function CustomerFormScreen({ id }: { id?: string }) {
  const { back, toast, confirm } = useNav();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!id) return;
    db.customers.get(id).then((row) => {
      if (!row) return;
      setName(row.name); setPhone(row.phone); setEmail(row.email);
    });
  }, [id]);

  const submit = async () => {
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = 'Vpiši ime in priimek.';
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = 'Preveri e-poštni naslov.';
    setErrors(next);
    if (Object.keys(next).length) return;
    await save(db.customers, { id, name: name.trim(), phone: phone.trim(), email: email.trim().toLowerCase() });
    toast(id ? 'Stranka posodobljena' : 'Stranka dodana');
    back();
  };

  const remove = async () => {
    if (!id || !(await confirm({ title: 'Izbrišem stranko?', text: 'Vozila in servisi ostanejo nespremenjeni.', okLabel: 'Izbriši', danger: true }))) return;
    await softDelete(db.customers, id);
    toast('Stranka izbrisana');
    back();
  };

  return (
    <Screen>
      <TopBar close title={id ? 'Uredi stranko' : 'Nova stranka'} actions={id ? <button className="iconbtn danger" aria-label="Izbriši stranko" onClick={remove}><Trash2 size={20} /></button> : undefined} />
      <div className="subtitle">Kontaktni podatki niso obvezni</div>
      <div className="scroll">
        <div className="card" style={{ padding: '4px 16px 18px' }}>
          <Label>Ime in priimek</Label>
          <TextField value={name} onChange={(v) => { setName(v); setErrors((e) => ({ ...e, name: '' })); }} placeholder="npr. Peter Novak" icon={<UserRound size={20} color="var(--text-2)" />} error={errors.name} autoCapitalize="words" />
          <Label>Telefon (neobvezno)</Label>
          <TextField value={phone} onChange={setPhone} placeholder="npr. 041 123 456" icon={<Phone size={20} color="var(--text-2)" />} inputMode="tel" />
          <Label>E-pošta (neobvezno)</Label>
          <TextField value={email} onChange={(v) => { setEmail(v); setErrors((e) => ({ ...e, email: '' })); }} placeholder="ime@gmail.com" icon={<Mail size={20} color="var(--text-2)" />} inputMode="email" autoCapitalize="none" error={errors.email} />
        </div>
      </div>
      <div className="footer">
        <Button variant="secondary" onClick={() => back()}>Prekliči</Button>
        <Button icon={<Check size={20} />} onClick={submit}>{id ? 'Shrani spremembe' : 'Shrani stranko'}</Button>
      </div>
    </Screen>
  );
}
