import { useState } from 'react';
import { User, ShieldCheck, WifiOff, Info } from 'lucide-react';
import { Label, TextField, Button } from '../ui/components';
import { login, LOGIN_ERRORS, ServerError, type Session } from '../lib/account';

/** Prijava s strežniškim računom. Registracije ni – račune ustvarja administrator. */
export function LoginScreen({ onDone, notice }: { onDone: (s: Session) => void; notice?: string }) {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [help, setHelp] = useState(false);

  const submit = async () => {
    setErr('');
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) return setErr('Vpiši veljaven e-poštni naslov.');
    if (!pw) return setErr('Vpiši geslo.');
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return setErr(LOGIN_ERRORS.network);
    setBusy(true);
    try {
      const s = await login(email, pw);
      setPw('');
      onDone(s);
    } catch (e) {
      const se = e instanceof ServerError ? e : new ServerError('server');
      let msg = LOGIN_ERRORS[se.code] ?? LOGIN_ERRORS.server;
      const mins = Math.ceil(Number(se.info.retry_after ?? 0) / 60);
      if (mins > 0) msg += ` Poskusi znova čez ${mins} min.`;
      if (se.info.reason) msg += ` (${String(se.info.reason)})`;
      setErr(msg);
      setBusy(false);
    }
  };

  return (
    <div className="screen fade-enter">
      <div className="scroll" style={{ display: 'flex', flexDirection: 'column', paddingTop: 96 }}>
        <div style={{ textAlign: 'center', fontSize: 34, fontWeight: 600 }}>Primož app</div>
        <div className="t-r15 c2" style={{ textAlign: 'center', marginTop: 18, marginBottom: 20, color: 'var(--text)' }}>Evidenca vozil na enem mestu</div>
        {notice && <div className="card row" style={{ padding: 12, gap: 10, background: 'var(--orange-bg)', borderColor: '#5a3a1c', marginBottom: 6 }}><Info size={20} color="var(--orange)" style={{ flex: 'none' }} /><span className="t-r14">{notice}</span></div>}
        <Label>E-pošta</Label>
        <TextField value={email} onChange={setEmail} placeholder="ime@primer.si" type="email" inputMode="email" icon={<User size={20} color="var(--text-2)" />} />
        <Label>Geslo</Label>
        <TextField value={pw} onChange={setPw} placeholder="••••••••" type="password" icon={<ShieldCheck size={20} color="var(--text-2)" />} onEnter={submit} />
        {err && <div className="errtext" style={{ fontSize: 14 }}>{err}</div>}
        <Button style={{ marginTop: 20 }} onClick={submit} loading={busy}>Prijava</Button>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, marginTop: 24 }}>
          <button className="btn ghost s" onClick={() => setHelp(!help)}>Nimaš računa ali si pozabil geslo?</button>
          {help && <div className="t-r14 c2" style={{ textAlign: 'center', lineHeight: 1.5, padding: '0 12px' }}>Račune ustvarja in gesla ponastavlja administrator. Obrni se nanj – po ponastavitvi se prijaviš z novim geslom.</div>}
        </div>
        <div className="row t-r12 cdis" style={{ justifyContent: 'center', gap: 6, marginTop: 'auto', paddingTop: 24 }}><WifiOff size={14} />Za prijavo je potrebna internetna povezava.</div>
      </div>
    </div>
  );
}
