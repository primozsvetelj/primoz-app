import { useState } from 'react';
import { ChevronRight, Search, Car } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader, Empty, Button, SwipeRow } from '../ui/components';
import { useDelete } from '../ui/actions';
import { useVehicles } from '../lib/hooks';

export function VehiclesScreen() {
  const { push } = useNav();
  const remove = useDelete();
  const vehicles = useVehicles();
  const [q, setQ] = useState('');
  const [focus, setFocus] = useState(false);
  const list = (vehicles ?? []).filter((v) => {
    if (!q.trim()) return true;
    const s = q.trim().toLowerCase().replace(/\s+/g, '');
    return `${v.owner}${v.plate}${v.brand}${v.model}`.toLowerCase().replace(/\s+/g, '').includes(s);
  });
  const needle = q.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[\s-]+/g, '');
  const suggestions = needle ? [...new Map((vehicles ?? []).flatMap((v) => [v.owner, v.plate, v.brand, v.model, [v.brand, v.model].filter(Boolean).join(' ')])
    .filter((x): x is string => !!x?.trim())
    .map((x) => [x.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[\s-]+/g, ''), x.trim()])).entries()]
    .filter(([key]) => key.includes(needle))
    .sort(([a], [b]) => Number(!a.startsWith(needle)) - Number(!b.startsWith(needle)))
    .slice(0, 3)
    .map(([, value]) => value) : [];

  return (
    <Screen nav animate={false}>
      <SearchHeader onPlus={() => push({ name: 'vehicleForm' })} plusLabel="Novo vozilo" />
      <div className="scroll">
        <div className="h-big">Vozila</div>
        {vehicles && vehicles.length === 0 ? (
          <Empty icon={<Car size={30} />} title="Ni še nobenega vozila" text="Dodaj vozilo v svojo evidenco – lastnik, registracija, šasija in ostalo."
            action={<Button size="m" onClick={() => push({ name: 'vehicleForm' })}>Dodaj vozilo</Button>} />
        ) : (
          <>
            <label className={`searchbar ${focus ? 'focus' : ''}`} style={{ height: 56, borderRadius: 28 }}>
              <Search size={22} color="var(--text)" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Išči po imenu ali registraciji …" onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} />
            </label>
            {focus && suggestions.length > 0 && (
              <div className="card" style={{ marginTop: 8, padding: 6 }} aria-label="Predlogi iskanja">
                {suggestions.map((s) => (
                  <button key={s} className="listrow" style={{ minHeight: 42, padding: '8px 12px' }} onPointerDown={(e) => { e.preventDefault(); setQ(s); }}>
                    <Search size={16} /><span className="main t-r14" style={{ textAlign: 'left' }}>{s}</span>
                  </button>
                ))}
              </div>
            )}
            <div className="row" style={{ background: 'var(--bg-card)', borderRadius: 10, padding: '12px 16px', margin: '16px 0 8px', fontSize: 14, fontWeight: 500 }}>
              <span style={{ flex: 1 }}>Ime</span>
              <span style={{ width: 150 }}>Registrska številka</span>
            </div>
            {list.length === 0 && <div className="empty" style={{ padding: 32 }}>Ni zadetkov za »{q}«.</div>}
            {list.map((v) => (
              <SwipeRow key={v.id} className="card-row" onEdit={() => push({ name: 'vehicleForm', id: v.id })} onDelete={() => remove.vehicle(v.id)}>
              <button className="listrow" style={{ padding: '12px 12px 12px 16px', borderColor: q && list.length === 1 ? 'var(--violet)' : undefined }}
                onClick={() => push({ name: 'vehicle', id: v.id })}>
                <div className="main">
                  <div className="t1" style={{ fontSize: 17 }}>{v.owner || 'Brez imena'}</div>
                  <div className="t2">{[v.brand, v.model].filter(Boolean).join(' ') || '—'}</div>
                </div>
                <span className="t-b15" style={{ width: 118 }}>{v.plate}</span>
                <ChevronRight size={20} />
              </button>
              </SwipeRow>
            ))}
            {list.length > 0 && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
          </>
        )}
      </div>
    </Screen>
  );
}
