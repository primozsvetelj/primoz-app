import { useState } from 'react';
import { ChevronRight, Car, ArrowDownAZ, History, SlidersHorizontal } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader, Empty, Button, SwipeRow, Sheet, Radio } from '../ui/components';
import { useDelete } from '../ui/actions';
import { useVehicles } from '../lib/hooks';

type SortMode = 'owner' | 'recent';
const SORT_KEY = 'primoz-vehicles-sort';
const RECENT_KEY = 'primoz-vehicles-opened';

function readOpened(): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(RECENT_KEY) ?? '{}') as Record<string, number>; }
  catch { return {}; }
}

export function VehiclesScreen() {
  const { push } = useNav();
  const remove = useDelete();
  const vehicles = useVehicles();
  const [sortOpen, setSortOpen] = useState(false);
  const [sortMode, setSortMode] = useState<SortMode>(() => localStorage.getItem(SORT_KEY) === 'recent' ? 'recent' : 'owner');
  const [opened, setOpened] = useState(readOpened);
  const byOwner = (a: { owner: string }, b: { owner: string }) => (a.owner || 'Ž').localeCompare(b.owner || 'Ž', 'sl', { sensitivity: 'base' });
  const list = [...(vehicles ?? [])].sort((a, b) => sortMode === 'recent'
    ? (opened[b.id] ?? 0) - (opened[a.id] ?? 0) || byOwner(a, b)
    : byOwner(a, b));

  const chooseSort = (mode: SortMode) => {
    setSortMode(mode);
    localStorage.setItem(SORT_KEY, mode);
    setSortOpen(false);
  };

  const openVehicle = (id: string) => {
    const next = { ...opened, [id]: Date.now() };
    setOpened(next);
    localStorage.setItem(RECENT_KEY, JSON.stringify(next));
    push({ name: 'vehicle', id });
  };

  return (
    <Screen nav animate={false}>
      <SearchHeader onPlus={() => push({ name: 'vehicleForm' })} plusLabel="Novo vozilo" />
      <div className="scroll">
        <div className="row" style={{ alignItems: 'center' }}>
          <div className="h-big" style={{ flex: 1 }}>Vozila</div>
          <button className="btn secondary s" style={{ gap: 6 }} onClick={() => setSortOpen(true)} aria-label="Razvrsti vozila">
            <SlidersHorizontal size={17} /> {sortMode === 'owner' ? 'Ime voznika' : 'Zadnje odprto'}
          </button>
        </div>
        {vehicles && vehicles.length === 0 ? (
          <Empty icon={<Car size={30} />} title="Ni še nobenega vozila" text="Dodaj vozilo v svojo evidenco – lastnik, registracija, šasija in ostalo."
            action={<Button size="m" onClick={() => push({ name: 'vehicleForm' })}>Dodaj vozilo</Button>} />
        ) : (
          <>
            <div className="row" style={{ background: 'var(--bg-card)', borderRadius: 10, padding: '12px 16px', margin: '16px 0 8px', fontSize: 14, fontWeight: 500 }}>
              <span style={{ flex: 1 }}>Ime</span>
              <span style={{ width: 150 }}>Registrska številka</span>
            </div>
            {list.map((v) => (
              <SwipeRow key={v.id} className="card-row" onEdit={() => push({ name: 'vehicleForm', id: v.id })} onDelete={() => remove.vehicle(v.id)}>
              <button className="listrow" style={{ padding: '12px 12px 12px 16px' }}
                onClick={() => openVehicle(v.id)}>
                <div className="main">
                  <div className="t1" style={{ fontSize: 17 }}>{v.owner || 'Brez imena'}</div>
                  <div className="t2">{[v.brand, v.model].filter(Boolean).join(' ') || '—'}</div>
                </div>
                <span className="t-b15" style={{ width: 118 }}>{v.plate}</span>
                <ChevronRight size={20} />
              </button>
              </SwipeRow>
            ))}
            {list.length > 0 && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
          </>
        )}
      </div>
      <Sheet open={sortOpen} onClose={() => setSortOpen(false)} title="Razvrsti vozila">
        <button className="listrow" style={{ width: '100%' }} onClick={() => chooseSort('owner')}>
          <div className="ico"><ArrowDownAZ size={20} /></div>
          <div className="main"><div className="t1">Ime voznika</div><div className="t2">Po abecedi od A do Ž</div></div>
          <Radio on={sortMode === 'owner'} />
        </button>
        <button className="listrow" style={{ width: '100%' }} onClick={() => chooseSort('recent')}>
          <div className="ico"><History size={20} /></div>
          <div className="main"><div className="t1">Zadnje odprto vozilo</div><div className="t2">Nazadnje obiskana vozila so na vrhu</div></div>
          <Radio on={sortMode === 'recent'} />
        </button>
      </Sheet>
    </Screen>
  );
}
