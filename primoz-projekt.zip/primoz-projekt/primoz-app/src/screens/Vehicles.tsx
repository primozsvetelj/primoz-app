import { ChevronRight, Car } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader, Empty, Button, SwipeRow } from '../ui/components';
import { useDelete } from '../ui/actions';
import { useVehicles } from '../lib/hooks';

export function VehiclesScreen() {
  const { push } = useNav();
  const remove = useDelete();
  const vehicles = useVehicles();
  const list = vehicles ?? [];

  return (
    <Screen nav animate={false}>
      <SearchHeader onPlus={() => push({ name: 'vehicleForm' })} plusLabel="Novo vozilo" />
      <div className="scroll">
        <div className="h-big">Vozila</div>
        {vehicles && vehicles.length === 0 ? (
          <Empty icon={<Car size={30} />} title="Ni še nobenega vozila" text="Dodaj vozilo v svojo evidenco – lastnik, registracija, šasija in ostalo."
            action={<Button size="m" onClick={() => push({ name: 'vehicleForm' })}>Dodaj vozilo</Button>} />
        ) : (
          <>
            <div className="row" style={{ background: 'var(--bg-card)', borderRadius: 10, padding: '12px 16px', margin: '16px 0 8px', fontSize: 14, fontWeight: 500 }}>
              <span style={{ flex: 1 }}>Ime</span>
              <span style={{ width: 150 }}>Registrska številka</span>
            </div>
            {list.map((v) => (
              <SwipeRow key={v.id} className="card-row" onEdit={() => push({ name: 'vehicleForm', id: v.id })} onDelete={() => remove.vehicle(v.id)}>
              <button className="listrow" style={{ padding: '12px 12px 12px 16px' }}
                onClick={() => push({ name: 'vehicle', id: v.id })}>
                <div className="main">
                  <div className="t1" style={{ fontSize: 17 }}>{v.owner || 'Brez imena'}</div>
                  <div className="t2">{[v.brand, v.model].filter(Boolean).join(' ') || '—'}</div>
                </div>
                <span className="t-b15" style={{ width: 118 }}>{v.plate}</span>
                <ChevronRight size={20} />
              </button>
              </SwipeRow>
            ))}
            {list.length > 0 && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
          </>
        )}
      </div>
    </Screen>
  );
}
