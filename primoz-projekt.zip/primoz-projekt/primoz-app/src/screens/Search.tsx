import { useState } from 'react';
import { ArrowLeft, Search, X, ChevronRight, Wrench, Bell, SearchX } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, Chip, VehicleTypeIcon, Empty } from '../ui/components';
import { useReminders, useServices, useServiceTypes, useVehicles } from '../lib/hooks';
import { fmtDate, fmtShort, nextOccurrence, todayISO } from '../lib/dates';
import { vehicleLabel } from '../lib/db';

type F = 'all' | 'vehicles' | 'services' | 'reminders';
const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[\s-]+/g, '');

export function SearchScreen({ filter: initial = 'all' }: { filter?: F }) {
  const { back, push } = useNav();
  const [q, setQ] = useState('');
  const [f, setF] = useState<F>(initial);
  const vehicles = useVehicles() ?? [];
  const services = useServices() ?? [];
  const reminders = useReminders() ?? [];
  const stypes = new Map((useServiceTypes() ?? []).map((t) => [t.id, t.name]));
  const vmap = new Map(vehicles.map((v) => [v.id, v]));
  const n = norm(q);
  const hit = (...parts: (string | undefined)[]) => !n || parts.some((p) => p && norm(p).includes(n));

  const vRes = f === 'all' || f === 'vehicles' ? vehicles.filter((v) => hit(v.owner, v.brand, v.model, v.plate, v.vin, `${v.brand} ${v.model}`)) : [];
  const sRes = f === 'all' || f === 'services' ? services.filter((s) => { const v = vmap.get(s.vehicleId); return hit(s.title, stypes.get(s.typeId), v?.owner, v?.plate, v?.model, v?.brand); }).sort((a, b) => b.date.localeCompare(a.date)) : [];
  const rRes = f === 'all' || f === 'reminders' ? reminders.filter((r) => { const v = vmap.get(r.vehicleId); return hit(r.title, v?.owner, v?.plate, v?.model, v?.brand); }) : [];
  const total = vRes.length + sRes.length + rRes.length;
  const suggestionPool = [
    ...(f === 'all' || f === 'vehicles' ? vehicles.flatMap((v) => [v.owner, v.plate, v.brand, v.model, [v.brand, v.model].filter(Boolean).join(' ')]) : []),
    ...(f === 'all' || f === 'services' ? services.flatMap((s) => [s.title, stypes.get(s.typeId)]) : []),
    ...(f === 'all' || f === 'reminders' ? reminders.map((r) => r.title) : []),
  ].filter((x): x is string => !!x?.trim());
  const suggestions = q.trim() ? [...new Map(suggestionPool.map((x) => [norm(x), x.trim()])).values()]
    .filter((x) => norm(x).includes(n))
    .sort((a, b) => Number(!norm(a).startsWith(n)) - Number(!norm(b).startsWith(n)) || a.localeCompare(b, 'sl'))
    .slice(0, 3) : [];

  return (
    <Screen>
      <div className="searchrow" style={{ paddingTop: 14 }}>
        <button className="iconbtn" aria-label="Nazaj" onClick={() => back()}><ArrowLeft size={24} /></button>
        <label className="searchbar focus" style={{ borderRadius: 12 }}>
          <Search size={20} color="var(--text)" />
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Išči vozila, servise, opomnike …" />
          {q && <button aria-label="Počisti" onClick={() => setQ('')}><X size={20} color="var(--text)" /></button>}
        </label>
      </div>
      <div className="chips" style={{ padding: '14px 16px 0' }}>
        <Chip on={f === 'all'} onClick={() => setF('all')}>Vse</Chip>
        <Chip on={f === 'vehicles'} onClick={() => setF('vehicles')}>Vozila</Chip>
        <Chip on={f === 'services'} onClick={() => setF('services')}>Servisi</Chip>
        <Chip on={f === 'reminders'} onClick={() => setF('reminders')}>Opomniki</Chip>
      </div>
      {suggestions.length > 0 && (
        <div className="chips" style={{ padding: '10px 16px 0' }} aria-label="Predlogi iskanja">
          {suggestions.map((s) => <Chip key={s} on={norm(s) === n} onClick={() => setQ(s)}>{s}</Chip>)}
        </div>
      )}
      <div className="scroll">
        {total === 0 && <Empty icon={<SearchX size={28} />} title={q ? 'Ni rezultatov' : 'Ni podatkov za iskanje'} text={q ? `Za »${q}« ni zadetkov. Poskusi z registracijo ali imenom lastnika.` : undefined} />}
        {vRes.length > 0 && <div className="h-sec">Vozila</div>}
        {vRes.slice(0, 30).map((v) => (
          <button key={v.id} className="listrow" onClick={() => push({ name: 'vehicle', id: v.id })}>
            <div className="ico"><VehicleTypeIcon type={v.type} /></div>
            <div className="main"><div className="t1">{v.owner}</div><div className="t2">{vehicleLabel(v)}{v.plate ? ' · ' + v.plate : ''}</div></div>
            <ChevronRight size={20} />
          </button>
        ))}
        {sRes.length > 0 && <div className="h-sec">Servisi</div>}
        {sRes.slice(0, 30).map((s) => (
          <button key={s.id} className="listrow" onClick={() => push({ name: 'service', id: s.id })}>
            <div className="ico"><Wrench size={20} /></div>
            <div className="main"><div className="t1">{s.title}</div><div className="t2">{vehicleLabel(vmap.get(s.vehicleId))} · {fmtDate(s.date)}</div></div>
            <ChevronRight size={20} />
          </button>
        ))}
        {rRes.length > 0 && <div className="h-sec">Opomniki</div>}
        {rRes.slice(0, 30).map((r) => {
          const occ = nextOccurrence(r, todayISO()) ?? r.date;
          return (
            <button key={r.id} className="listrow" onClick={() => push({ name: 'reminder', id: r.id, occ })}>
              <div className="ico"><Bell size={20} /></div>
              <div className="main"><div className="t1">{r.title}</div><div className="t2">{vehicleLabel(vmap.get(r.vehicleId))} · {fmtDate(occ)}</div></div>
              <span className="datechip">{fmtShort(occ)}</span>
              <ChevronRight size={20} />
            </button>
          );
        })}
      </div>
    </Screen>
  );
}
