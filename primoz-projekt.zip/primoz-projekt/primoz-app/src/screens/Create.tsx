import type { ReactNode } from 'react';
import { Car, Wrench, Droplet, List, Plus, UsersRound } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader } from '../ui/components';

function Tile({ icon, bg, color, title, sub, onClick }: { icon: ReactNode; bg: string; color: string; title: string; sub: string; onClick: () => void }) {
  return (
    <button className="card" style={{ padding: 14, textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 0, minHeight: 122 }} onClick={onClick}>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: bg, color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>
        <span className="spacer" />
        <Plus size={22} />
      </div>
      <div className="t-b16" style={{ marginTop: 16 }}>{title}</div>
      <div className="t-r12 c2" style={{ marginTop: 3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sub}</div>
    </button>
  );
}

export function CreateScreen() {
  const { push } = useNav();

  return (
    <Screen nav animate={false}>
      <SearchHeader />
      <div className="scroll">
        <div className="h-big">Kreiraj</div>
        <div className="grid2" style={{ gap: 12 }}>
          <Tile icon={<Car size={22} />} bg="var(--bg-selected)" color="var(--violet)" title="Novo vozilo" sub="Avto, kombi ali motor" onClick={() => push({ name: 'vehicleForm' })} />
          <Tile icon={<Wrench size={22} />} bg="var(--bg-selected)" color="var(--violet)" title="Popravilo" sub="Zapiši, kaj si danes naredil" onClick={() => push({ name: 'serviceForm', history: true })} />
          <Tile icon={<Droplet size={22} />} bg="var(--orange-bg)" color="var(--orange)" title="Olja in tekočine" sub="Olje, zavorna tekočina …" onClick={() => push({ name: 'fluidForm' })} />
          <Tile icon={<UsersRound size={22} />} bg="var(--success-bg)" color="var(--success)" title="Stranke" sub="Pregled in dodajanje strank" onClick={() => push({ name: 'customers' })} />
          <Tile icon={<List size={22} />} bg="var(--success-bg)" color="var(--success)" title="Lastno polje" sub="Svoj podatek o vozilu" onClick={() => push({ name: 'fields' })} />
        </div>
      </div>
    </Screen>
  );
}
