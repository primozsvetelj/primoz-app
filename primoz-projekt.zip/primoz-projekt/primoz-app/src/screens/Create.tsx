import type { ReactNode } from 'react';
import { Car, Wrench, Droplet, List, Plus, UsersRound } from 'lucide-react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader } from '../ui/components';
import { db, alive } from '../lib/db';
import { relativeDays } from '../lib/dates';

function Tile({ icon, bg, color, title, sub, onClick }: { icon: ReactNode; bg: string; color: string; title: string; sub: string; onClick: () => void }) {
  return (
    <button className="card" style={{ padding: 14, textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 0, minHeight: 122 }} onClick={onClick}>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: bg, color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>
        <span className="spacer" />
        <Plus size={22} />
      </div>
      <div className="t-b16" style={{ marginTop: 16 }}>{title}</div>
      <div className="t-r12 c2" style={{ marginTop: 3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sub}</div>
    </button>
  );
}

export function CreateScreen() {
  const { push } = useNav();
  const recent = useLiveQuery(async () => {
    const vehicles = new Map((await db.vehicles.toArray()).filter(alive).map((v) => [v.id, v]));
    const stypes = new Map((await db.serviceTypes.toArray()).map((t) => [t.id, t]));
    const ftypes = new Map((await db.fluidTypes.toArray()).map((t) => [t.id, t]));
    const s = (await db.services.orderBy('updatedAt').reverse().limit(20).toArray()).filter((x) => alive(x) && vehicles.has(x.vehicleId))
      .map((x) => ({ kind: 'service' as const, id: x.id, vehicleId: x.vehicleId, title: stypes.get(x.typeId)?.name ?? x.title, owner: vehicles.get(x.vehicleId)!.owner, at: x.createdAt }));
    const f = (await db.fluids.orderBy('updatedAt').reverse().limit(20).toArray()).filter((x) => alive(x) && vehicles.has(x.vehicleId))
      .map((x) => ({ kind: 'fluid' as const, id: x.id, vehicleId: x.vehicleId, title: ftypes.get(x.typeId)?.name ?? 'Tekočina', owner: vehicles.get(x.vehicleId)!.owner, at: x.createdAt }));
    return [...s, ...f].sort((a, b) => b.at - a.at).slice(0, 5);
  }, []);

  return (
    <Screen nav animate={false}>
      <SearchHeader />
      <div className="scroll">
        <div className="h-big">Kreiraj</div>
        <div className="grid2" style={{ gap: 12 }}>
          <Tile icon={<Car size={22} />} bg="var(--bg-selected)" color="var(--violet)" title="Novo vozilo" sub="Avto, kombi ali motor" onClick={() => push({ name: 'vehicleForm' })} />
          <Tile icon={<Wrench size={22} />} bg="var(--bg-selected)" color="var(--violet)" title="Servis" sub="Zabeleži opravljen servis" onClick={() => push({ name: 'serviceForm' })} />
          <Tile icon={<Droplet size={22} />} bg="var(--orange-bg)" color="var(--orange)" title="Olja in tekočine" sub="Olje, zavorna tekočina …" onClick={() => push({ name: 'fluidForm' })} />
          <Tile icon={<UsersRound size={22} />} bg="var(--success-bg)" color="var(--success)" title="Stranke" sub="Pregled in dodajanje strank" onClick={() => push({ name: 'customers' })} />
          <Tile icon={<List size={22} />} bg="var(--success-bg)" color="var(--success)" title="Lastno polje" sub="Svoj podatek o vozilu" onClick={() => push({ name: 'fields' })} />
        </div>
        <div className="h-sec" style={{ marginTop: 24 }}>Nedavno uporabljeno</div>
        {recent && recent.length === 0 && <div className="t-r14 c2">Tukaj se prikažejo zadnji servisi in tekočine, ki jih lahko hitro ponoviš.</div>}
        {recent?.map((r) => (
          <div key={r.kind + r.id} className="listrow">
            <div className="ico" style={{ background: r.kind === 'service' ? 'var(--bg-selected)' : 'var(--orange-bg)', color: r.kind === 'service' ? 'var(--violet)' : 'var(--orange)' }}>
              {r.kind === 'service' ? <Wrench size={20} /> : <Droplet size={20} />}
            </div>
            <div className="main">
              <div className="t1">{r.title}</div>
              <div className="t2">{r.owner} · {relativeDays(r.at)}</div>
            </div>
            <button className="btn secondary s" onClick={() => push(r.kind === 'service' ? { name: 'serviceForm', copyFrom: r.id, vehicleId: r.vehicleId } : { name: 'fluidForm', copyFrom: r.id, vehicleId: r.vehicleId })}>Ponovi</button>
          </div>
        ))}
      </div>
    </Screen>
  );
}
