import { useEffect, useState, type ReactNode } from 'react';
import { Bell, ChevronRight, Download, Cloud, LogOut, Pencil, Check, Upload, CloudUpload, CircleCheck, Share2, FileUp, Unlink, KeyRound, Smartphone } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, SearchHeader, TopBar, Toggle, Button, Label, TextField, ChipGroup } from '../ui/components';
import { useMeta } from '../lib/hooks';
import { setMeta } from '../lib/db';
import { updateProfile, type Profile } from '../lib/auth';
import { APP_VERSION, type Session } from '../lib/account';
import { ChangePasswordForm } from './Gate';
import { requestNotificationPermission, rescheduleAll } from '../lib/notifications';
import { fmtTimestamp, plural } from '../lib/dates';
import { buildExport, type ExportFormat, type ExportPeriod } from '../lib/exporter';
import { saveFiles, shareFiles, pickFile, fileToDataUrl, isNative, type SavedFile } from '../lib/native';
import { backupNow, restoreFromDrive, pendingCount, connectGoogle, disconnectGoogle, mergeRecords, GOOGLE_WEB_CLIENT_ID, type DeltaFile } from '../lib/sync';

export { APP_VERSION };

function SettingRow({ icon, title, value, onClick, right }: { icon: ReactNode; title: string; value?: string; onClick?: () => void; right?: ReactNode }) {
  return (
    <div role="button" tabIndex={0} className="row" style={{ width: '100%', padding: '12px 14px', minHeight: 56, textAlign: 'left', gap: 14, cursor: 'pointer' }} onClick={onClick} onKeyDown={(e) => { if (e.key === 'Enter') onClick?.(); }}>
      <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--bg-field)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</span>
      <span className="t-b16" style={{ flex: 1 }}>{title}</span>
      {value && <span className="t-r14 c2">{value}</span>}
      {right ?? <ChevronRight size={20} />}
    </div>
  );
}

export function Avatar({ profile, size = 52 }: { profile: Profile | null; size?: number }) {
  if (profile?.avatar) return <img src={profile.avatar} alt="" style={{ width: size, height: size, borderRadius: size / 2, objectFit: 'cover', flex: 'none' }} />;
  return <span style={{ width: size, height: size, borderRadius: size / 2, background: 'var(--violet)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.38, fontWeight: 500, flex: 'none' }}>{(profile?.name || 'P')[0].toUpperCase()}</span>;
}

export function SettingsScreen({ onLogout }: { onLogout: () => void }) {
  const { push, confirm } = useNav();
  const local = useMeta<Profile | null>('profile', null);
  const session = useMeta<Session | null>('session', null);
  const profile: Profile = { name: session?.account.name || session?.account.email || 'Profil', email: session?.account.email ?? '', phone: local?.phone ?? '', avatar: local?.avatar ?? '' };
  const notif = useMeta('notifications', true);
  const lastBackup = useMeta('lastBackupAt', 0);

  const toggleNotif = async (on: boolean) => {
    if (on && !(await requestNotificationPermission())) { await setMeta('notifications', false); return; }
    await setMeta('notifications', on);
    await rescheduleAll();
  };
  const doLogout = async () => {
    if (!(await confirm({ title: 'Odjava', text: 'Ali se res želiš odjaviti? Podatki ostanejo na telefonu. Za ponovno prijavo potrebuješ internet in geslo.', okLabel: 'Odjava', danger: true }))) return;
    onLogout();
  };

  return (
    <Screen nav animate={false}>
      <SearchHeader />
      <div className="scroll">
        <div className="h-big">Nastavitve</div>
        <div className="card row" style={{ padding: 16, gap: 12 }}>
          <Avatar profile={profile} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="row" style={{ gap: 8 }}><span className="t-kartica" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{profile.name}</span></div>
            <div className="t-r14 c2" style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{profile?.email}</div>
          </div>
          <Button variant="secondary" size="s" icon={<Pencil size={16} />} onClick={() => push({ name: 'profile' })}>Uredi</Button>
        </div>

        <div className="label" style={{ marginTop: 20 }}>Splošno</div>
        <div className="card">
          <SettingRow icon={<Bell size={18} />} title="Obvestila" onClick={() => toggleNotif(!notif)} right={<span onClick={(e) => e.stopPropagation()}><Toggle on={notif} onChange={toggleNotif} label="Obvestila" /></span>} />
          <div className="divider" />
          <SettingRow icon={<KeyRound size={18} />} title="Spremeni geslo" onClick={() => push({ name: 'password' })} />
        </div>

        <div className="label" style={{ marginTop: 20 }}>Račun</div>
        <div className="card">
          <SettingRow icon={<Smartphone size={18} />} title="Zadnja potrditev" value={session ? fmtTimestamp(session.lastOkLocal) : '—'} right={<span />} />
        </div>

        <div className="label" style={{ marginTop: 20 }}>Podatki</div>
        <div className="card">
          <SettingRow icon={<Download size={18} />} title="Izvoz podatkov" value="CSV" onClick={() => push({ name: 'export' })} />
          <div className="divider" />
          <SettingRow icon={<Cloud size={18} />} title="Varnostna kopija" value={lastBackup ? fmtTimestamp(lastBackup) : 'Še ni'} onClick={() => push({ name: 'backup' })} />
        </div>

        <Button variant="danger" style={{ width: '100%', marginTop: 20 }} icon={<LogOut size={20} />} onClick={doLogout}>Odjava</Button>
        <div className="t-r12 cdis" style={{ textAlign: 'center', marginTop: 16 }}>Različica {APP_VERSION}</div>
      </div>
    </Screen>
  );
}

export function ProfileScreen() {
  const { back, toast } = useNav();
  const local = useMeta<Profile | null>('profile', null);
  const session = useMeta<Session | null>('session', null);
  const [f, setF] = useState({ phone: '', avatar: '' });
  useEffect(() => { if (local) setF({ phone: local.phone ?? '', avatar: local.avatar ?? '' }); }, [local]);
  const profile: Profile = { name: session?.account.name || session?.account.email || 'P', email: session?.account.email ?? '', ...f };

  const pick = async () => {
    const file = await pickFile('image/*');
    if (!file) return;
    try {
      const url = await fileToDataUrl(file);
      setF((p) => ({ ...p, avatar: url }));
    } catch {
      toast('Slike ni bilo mogoče prebrati');
    }
  };
  const submit = async () => {
    await updateProfile(f);
    toast('Profil shranjen');
    back();
  };

  return (
    <Screen>
      <TopBar close title="Uredi profil" obrazec />
      <div className="scroll">
        <div className="card" style={{ padding: '16px 16px 18px', marginTop: 8 }}>
          <div className="row" style={{ gap: 12 }}>
            <Avatar profile={profile} size={64} />
            {f.avatar && <Button variant="ghost" size="s" onClick={() => setF((p) => ({ ...p, avatar: '' }))}>Odstrani</Button>}
            <Button variant="secondary" size="s" icon={<Pencil size={16} />} onClick={pick}>Spremeni sliko</Button>
          </div>
          <Label>Ime in priimek</Label>
          <div className="t-b16" style={{ padding: '4px 2px' }}>{session?.account.name || '—'}</div>
          <Label>E-pošta (prijava)</Label>
          <div className="t-b16" style={{ padding: '4px 2px' }}>{session?.account.email}</div>
          <div className="t-r12 c2" style={{ marginTop: 4 }}>Ime in e-pošto računa ureja administrator.</div>
          <Label>Telefon</Label>
          <TextField value={f.phone} onChange={(v) => setF((p) => ({ ...p, phone: v }))} placeholder="+386 …" inputMode="tel" type="tel" />
        </div>
      </div>
      <div className="footer">
        <Button variant="secondary" onClick={() => back()}>Prekliči</Button>
        <Button icon={<Check size={20} />} onClick={submit}>Shrani</Button>
      </div>
    </Screen>
  );
}

export function PasswordScreen() {
  const { back, toast } = useNav();
  return (
    <Screen>
      <TopBar close title="Spremeni geslo" obrazec />
      <div className="scroll">
        <ChangePasswordForm onDone={() => { toast('Geslo spremenjeno'); back(); }} onCancel={() => back()} />
      </div>
    </Screen>
  );
}

const FORMATS: { id: ExportFormat; label: string }[] = [{ id: 'csv', label: 'CSV' }, { id: 'xlsx', label: 'Excel' }, { id: 'pdf', label: 'PDF' }, { id: 'json', label: 'JSON kopija' }];
const PERIODS: { id: ExportPeriod; label: string }[] = [{ id: 'month', label: 'Zadnji mesec' }, { id: 'year', label: 'Letos' }, { id: 'all', label: 'Vse' }];

export function ExportScreen() {
  const { toast } = useNav();
  const [format, setFormat] = useState<ExportFormat>('csv');
  const [period, setPeriod] = useState<ExportPeriod>('all');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<SavedFile[] | null>(null);

  const run = async () => {
    setBusy(true);
    try {
      const files = await buildExport(format, period);
      const saved = await saveFiles(files);
      setDone(saved);
    } catch (e) {
      toast('Izvoz ni uspel: ' + (e as Error).message);
    } finally { setBusy(false); }
  };

  if (done) {
    return (
      <Screen>
        <TopBar title="Izvoz podatkov" onBack={() => setDone(null)} />
        <div className="scroll" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', paddingTop: 40 }}>
          <div style={{ width: 72, height: 72, borderRadius: 36, background: 'var(--success-bg)', color: 'var(--success)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><CircleCheck size={36} /></div>
          <div className="t-dialog" style={{ marginTop: 18 }}>Izvoz uspešen</div>
          <div className="t-r14 c2" style={{ marginTop: 8, lineHeight: 1.5 }}>
            {done.length === 1 ? 'Datoteka je shranjena' : `${done.length} datoteke so shranjene`} v mapo <b style={{ color: 'var(--text)' }}>{done[0].location}</b>.<br />
            Na računalnik jo preneseš prek USB kabla ali z gumbom Deli (e-pošta, Drive, Quick Share …).
          </div>
          <div className="card" style={{ width: '100%', marginTop: 20, padding: '4px 16px', textAlign: 'left' }}>
            {done.map((d) => <div key={d.name} className="kv"><span className="t-r14" style={{ overflowWrap: 'anywhere' }}>{d.name}</span></div>)}
          </div>
        </div>
        <div className="footer">
          <Button variant="secondary" onClick={() => setDone(null)}>Končano</Button>
          {isNative && <Button icon={<Share2 size={20} />} onClick={() => shareFiles(done)}>Deli</Button>}
        </div>
      </Screen>
    );
  }

  return (
    <Screen>
      <TopBar title="Izvoz podatkov" />
      <div className="subtitle">Izvozi evidenco v datoteko (za računalnik)</div>
      <div className="scroll">
        <div className="card" style={{ padding: '2px 16px 16px' }}>
          <Label>Format</Label>
          <ChipGroup value={format} options={FORMATS} onChange={setFormat} />
          {format !== 'json' && (<><Label>Obdobje</Label><ChipGroup value={period} options={PERIODS} onChange={setPeriod} /></>)}
          <div className="t-r13 c2" style={{ marginTop: 14, lineHeight: 1.45 }}>
            {format === 'csv' && 'Ločene CSV datoteke za stranke, vozila, servise, opomnike in tekočine (odpre jih Excel).'}
            {format === 'xlsx' && 'En Excel delovni zvezek z zavihki: Vozila, Servisi, Opomniki, Olja in tekočine.'}
            {format === 'pdf' && 'Pregledno poročilo za tisk ali arhiv.'}
            {format === 'json' && 'Popolna kopija vseh podatkov – lahko jo kasneje uvoziš nazaj (Varnostna kopija → Uvozi iz datoteke).'}
          </div>
        </div>
      </div>
      <div className="footer">
        <Button icon={<Download size={20} />} onClick={run} loading={busy}>Izvozi</Button>
      </div>
    </Screen>
  );
}

export function BackupScreen() {
  const { toast, confirm } = useNav();
  const lastBackup = useMeta('lastBackupAt', 0);
  const bytes = useMeta('backupBytes', 0);
  const auto = useMeta('autoBackup', false);
  const gEmail = useMeta('gEmail', '');
  const lastSync = useMeta('lastSyncAt', 0);
  const [pending, setPending] = useState<number | null>(null);
  const [busy, setBusy] = useState<'' | 'backup' | 'restore' | 'connect' | 'import'>('');

  useEffect(() => { pendingCount().then(setPending); }, [lastSync, busy]);

  const err = (e: unknown) => toast((e as Error).message || 'Napaka');

  const run = async () => {
    setBusy('backup');
    try {
      const r = await backupNow(true);
      toast(r.uploaded ? `Naloženo ${plural(r.uploaded, 'sprememba', 'spremembi', 'spremembe', 'sprememb')} v Google Drive` : 'Ni novih sprememb – kopija je ažurna');
    } catch (e) { err(e); } finally { setBusy(''); }
  };
  const restoreIt = async () => {
    if (!(await confirm({ title: 'Obnovi iz kopije?', text: 'Podatki iz Google Drive se združijo s podatki na telefonu. Novejša različica posameznega zapisa obvelja.', okLabel: 'Obnovi' }))) return;
    setBusy('restore');
    try {
      const r = await restoreFromDrive();
      await rescheduleAll();
      toast(r.files ? `Obnovljeno: ${plural(r.applied, 'zapis', 'zapisa', 'zapisi', 'zapisov')} iz ${r.files} kopij` : 'Na Drive ni kopij');
    } catch (e) { err(e); } finally { setBusy(''); }
  };
  const connect = async () => {
    setBusy('connect');
    try { await connectGoogle(false); toast('Google Drive povezan'); } catch (e) { err(e); } finally { setBusy(''); }
  };
  const importFile = async () => {
    const file = await pickFile('application/json,.json');
    if (!file) return;
    setBusy('import');
    try {
      const data = JSON.parse(await file.text()) as DeltaFile;
      if (data.app !== 'primoz-app') throw new Error('To ni kopija Primož app.');
      const n = await mergeRecords(data.records);
      await rescheduleAll();
      toast(`Uvoženo: ${plural(n, 'zapis', 'zapisa', 'zapisi', 'zapisov')}`);
    } catch (e) { err(e); } finally { setBusy(''); }
  };

  return (
    <Screen>
      <TopBar title="Varnostna kopija" />
      <div className="subtitle">Shrani podatke v oblak (Google Drive). Naložijo se samo novi in spremenjeni podatki.</div>
      <div className="scroll">
        <div className="card" style={{ padding: '14px 16px 4px' }}>
          <div className="t-kartica" style={{ marginBottom: 4 }}>Stanje</div>
          <div className="kv"><span className="k">Zadnja kopija</span><span className="v">{lastBackup ? fmtTimestamp(lastBackup) : 'Še ni'}</span></div>
          <div className="kv"><span className="k">Čaka na nalaganje</span><span className="v">{pending === null ? '…' : plural(pending, 'sprememba', 'spremembi', 'spremembe', 'sprememb')}</span></div>
          <div className="kv"><span className="k">Velikost v oblaku</span><span className="v">{bytes ? (bytes > 1e6 ? (bytes / 1e6).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(bytes / 1024)) + ' KB') : '—'}</span></div>
          <div className="kv"><span className="k">Google račun</span><span className="v">{gEmail || 'Ni povezan'}</span></div>
        </div>

        <div className="card" style={{ padding: '14px 16px', marginTop: 12 }}>
          <div className="t-kartica" style={{ marginBottom: 10 }}>Nastavitve</div>
          <div className="row">
            <div style={{ flex: 1 }}>
              <div className="t-b16">Samodejna kopija</div>
              <div className="t-r13 c2">Enkrat dnevno ob odprtju aplikacije</div>
            </div>
            <Toggle on={auto} label="Samodejna kopija" onChange={(on) => setMeta('autoBackup', on)} />
          </div>
        </div>

        {!GOOGLE_WEB_CLIENT_ID && (
          <div className="card" style={{ padding: 14, marginTop: 12, borderColor: 'var(--orange)', background: 'var(--orange-bg)' }}>
            <div className="t-b15 co">Google Drive še ni nastavljen</div>
            <div className="t-r13" style={{ marginTop: 4, lineHeight: 1.45 }}>Razvijalec mora vpisati Google OAuth Client ID (glej NAVODILA.md). Do takrat uporabi Izvoz podatkov → JSON kopija.</div>
          </div>
        )}

        {gEmail ? (
          <button className="listrow" style={{ marginTop: 12 }} onClick={restoreIt} disabled={!!busy}>
            <div className="ico"><Cloud size={20} /></div>
            <div className="main"><div className="t1">Obnovi iz kopije</div><div className="t2">Povrni podatke iz Google Drive</div></div>
            {busy === 'restore' ? <span className="spin" style={{ width: 18, height: 18, border: '2px solid var(--text)', borderRightColor: 'transparent', borderRadius: 9 }} /> : <ChevronRight size={20} />}
          </button>
        ) : (
          <button className="listrow" style={{ marginTop: 12 }} onClick={connect} disabled={!!busy}>
            <div className="ico"><CloudUpload size={20} /></div>
            <div className="main"><div className="t1">Poveži Google Drive</div><div className="t2">Prijava z Google računom</div></div>
            <ChevronRight size={20} />
          </button>
        )}
        <button className="listrow" onClick={importFile} disabled={!!busy}>
          <div className="ico"><FileUp size={20} /></div>
          <div className="main"><div className="t1">Uvozi iz datoteke</div><div className="t2">JSON kopija z računalnika ali telefona</div></div>
          <ChevronRight size={20} />
        </button>
        {gEmail && (
          <button className="listrow" onClick={async () => { if (await confirm({ title: 'Prekini povezavo?', text: 'Kopije na Google Drive ostanejo. Za nadaljnje kopije se boš moral znova prijaviti.', okLabel: 'Prekini' })) { await disconnectGoogle(); toast('Povezava prekinjena'); } }}>
            <div className="ico"><Unlink size={20} /></div>
            <div className="main"><div className="t1">Prekini povezavo z Google</div><div className="t2">{gEmail}</div></div>
          </button>
        )}
      </div>
      <div className="footer">
        <Button icon={<Upload size={20} />} onClick={run} loading={busy === 'backup' || busy === 'connect'}>Ustvari kopijo zdaj</Button>
      </div>
    </Screen>
  );
}
