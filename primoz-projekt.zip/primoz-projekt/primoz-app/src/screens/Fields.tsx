import { useEffect, useRef, useState } from 'react';
import { GripVertical, Plus, Check, Trash2, Car } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, TopBar, Label, TextField, Button, Toggle, Sheet, ChipGroup, VehiclePickerSheet, Chip } from '../ui/components';
import { db, save, patch, softDelete, restore, getMeta, setMeta, type FieldDef, type FieldType } from '../lib/db';
import { useFieldDefs, useServices, useVehicles } from '../lib/hooks';
import { fieldValue } from './VehicleDetail';

const TYPES: { id: FieldType; label: string }[] = [{ id: 'text', label: 'Besedilo' }, { id: 'number', label: 'Številka' }, { id: 'date', label: 'Datum' }];
const ROW_H = 60;

export function FieldsScreen({ vehicleId: initialVehicle }: { vehicleId?: string }) {
  const { push, toast } = useNav();
  const vehicles = useVehicles() ?? [];
  const defs = useFieldDefs() ?? [];
  const services = useServices();
  const [vehicleId, setVehicleId] = useState(initialVehicle ?? '');
  const [pickV, setPickV] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState<FieldType>('text');
  const [editing, setEditing] = useState<FieldDef | null>(null);
  const [order, setOrder] = useState<string[]>([]);
  const [drag, setDrag] = useState<{ id: string; startY: number; dy: number } | null>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!vehicleId && vehicles.length) {
      getMeta('lastFieldsVehicle', '').then((id) => setVehicleId(vehicles.find((v) => v.id === id) ? (id as string) : vehicles[0].id));
    }
  }, [vehicleId, vehicles]);
  useEffect(() => { if (vehicleId) setMeta('lastFieldsVehicle', vehicleId); }, [vehicleId]);
  useEffect(() => { if (!drag) setOrder(defs.map((d) => d.id)); }, [defs, drag]);

  const v = vehicles.find((x) => x.id === vehicleId);
  const ordered = order.map((id) => defs.find((d) => d.id === id)).filter(Boolean) as FieldDef[];

  const add = async () => {
    const n = name.trim();
    if (!n) return;
    if (defs.some((d) => d.name.toLowerCase() === n.toLowerCase())) { toast('Polje s tem imenom že obstaja'); return; }
    const maxOrder = Math.max(0, ...defs.filter((d) => d.builtin !== 'lastService').map((d) => d.order));
    const f = await save(db.fieldDefs, { name: n, type, active: 1, order: maxOrder + 1 });
    setName('');
    toast('Polje dodano');
    if (v) setEditing(f);
  };

  // --- premikanje vrstic ---
  const onDown = (id: string, e: React.PointerEvent) => {
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setDrag({ id, startY: e.clientY, dy: 0 });
  };
  const onMove = (e: React.PointerEvent) => {
    if (!drag) return;
    const dy = e.clientY - drag.startY;
    const idx = order.indexOf(drag.id);
    const target = Math.max(0, Math.min(order.length - 1, idx + Math.round(dy / ROW_H)));
    if (target !== idx) {
      const next = order.filter((x) => x !== drag.id);
      next.splice(target, 0, drag.id);
      setOrder(next);
      setDrag({ ...drag, startY: drag.startY + (target - idx) * ROW_H, dy: dy - (target - idx) * ROW_H });
    } else setDrag({ ...drag, dy });
  };
  const onUp = async () => {
    if (!drag) return;
    setDrag(null);
    const changed = order.map((id, i) => ({ id, i })).filter(({ id, i }) => defs.find((d) => d.id === id)?.order !== i);
    for (const c of changed) await patch(db.fieldDefs, c.id, { order: c.i });
  };

  return (
    <Screen nav>
      <TopBar title="Lastna polja" />
      <div className="t-r15 c2" style={{ padding: '0 16px 12px' }}>Prilagodi podatke posameznega vozila</div>
      <div className="scroll">
        <button className="card" style={{ width: '100%', textAlign: 'left', padding: '10px 14px', background: 'var(--bg-selected)', borderColor: 'var(--violet)' }} onClick={() => setPickV(true)}>
          {v ? (<><div className="t-kartica">{v.owner}</div><div className="t-r14 c2">{[v.brand, v.model].filter(Boolean).join(' ')}{v.plate ? ' · ' + v.plate : ''}</div></>)
            : <div className="row"><Car size={20} /><span className="t-b15">{vehicles.length ? 'Izberi vozilo' : 'Ni vozil – polja se vseeno lahko dodajo'}</span></div>}
        </button>

        <div className="t-sekcija" style={{ marginTop: 18, fontSize: 22 }}>Dodaj novo polje</div>
        <div className="t-r13 c2" style={{ marginTop: 2 }}>Ustvari lastno podatkovno polje (velja za vsa vozila)</div>
        <div className="card" style={{ padding: '2px 16px 16px', marginTop: 12 }}>
          <Label>Ime polja</Label>
          <TextField value={name} onChange={setName} placeholder="npr. Velikost platišč" onEnter={add} />
          <Label>Tip polja</Label>
          <div className="segment">
            {TYPES.map((t) => <Chip key={t.id} on={type === t.id} onClick={() => setType(t.id)}>{t.label}</Chip>)}
          </div>
          <Button size="m" style={{ width: '100%', marginTop: 14 }} icon={<Plus size={20} />} disabled={!name.trim()} onClick={add}>Dodaj polje</Button>
        </div>

        <div className="t-sekcija" style={{ marginTop: 20, fontSize: 22 }}>Aktivna polja</div>
        <div className="t-r13 c2" style={{ margin: '2px 0 12px' }}>Preuredi polja (drži ⋮⋮ in povleci) in nastavi njihovo vidnost</div>
        <div ref={listRef} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} style={{ touchAction: drag ? 'none' : undefined }}>
          {ordered.map((f) => {
            const val = v ? fieldValue(v, f, services) : '';
            const isDrag = drag?.id === f.id;
            return (
              <div key={f.id} className="card row" style={{
                height: ROW_H - 8, marginBottom: 8, marginTop: 0, padding: '0 8px 0 4px', gap: 6,
                transform: isDrag ? `translateY(${drag!.dy}px) scale(1.02)` : undefined, zIndex: isDrag ? 2 : undefined, position: 'relative',
                boxShadow: isDrag ? '0 8px 20px rgba(0,0,0,.5)' : undefined, transition: isDrag ? 'none' : 'transform .15s',
              }}>
                <span onPointerDown={(e) => onDown(f.id, e)} style={{ padding: '14px 6px', touchAction: 'none', cursor: 'grab' }} aria-label="Premakni"><GripVertical size={20} color="var(--text-2)" /></span>
                <button style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: 8, textAlign: 'left', height: '100%' }}
                  onClick={() => f.builtin ? (f.builtin !== 'lastService' && v && push({ name: 'vehicleForm', id: v.id })) : setEditing(f)}>
                  <span className="t-b16" style={{ width: 130, flex: 'none', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.name}</span>
                  <span className="t-r14 c2" style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{val || (f.builtin ? '—' : 'Vpiši vrednost')}</span>
                </button>
                <Toggle on={!!f.active} label={`Prikaži ${f.name}`} onChange={(on) => patch(db.fieldDefs, f.id, { active: on ? 1 : 0 })} />
              </div>
            );
          })}
        </div>
      </div>

      <VehiclePickerSheet open={pickV} vehicles={vehicles} value={vehicleId} onClose={() => setPickV(false)} onPick={(id) => { setVehicleId(id); setPickV(false); }} />
      <FieldValueSheet def={editing} vehicleId={vehicleId} onClose={() => setEditing(null)} />
    </Screen>
  );
}

function FieldValueSheet({ def, vehicleId, onClose }: { def: FieldDef | null; vehicleId: string; onClose: () => void }) {
  const { toast, confirm } = useNav();
  const [val, setVal] = useState('');
  const [nm, setNm] = useState('');
  const [tp, setTp] = useState<FieldType>('text');
  useEffect(() => {
    if (!def) return;
    setNm(def.name); setTp(def.type);
    if (vehicleId) db.vehicles.get(vehicleId).then((v) => setVal(v?.custom?.[def.id] ?? ''));
  }, [def, vehicleId]);
  if (!def) return null;

  const saveIt = async () => {
    if (nm.trim() && (nm.trim() !== def.name || tp !== def.type)) await patch(db.fieldDefs, def.id, { name: nm.trim(), type: tp });
    if (vehicleId) {
      const v = await db.vehicles.get(vehicleId);
      if (v) await patch(db.vehicles, v.id, { custom: { ...(v.custom ?? {}), [def.id]: val.trim() } });
    }
    toast('Shranjeno');
    onClose();
  };
  const del = async () => {
    if (!(await confirm({ title: 'Izbriši polje?', text: `Polje »${def.name}« bo odstranjeno z vseh vozil.`, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> }))) return;
    await softDelete(db.fieldDefs, def.id);
    onClose();
    toast('Polje izbrisano', { label: 'Razveljavi', run: () => restore(db.fieldDefs, def.id) });
  };

  return (
    <Sheet open={!!def} onClose={onClose} title={def.name}
      footer={<><Button variant="danger" style={{ flex: 1 }} icon={<Trash2 size={18} />} onClick={del}>Izbriši</Button><Button style={{ flex: 1 }} icon={<Check size={20} />} onClick={saveIt}>Shrani</Button></>}>
      {vehicleId && (
        <>
          <Label>Vrednost za to vozilo</Label>
          {tp === 'date'
            ? <label className="field"><input type="date" value={val} onChange={(e) => setVal(e.target.value)} /></label>
            : <TextField value={val} onChange={setVal} inputMode={tp === 'number' ? 'decimal' : 'text'} placeholder={tp === 'number' ? 'npr. 148230' : 'Vpiši vrednost'} autoFocus />}
        </>
      )}
      <Label>Ime polja</Label>
      <TextField value={nm} onChange={setNm} />
      <Label>Tip polja</Label>
      <ChipGroup value={tp} options={TYPES} onChange={setTp} />
    </Sheet>
  );
}
