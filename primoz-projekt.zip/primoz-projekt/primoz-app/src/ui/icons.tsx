import type { FluidIcon } from '../lib/db';

type P = { size?: number; color?: string };

/** Ikone tekočin (po Figma »Ikone«) */
export function OilIcon({ size = 22, color = 'currentColor' }: P) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
      <path d="M3 9.5h3.2l1.3-1.8h4.3l1.1 1.3 5.6-2.5c.5-.2 1 .3.7.8l-4.9 7.2c-.3.4-.8.7-1.3.7H6.5c-.8 0-1.5-.7-1.5-1.5v-2.2L3 10.9c-.6-.3-.4-1.4 0-1.4zM8.4 5.4h2.6v1.5H8.4z" />
      <path d="M20.3 13.2c.4.7 1.2 1.8 1.2 2.6a1.5 1.5 0 0 1-3 0c0-.8.8-1.9 1.2-2.6.2-.3.5-.3.6 0z" />
    </svg>
  );
}
export function BrakeIcon({ size = 22, color = 'currentColor' }: P) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
      <path d="M2.5 14.5 9 8l2.8 2.8L20.6 4c.6-.5 1.4.3.9.9l-6.8 8.8 1.8 1.8-6.5 6.5c-.6.6-1.5.6-2.1 0l-5.4-5.4c-.6-.6-.6-1.5 0-2.1z" />
      <path d="M18.8 14.5c.5.9 1.6 2.3 1.6 3.3a2 2 0 0 1-4 0c0-1 1.1-2.4 1.6-3.3.2-.3.6-.3.8 0z" />
    </svg>
  );
}
export function GearboxIcon({ size = 22, color = 'currentColor' }: P) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round">
      <circle cx="12" cy="4.5" r="2" fill={color} />
      <path d="M12 6.5v6.5" />
      <rect x="5" y="13" width="14" height="8" rx="2" fill={color} stroke="none" />
      <path d="M9 17h6" stroke="#0b0b10" />
    </svg>
  );
}
export function DropIcon({ size = 22, color = 'currentColor' }: P) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
      <path d="M12 2.7c.3 0 .5.1.7.4C14.4 5.5 18 10.4 18 14a6 6 0 0 1-12 0c0-3.6 3.6-8.5 5.3-10.9.2-.3.4-.4.7-.4z" />
    </svg>
  );
}
export function FluidGlyph({ icon, size = 22, color }: { icon: FluidIcon; size?: number; color?: string }) {
  if (icon === 'oil') return <OilIcon size={size} color={color} />;
  if (icon === 'brake') return <BrakeIcon size={size} color={color} />;
  if (icon === 'gear') return <GearboxIcon size={size} color={color} />;
  return <DropIcon size={size} color={color} />;
}
