import { Trash2 } from 'lucide-react';
import { useNav } from './nav';
import { db, deleteVehicleCascade, softDelete, restore, undoRemoved, vehicleLabel } from '../lib/db';
import { fmtDate } from '../lib/dates';
import { rescheduleAll } from '../lib/notifications';

/**
 * Enoten način brisanja v celi aplikaciji:
 * potrditveni dialog (rdeč gumb »Izbriši«) → mehko brisanje → obvestilo z »Razveljavi«.
 * Vsaka funkcija vrne true, če je bilo izbrisano.
 */
export function useDelete() {
  const { confirm, toast } = useNav();
  const ask = (title: string, text: string) => confirm({ title, text, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> });

  const vehicle = async (id: string) => {
    const v = await db.vehicles.get(id);
    if (!v) return false;
    if (!(await ask('Izbriši vozilo?', `Vozilo ${v.owner} · ${vehicleLabel(v)}${v.plate ? ` (${v.plate})` : ''} bo izbrisano skupaj s servisi, opomniki ter olji in tekočinami.`))) return false;
    const removed = await deleteVehicleCascade(id);
    await rescheduleAll();
    toast('Vozilo izbrisano', { label: 'Razveljavi', run: async () => { await undoRemoved(removed); await rescheduleAll(); toast('Obnovljeno'); } });
    return true;
  };

  const service = async (id: string) => {
    const s = await db.services.get(id);
    if (!s) return false;
    if (!(await ask('Izbriši servis?', `»${s.title}« (${fmtDate(s.date)}) bo izbrisan.`))) return false;
    await softDelete(db.services, id);
    toast('Servis izbrisan', { label: 'Razveljavi', run: () => restore(db.services, id) });
    return true;
  };

  const reminder = async (id: string) => {
    const r = await db.reminders.get(id);
    if (!r) return false;
    if (!(await ask('Izbriši opomnik?', `»${r.title}« bo izbrisan${r.repeat !== 'once' ? ' skupaj z vsemi ponovitvami' : ''}.`))) return false;
    await softDelete(db.reminders, id);
    await rescheduleAll();
    toast('Opomnik izbrisan', { label: 'Razveljavi', run: async () => { await restore(db.reminders, id); await rescheduleAll(); } });
    return true;
  };

  const fluid = async (id: string) => {
    const f = await db.fluids.get(id);
    if (!f) return false;
    const t = await db.fluidTypes.get(f.typeId);
    if (!(await ask('Izbriši tekočino?', `${t?.name ?? 'Tekočina'} bo odstranjena s tega vozila.`))) return false;
    await softDelete(db.fluids, id);
    toast('Tekočina izbrisana', { label: 'Razveljavi', run: () => restore(db.fluids, id) });
    return true;
  };

  return { vehicle, service, reminder, fluid };
}

type Kind = 'vehicle' | 'service' | 'reminder' | 'fluid';
const DETAIL: Partial<Record<Kind, string>> = { vehicle: 'vehicle', service: 'service', reminder: 'reminder' };

/**
 * Gumb koš v glavi obrazca za urejanje. Po brisanju zapre obrazec in – če je bil
 * odprt iz podrobnosti istega zapisa – tudi podrobnosti.
 */
export function FormDeleteButton({ kind, id, label }: { kind: Kind; id?: string; label: string }) {
  const { stack, pop } = useNav();
  const remove = useDelete();
  if (!id) return null;
  const run = async () => {
    if (!(await remove[kind](id))) return;
    const prev = stack[stack.length - 2] as { name: string; id?: string } | undefined;
    pop(prev && prev.name === DETAIL[kind] && prev.id === id ? 2 : 1);
  };
  return <button className="iconbtn danger" aria-label={`Izbriši ${label}`} onClick={run}><Trash2 size={20} /></button>;
}
