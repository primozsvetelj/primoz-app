import { useEffect, useRef, useState, type ReactNode, type CSSProperties } from 'react';
import { ArrowLeft, Check, ChevronLeft, ChevronRight, Clock, Plus, Search, X, Car, Copy, Truck, Bike, Bus, Pencil, Trash2 } from 'lucide-react';
import { useNav } from './nav';
import { DOW_SHORT, MONTHS_CAP, monthGrid, parseISO, todayISO, fmtDayTitle } from '../lib/dates';
import type { EventColor, Vehicle, VehicleType } from '../lib/db';
import { copyText, tap } from '../lib/native';

/* ---------- Ogrodje zaslona ---------- */

export function Screen({ children, nav, className = '', animate = true }: { children: ReactNode; nav?: boolean; className?: string; animate?: boolean }) {
  return <div className={`screen ${nav ? 'with-nav' : ''} ${animate ? 'push-enter' : ''} ${className}`}>{children}</div>;
}

export function TopBar({ title, onBack, close, actions, obrazec }: { title: ReactNode; onBack?: () => void; close?: boolean; actions?: ReactNode; obrazec?: boolean }) {
  const { back } = useNav();
  return (
    <div className="topbar">
      <button className="iconbtn" aria-label={close ? 'Zapri' : 'Nazaj'} onClick={onBack ?? (() => back())}>
        {close ? <X size={24} /> : <ArrowLeft size={24} />}
      </button>
      <div className={`title ${obrazec ? 'obrazec' : ''}`}>{title}</div>
      {actions}
    </div>
  );
}

export function SearchHeader({ onPlus, plusLabel }: { onPlus?: () => void; plusLabel?: string }) {
  const { push } = useNav();
  return (
    <div className="searchrow">
      <button className="searchbar" onClick={() => push({ name: 'search' })}>
        <Search size={22} color="var(--text)" />
        <span className="t-r15">Išči …</span>
      </button>
      {onPlus && (
        <button className="fabplus" aria-label={plusLabel ?? 'Dodaj'} onClick={onPlus}>
          <Plus size={26} />
        </button>
      )}
    </div>
  );
}

/* ---------- Gumbi ---------- */

type BtnVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
export function Button({ variant = 'primary', size, icon, children, onClick, disabled, loading, style, type = 'button' }: {
  variant?: BtnVariant; size?: 'm' | 's'; icon?: ReactNode; children?: ReactNode; onClick?: () => void; disabled?: boolean; loading?: boolean; style?: CSSProperties; type?: 'button' | 'submit';
}) {
  return (
    <button type={type} className={`btn ${variant} ${size ?? ''}`} onClick={onClick} disabled={disabled || loading} style={style}>
      {loading ? <span className="spin" style={{ width: 20, height: 20, border: '2px solid currentColor', borderRightColor: 'transparent', borderRadius: 10 }} /> : icon}
      {children}
    </button>
  );
}

/* ---------- Izbire ---------- */

export function Chip({ on, children, onClick, lg }: { on?: boolean; children: ReactNode; onClick?: () => void; lg?: boolean }) {
  return (
    <button className={`chip ${on ? 'on' : ''} ${lg ? 'lg' : ''}`} onClick={() => { tap(); onClick?.(); }}>
      {on && <Check size={16} />}
      {children}
    </button>
  );
}

export function ChipGroup<T extends string>({ value, options, onChange, segment }: { value: T; options: { id: T; label: string }[]; onChange: (v: T) => void; segment?: boolean }) {
  return (
    <div className={segment ? 'segment' : 'chips'}>
      {options.map((o) => (
        <Chip key={o.id} on={value === o.id} onClick={() => onChange(o.id)}>{o.label}</Chip>
      ))}
    </div>
  );
}

export function ColorPicker({ value, onChange }: { value: EventColor; onChange: (c: EventColor) => void }) {
  return (
    <div className="chips">
      {(['violet', 'orange'] as EventColor[]).map((c) => (
        <button key={c} className={`colorchip ${value === c ? 'on' : ''} ${c}`} onClick={() => { tap(); onChange(c); }}>
          <span className="dot" style={{ background: c === 'violet' ? 'var(--violet)' : 'var(--orange)' }} />
          {c === 'violet' ? 'Dolg servis' : 'Hitri servis'}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} className={`switch ${on ? 'on' : ''}`} onClick={() => { tap(); onChange(!on); }}>
      {on && <Check size={14} className="chk" strokeWidth={3} />}
    </button>
  );
}

export function Radio({ on }: { on: boolean }) {
  return <span className={`radio ${on ? 'on' : ''}`}>{on && <Check size={14} strokeWidth={3} />}</span>;
}

/* ---------- Polja ---------- */

export function Label({ children }: { children: ReactNode }) {
  return <span className="label">{children}</span>;
}

export function TextField({ value, onChange, placeholder, icon, type = 'text', error, inputMode, autoFocus, maxLength, onEnter, autoCapitalize, trailing }: {
  value: string; onChange: (v: string) => void; placeholder?: string; icon?: ReactNode; type?: string; error?: string; trailing?: ReactNode;
  inputMode?: 'text' | 'numeric' | 'decimal' | 'email' | 'tel'; autoFocus?: boolean; maxLength?: number; onEnter?: () => void; autoCapitalize?: string;
}) {
  const [focus, setFocus] = useState(false);
  return (
    <>
      <label className={`field ${focus ? 'focus' : ''} ${error ? 'error' : ''}`}>
        {icon}
        <input
          value={value} type={type} placeholder={placeholder} inputMode={inputMode} autoFocus={autoFocus} maxLength={maxLength}
          autoCapitalize={autoCapitalize}
          onChange={(e) => onChange(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          onKeyDown={(e) => { if (e.key === 'Enter') { (e.target as HTMLInputElement).blur(); onEnter?.(); } }}
        />
        {value && focus && (
          <button className="iconbtn" style={{ width: 28, height: 28, marginRight: -6 }} onMouseDown={(e) => e.preventDefault()} onClick={() => onChange('')} aria-label="Počisti">
            <X size={16} color="var(--text-2)" />
          </button>
        )}
        {trailing}
      </label>
      {error && <div className="errtext">{error}</div>}
    </>
  );
}

export function SelectField({ icon, value, placeholder, onClick, error }: { icon?: ReactNode; value?: string; placeholder: string; onClick: () => void; error?: string }) {
  return (
    <>
      <button className={`field ${error ? 'error' : ''}`} onClick={onClick}>
        {icon}
        <span style={{ flex: 1 }} className={value ? 't-r15' : 't-r15 ph'}>{value || placeholder}</span>
        <ChevronRight size={20} />
      </button>
      {error && <div className="errtext">{error}</div>}
    </>
  );
}

/* ---------- Ikone vozil ---------- */

export function VehicleTypeIcon({ type, size = 20, color }: { type?: VehicleType; size?: number; color?: string }) {
  if (type === 'kombi') return <Bus size={size} color={color} />;
  if (type === 'motor') return <Bike size={size} color={color} />;
  if (type === 'tovorno') return <Truck size={size} color={color} />;
  return <Car size={size} color={color} />;
}

/* ---------- Spodnji list in dialog ---------- */

export function useBackClose(open: boolean, onClose: () => void) {
  const { registerBackHandler } = useNav();
  const ref = useRef(onClose);
  ref.current = onClose;
  useEffect(() => {
    if (!open) return;
    return registerBackHandler(() => { ref.current(); return true; });
  }, [open, registerBackHandler]);
}

export function Sheet({ open, onClose, title, children, footer }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; footer?: ReactNode }) {
  useBackClose(open, onClose);
  if (!open) return null;
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <div className="sheet" role="dialog">
        <div className="handle" style={{ alignSelf: 'flex-start' }} />
        {title && <div className="t-dialog" style={{ marginBottom: 12 }}>{title}</div>}
        <div style={{ overflowY: 'auto', flex: 1, margin: '0 -4px', padding: '0 4px' }}>{children}</div>
        {footer && <div className="row" style={{ gap: 10, marginTop: 16 }}>{footer}</div>}
      </div>
    </>
  );
}

export function ConfirmHost() {
  const { confirmState, closeConfirm } = useNav();
  if (!confirmState) return null;
  const c = confirmState;
  return (
    <>
      <div className="scrim" onClick={() => closeConfirm(false)} />
      <div className="dialog" role="alertdialog">
        {c.icon && (
          <div style={{ width: 48, height: 48, borderRadius: 24, background: 'var(--error-bg)', color: 'var(--error)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
            {c.icon}
          </div>
        )}
        <div className="t-dialog" style={{ marginBottom: 12 }}>{c.title}</div>
        {c.text && <div className="t-r14 c2" style={{ lineHeight: 1.45, marginBottom: 20 }}>{c.text}</div>}
        <div className="row" style={{ gap: 10 }}>
          <Button variant="secondary" style={{ flex: 1 }} onClick={() => closeConfirm(false)}>Prekliči</Button>
          <Button variant={c.danger ? 'danger' : 'primary'} style={{ flex: 1 }} icon={c.danger && c.icon ? <Trash2 size={18} /> : undefined} onClick={() => closeConfirm(true)}>
            {c.okLabel}
          </Button>
        </div>
      </div>
    </>
  );
}

export function ToastHost({ bottom }: { bottom: number }) {
  const { toastState } = useNav();
  if (!toastState) return null;
  return (
    <div key={toastState.id} className="snackbar" style={{ bottom }}>
      <span style={{ flex: 1 }}>{toastState.text}</span>
      {toastState.action && (
        <button className="btn ghost s" onClick={toastState.action.run}>{toastState.action.label}</button>
      )}
    </div>
  );
}

/* ---------- Koledar ---------- */

export function MonthCalendar({ value, onChange, month, onMonth, dots, big, showAdjacent }: {
  value?: string; onChange: (iso: string) => void; month: { y: number; m: number }; onMonth: (m: { y: number; m: number }) => void;
  dots?: Set<string>; big?: boolean; showAdjacent?: boolean;
}) {
  const cells = monthGrid(month.y, month.m);
  const today = todayISO();
  const shift = (d: number) => {
    const dt = new Date(month.y, month.m + d, 1);
    onMonth({ y: dt.getFullYear(), m: dt.getMonth() });
  };
  return (
    <div className={`card cal ${big ? 'big' : ''}`}>
      <div className="cal-head">
        <div className={`m ${big ? 't-kartica' : ''}`} style={big ? { fontSize: 18 } : undefined}>{MONTHS_CAP[month.m]} {month.y}</div>
        <button className="iconbtn" aria-label="Prejšnji mesec" onClick={() => shift(-1)}><ChevronLeft size={22} /></button>
        <button className="iconbtn" aria-label="Naslednji mesec" onClick={() => shift(1)}><ChevronRight size={22} /></button>
      </div>
      <div className="cal-grid">
        {DOW_SHORT.map((d) => <div key={d} className="cal-dow">{d}</div>)}
        {cells.map((c) => {
          if (!c.inMonth && !showAdjacent) return <div key={c.iso} className="cal-day" />;
          const cls = ['cal-day', !c.inMonth ? 'dim' : '', c.iso === value ? 'sel' : '', c.iso === today && c.iso !== value ? 'today' : ''].join(' ');
          return (
            <button key={c.iso} className={cls} onClick={() => { tap(); onChange(c.iso); if (!c.inMonth) { const d = parseISO(c.iso); onMonth({ y: d.getFullYear(), m: d.getMonth() }); } }}>
              <span>{c.day}</span>
              {dots?.has(c.iso) && <i className="evdot" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}

const HOURS = ['07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

/** Spodnji list za izbiro ure (po kliku na datum v obrazcu). */
export function TimeSheet({ open, date, value, onClose, onConfirm }: { open: boolean; date: string; value: string; onClose: () => void; onConfirm: (t: string) => void }) {
  const [t, setT] = useState(value || '09:00');
  const [h, m] = t.split(':').map(Number);
  useEffect(() => { if (open) setT(value || '09:00'); }, [open, value]);
  const set = (hh: number, mm: number) => setT(`${String((hh + 24) % 24).padStart(2, '0')}:${String((mm + 60) % 60).padStart(2, '0')}`);
  return (
    <Sheet open={open} onClose={onClose} title="Izberi uro"
      footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Prekliči</Button><Button style={{ flex: 1 }} icon={<Check size={20} />} onClick={() => onConfirm(t)}>Potrdi</Button></>}>
      <div className="t-r15 c2" style={{ marginTop: -4, marginBottom: 14 }}>{date ? fmtDayTitle(date) : ''}</div>
      <div className="card" style={{ background: 'var(--bg-field)', borderColor: 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, height: 64 }}>
        <TimeSpin value={h} onUp={() => set(h + 1, m)} onDown={() => set(h - 1, m)} />
        <span style={{ fontSize: 40, fontWeight: 600 }}>:</span>
        <TimeSpin value={m} onUp={() => set(h, m + 5 - (m % 5))} onDown={() => set(h, m % 5 ? m - (m % 5) : m - 5)} />
      </div>
      <div className="chips" style={{ marginTop: 14 }}>
        {HOURS.map((x) => <Chip key={x} lg on={t === x} onClick={() => setT(x)}>{x}</Chip>)}
      </div>
    </Sheet>
  );
}
function TimeSpin({ value, onUp, onDown }: { value: number; onUp: () => void; onDown: () => void }) {
  return (
    <div className="row" style={{ gap: 0 }}>
      <button className="iconbtn" onClick={onDown} aria-label="Manj"><ChevronLeft size={20} color="var(--text-2)" /></button>
      <span style={{ fontSize: 40, fontWeight: 600, width: 56, textAlign: 'center' }}>{String(value).padStart(2, '0')}</span>
      <button className="iconbtn" onClick={onUp} aria-label="Več"><ChevronRight size={20} color="var(--text-2)" /></button>
    </div>
  );
}

/* ---------- Izbira vozila ---------- */

export function VehiclePickerSheet({ open, vehicles, value, onClose, onPick }: { open: boolean; vehicles: Vehicle[]; value?: string; onClose: () => void; onPick: (id: string) => void }) {
  const [sel, setSel] = useState(value);
  const [q, setQ] = useState('');
  useEffect(() => { if (open) { setSel(value || vehicles[0]?.id); setQ(''); } }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  const list = vehicles.filter((v) => !q || `${v.owner} ${v.brand} ${v.model} ${v.plate}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <Sheet open={open} onClose={onClose} title="Izberi vozilo"
      footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Prekliči</Button><Button style={{ flex: 1 }} icon={<Check size={20} />} disabled={!sel} onClick={() => sel && onPick(sel)}>Izberi</Button></>}>
      {vehicles.length > 6 && (
        <div style={{ marginBottom: 10 }}><TextField value={q} onChange={setQ} placeholder="Išči vozilo …" icon={<Search size={18} color="var(--text-2)" />} /></div>
      )}
      {vehicles.length === 0 ? (
        <div className="empty" style={{ padding: 24 }}>Ni še nobenega vozila. Najprej dodaj vozilo.</div>
      ) : (
        <div className="card" style={{ padding: 4, background: 'var(--bg-field)' }}>
          {list.map((v) => (
            <button key={v.id} className="row" onClick={() => setSel(v.id)}
              style={{ width: '100%', padding: '10px 12px', borderRadius: 10, background: sel === v.id ? 'var(--bg-selected)' : 'transparent', textAlign: 'left' }}>
              <VehicleTypeIcon type={v.type} size={20} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="t-b15">{v.owner || 'Brez imena'}</div>
                <div className="t-r12 c2">{[v.brand, v.model].filter(Boolean).join(' ')}{v.plate ? ' · ' + v.plate : ''}</div>
              </div>
              <Radio on={sel === v.id} />
            </button>
          ))}
        </div>
      )}
    </Sheet>
  );
}

/* ---------- Drugo ---------- */

export function CopyBtn({ text, label = 'Kopirano' }: { text: string; label?: string }) {
  const { toast } = useNav();
  return (
    <button className="iconbtn" style={{ width: 32, height: 32 }} aria-label="Kopiraj" onClick={async () => { await copyText(text); toast(label); }}>
      <Copy size={18} color="var(--text-2)" />
    </button>
  );
}

export function Empty({ icon, title, text, action }: { icon: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="empty fade-enter">
      <div className="ico">{icon}</div>
      <div className="t-b16" style={{ color: 'var(--text)' }}>{title}</div>
      {text && <div>{text}</div>}
      {action}
    </div>
  );
}

export function TimeFieldButton({ date, time, onClick }: { date: string; time: string; onClick: () => void }) {
  return (
    <button className="field" onClick={onClick}>
      <Clock size={18} color="var(--text-2)" />
      <span className={date ? 't-r15' : 't-r15 ph'} style={{ flex: 1 }}>
        {date ? `${fmtDayTitle(date).split(',')[0]}, ${parseISO(date).getDate()}. ${parseISO(date).getMonth() + 1}. ${parseISO(date).getFullYear()} · ${time}` : 'Izberi datum, nato uro'}
      </span>
    </button>
  );
}

export function SwipeRow({ children, onEdit, onDelete, className }: { children: ReactNode; onEdit: () => void; onDelete: () => void; className?: string }) {
  const [x, setX] = useState(0);
  const start = useRef<{ x: number; y: number; base: number; locked?: 'h' | 'v' } | null>(null);
  const swallowClick = useRef(false);
  const W = 148;
  return (
    <div className={`swipe ${className ?? ''}`}>
      <div className="actions">
        <button style={{ background: 'var(--bg-selected)', color: 'var(--violet)', border: '1px solid var(--violet)' }} onClick={() => { setX(0); onEdit(); }}>
          <Pencil size={18} />Uredi
        </button>
        <button style={{ background: 'var(--error-bg)', color: 'var(--error)', border: '1px solid #4a1f28' }} onClick={() => { setX(0); onDelete(); }}>
          <Trash2 size={18} />Izbriši
        </button>
      </div>
      <div
        className="content"
        style={{ transform: `translateX(${x}px)`, transition: start.current ? 'none' : undefined }}
        onClickCapture={(e) => { if (swallowClick.current) { e.stopPropagation(); e.preventDefault(); swallowClick.current = false; } }}
        onPointerDown={(e) => { swallowClick.current = x !== 0; start.current = { x: e.clientX, y: e.clientY, base: x }; }}
        onPointerMove={(e) => {
          const s = start.current; if (!s) return;
          const dx = e.clientX - s.x, dy = e.clientY - s.y;
          if (!s.locked) { if (Math.abs(dx) > 8) s.locked = 'h'; else if (Math.abs(dy) > 8) s.locked = 'v'; }
          if (s.locked === 'h') setX(Math.max(-W, Math.min(0, s.base + dx)));
        }}
        onPointerUp={() => { const s = start.current; start.current = null; if (s?.locked === 'h') { swallowClick.current = true; setX(x < -W / 2 ? -W : 0); } else if (x !== 0) setX(0); }}
        onPointerCancel={() => { start.current = null; setX(x < -W / 2 ? -W : 0); }}
      >
        {children}
      </div>
    </div>
  );
}

/* ---------- Iskalno polje za vozilo (ime, registracija, znamka/model, vrsta) ---------- */

const TYPE_LABELS: Record<VehicleType, string> = { osebni: 'Osebni avto', kombi: 'Kombi', motor: 'Motor', tovorno: 'Tovorno' };
const normQ = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[\s\-·.]+/g, '');

export function matchVehicles(vehicles: Vehicle[], q: string) {
  const n = normQ(q);
  if (!n) return vehicles;
  const scored = vehicles
    .map((v) => {
      const fields = [v.owner, v.plate, `${v.brand} ${v.model}`, v.brand, v.model, TYPE_LABELS[v.type] ?? '', v.vin];
      let best = -1;
      fields.forEach((f, i) => {
        const x = normQ(f || '');
        if (!x) return;
        if (x.startsWith(n)) best = Math.max(best, 100 - i);
        else if (x.includes(n)) best = Math.max(best, 50 - i);
      });
      // več besed: vse morajo nekje ustrezati (npr. »peter golf«)
      if (best < 0 && q.trim().includes(' ')) {
        const all = normQ(fields.join(' '));
        if (q.trim().split(/\s+/).every((w) => all.includes(normQ(w)))) best = 10;
      }
      return { v, best };
    })
    .filter((x) => x.best >= 0)
    .sort((a, b) => b.best - a.best);
  return scored.map((x) => x.v);
}

export function VehicleSearchField({ vehicles, value, onChange, error, autoFocus }: {
  vehicles: Vehicle[]; value: string; onChange: (id: string) => void; error?: string; autoFocus?: boolean;
}) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const selected = vehicles.find((v) => v.id === value);
  const results = matchVehicles(vehicles, q).slice(0, 8);
  const pick = (id: string) => { tap(); onChange(id); setQ(''); setOpen(false); (document.activeElement as HTMLElement | null)?.blur(); };

  if (selected && !open) {
    return (
      <>
        <button className="field" onClick={() => { setOpen(true); setQ(''); }} aria-label="Zamenjaj vozilo">
          <VehicleTypeIcon type={selected.type} size={20} color="var(--text-2)" />
          <span className="t-r15" style={{ flex: 1, minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {selected.owner} · {[selected.brand, selected.model].filter(Boolean).join(' ')}{selected.plate ? ` · ${selected.plate}` : ''}
          </span>
          <Pencil size={16} color="var(--text-2)" />
        </button>
        {error && <div className="errtext">{error}</div>}
      </>
    );
  }

  return (
    <>
      <TextField
        value={q}
        onChange={(t) => { setQ(t); setOpen(true); }}
        placeholder="Vpiši ime, registracijo ali vrsto vozila …"
        icon={<Search size={20} color="var(--text-2)" />}
        error={error}
        autoFocus={autoFocus || open}
        autoCapitalize="none"
        onEnter={() => results[0] && pick(results[0].id)}
      />
      {(open || q) && (
        <div className="card" style={{ marginTop: 6, padding: 4, background: 'var(--bg-field)', maxHeight: 320, overflowY: 'auto' }} role="listbox">
          {vehicles.length === 0 && <div className="t-r14 c2" style={{ padding: 12 }}>Ni še nobenega vozila. Najprej dodaj vozilo.</div>}
          {vehicles.length > 0 && results.length === 0 && <div className="t-r14 c2" style={{ padding: 12 }}>Ni vozila za »{q}«.</div>}
          {results.map((v) => (
            <button key={v.id} role="option" aria-selected={v.id === value} className="row" onMouseDown={(e) => e.preventDefault()} onClick={() => pick(v.id)}
              style={{ width: '100%', padding: '10px 12px', borderRadius: 10, textAlign: 'left', background: v.id === value ? 'var(--bg-selected)' : 'transparent' }}>
              <VehicleTypeIcon type={v.type} size={20} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="t-b15">{v.owner || 'Brez imena'}</div>
                <div className="t-r12 c2">{[v.brand, v.model].filter(Boolean).join(' ')}{v.plate ? ' · ' + v.plate : ''} · {TYPE_LABELS[v.type]}</div>
              </div>
            </button>
          ))}
          {selected && (
            <button className="btn ghost s" style={{ width: '100%' }} onMouseDown={(e) => e.preventDefault()} onClick={() => { setOpen(false); setQ(''); }}>Obdrži {selected.owner}</button>
          )}
        </div>
      )}
    </>
  );
}
