import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from 'react';

export type TabId = 'domov' | 'vozila' | 'stranke' | 'kreiraj' | 'koledar' | 'nastavitve';

export type Route =
  | { name: 'search'; filter?: 'all' | 'vehicles' | 'services' | 'reminders' }
  | { name: 'vehicle'; id: string }
  | { name: 'vehicleForm'; id?: string }
  | { name: 'fields'; vehicleId?: string }
  | { name: 'fluidForm'; vehicleId?: string; id?: string; copyFrom?: string }
  | { name: 'serviceForm'; vehicleId?: string; id?: string; copyFrom?: string; date?: string }
  | { name: 'service'; id: string }
  | { name: 'reminderForm'; vehicleId?: string; id?: string; date?: string }
  | { name: 'reminder'; id: string; occ?: string }
  | { name: 'customerForm'; id?: string }
  | { name: 'profile' }
  | { name: 'password' }
  | { name: 'export' }
  | { name: 'backup' };

/** zasloni, na katerih je spodnja navigacija vidna */
const WITH_NAV = new Set<Route['name']>(['vehicle', 'fields']);
export const routeHasNav = (r: Route) => WITH_NAV.has(r.name);

interface Toast { id: number; text: string; action?: { label: string; run: () => void } }
interface Confirm {
  title: string;
  text?: string;
  okLabel: string;
  danger?: boolean;
  icon?: ReactNode;
  resolve: (ok: boolean) => void;
}

interface NavCtx {
  tab: TabId;
  stack: Route[];
  stacks: Record<TabId, Route[]>;
  setTab: (t: TabId) => void;
  push: (r: Route) => void;
  replace: (r: Route) => void;
  back: () => boolean;
  /** odstrani n zaslonov s sklada (npr. po brisanju: obrazec + podrobnosti) */
  pop: (n: number) => void;
  toast: (text: string, action?: Toast['action']) => void;
  toastState: Toast | null;
  confirm: (c: Omit<Confirm, 'resolve'>) => Promise<boolean>;
  confirmState: Confirm | null;
  closeConfirm: (ok: boolean) => void;
  /** odprti spodnji list ali dialog se zapre z gumbom nazaj */
  registerBackHandler: (fn: () => boolean) => () => void;
}

const Ctx = createContext<NavCtx>(null as unknown as NavCtx);
export const useNav = () => useContext(Ctx);

const emptyStacks = (): Record<TabId, Route[]> => ({ domov: [], vozila: [], stranke: [], kreiraj: [], koledar: [], nastavitve: [] });

export function NavProvider({ children, initialTab = 'vozila' }: { children: ReactNode; initialTab?: TabId }) {
  const [tab, setTabState] = useState<TabId>(initialTab);
  const [stacks, setStacks] = useState(emptyStacks);
  const [toastState, setToast] = useState<Toast | null>(null);
  const [confirmState, setConfirm] = useState<Confirm | null>(null);
  const toastTimer = useRef<number>(0);
  const backHandlers = useRef<(() => boolean)[]>([]);
  const tabRef = useRef(tab);
  tabRef.current = tab;
  const stacksRef = useRef(stacks);
  stacksRef.current = stacks;
  const confirmRef = useRef(confirmState);
  confirmRef.current = confirmState;

  const setTab = useCallback((t: TabId) => {
    if (t === tabRef.current) {
      // ponoven klik na zavihek -> na koren
      setStacks((s) => ({ ...s, [t]: [] }));
    }
    setTabState(t);
  }, []);
  const push = useCallback((r: Route) => setStacks((s) => ({ ...s, [tabRef.current]: [...s[tabRef.current], r] })), []);
  const replace = useCallback(
    (r: Route) => setStacks((s) => ({ ...s, [tabRef.current]: [...s[tabRef.current].slice(0, -1), r] })),
    [],
  );
  const closeConfirm = useCallback((ok: boolean) => {
    confirmRef.current?.resolve(ok);
    setConfirm(null);
  }, []);
  const back = useCallback(() => {
    if (confirmRef.current) { closeConfirm(false); return true; }
    const h = backHandlers.current[backHandlers.current.length - 1];
    if (h && h()) return true;
    const t = tabRef.current;
    if (stacksRef.current[t].length) {
      setStacks((s) => ({ ...s, [t]: s[t].slice(0, -1) }));
      return true;
    }
    if (t !== 'vozila') { setTabState('vozila'); return true; }
    return false;
  }, [closeConfirm]);

  const pop = useCallback((n: number) => {
    const t = tabRef.current;
    setStacks((s) => ({ ...s, [t]: s[t].slice(0, Math.max(0, s[t].length - n)) }));
  }, []);

  const toast = useCallback((text: string, action?: Toast['action']) => {
    window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), text, action });
    toastTimer.current = window.setTimeout(() => setToast(null), action ? 5000 : 2200);
  }, []);
  const confirm = useCallback(
    (c: Omit<Confirm, 'resolve'>) => new Promise<boolean>((resolve) => setConfirm({ ...c, resolve })),
    [],
  );
  const registerBackHandler = useCallback((fn: () => boolean) => {
    backHandlers.current.push(fn);
    return () => { backHandlers.current = backHandlers.current.filter((f) => f !== fn); };
  }, []);

  const value = useMemo(
    () => ({ tab, stack: stacks[tab], stacks, setTab, push, replace, back, pop, toast, toastState, confirm, confirmState, closeConfirm, registerBackHandler }),
    [tab, stacks, setTab, push, replace, back, pop, toast, toastState, confirm, confirmState, closeConfirm, registerBackHandler],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
