import { useEffect, useRef, useState } from 'react';
import { X, Zap, ZapOff, Image as ImageIcon, Check, RotateCcw, ShieldCheck, AlertTriangle, Camera } from 'lucide-react';
import { recognize, cropCanvas, warmUp, vinCheckOk, isValidVinFormat, type ScanKind, type OcrResult } from '../lib/ocr';
import { pickFile, tap } from '../lib/native';
import { useBackClose } from './components';

/** Razmerje okvirja (širina / višina) – VIN je dolga vrstica, tablica ~ 4.7 : 1 */
const GUIDE: Record<ScanKind, { ratio: number; widthPct: number; title: string; hint: string }> = {
  vin: { ratio: 6.5, widthPct: 0.92, title: 'Skeniraj šasijo (VIN)', hint: 'Poravnaj 17-mestno številko šasije v okvir. Drži telefon mirno in vzporedno.' },
  plate: { ratio: 4.2, widthPct: 0.86, title: 'Skeniraj registrsko', hint: 'Poravnaj tablico v okvir, da jo zapolni.' },
};

type Phase = 'starting' | 'live' | 'nocamera' | 'busy' | 'result';

export function Scanner({ kind, onClose, onResult }: { kind: ScanKind; onClose: () => void; onResult: (value: string) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [phase, setPhase] = useState<Phase>('starting');
  const [torch, setTorch] = useState(false);
  const [torchOk, setTorchOk] = useState(false);
  const [frozen, setFrozen] = useState<string>('');
  const [res, setRes] = useState<OcrResult | null>(null);
  const [value, setValue] = useState('');
  const [progress, setProgress] = useState(0);
  const [err, setErr] = useState('');
  const g = GUIDE[kind];
  useBackClose(true, onClose);

  useEffect(() => {
    warmUp();
    let stopped = false;
    (async () => {
      try {
        const s = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } },
          audio: false,
        });
        if (stopped) { s.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = s;
        const v = videoRef.current!;
        v.srcObject = s;
        await v.play();
        const track = s.getVideoTracks()[0];
        const caps = (track.getCapabilities?.() ?? {}) as MediaTrackCapabilities & { torch?: boolean; focusMode?: string[] };
        setTorchOk(!!caps.torch);
        if (caps.focusMode?.includes('continuous')) track.applyConstraints({ advanced: [{ focusMode: 'continuous' } as MediaTrackConstraintSet] }).catch(() => {});
        setPhase('live');
      } catch {
        setPhase('nocamera');
      }
    })();
    return () => { stopped = true; streamRef.current?.getTracks().forEach((t) => t.stop()); };
  }, []);

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try { await track.applyConstraints({ advanced: [{ torch: !torch } as MediaTrackConstraintSet] }); setTorch(!torch); } catch { /* ni podprto */ }
  };

  const run = async (src: HTMLCanvasElement | HTMLImageElement, cropped: boolean, preview: string) => {
    setFrozen(preview);
    setPhase('busy');
    setProgress(0.05);
    setErr('');
    try {
      const r = await recognize(src, kind, { cropped, onProgress: setProgress });
      setRes(r);
      setValue(r.value);
      setPhase('result');
      tap();
    } catch (e) {
      setErr('Prepoznava ni uspela: ' + (e as Error).message);
      setPhase(streamRef.current ? 'live' : 'nocamera');
    }
  };

  /** Zajem: iz videa izrežemo samo območje okvirja (+ rob), v polni ločljivosti. */
  const capture = async () => {
    const v = videoRef.current, box = boxRef.current;
    if (!v || !box || !v.videoWidth) return;
    tap();
    const vr = v.getBoundingClientRect();
    const br = box.getBoundingClientRect();
    // object-fit: cover -> preslikava zaslon -> video
    const scale = Math.max(vr.width / v.videoWidth, vr.height / v.videoHeight);
    const offX = (vr.width - v.videoWidth * scale) / 2, offY = (vr.height - v.videoHeight * scale) / 2;
    const toVX = (x: number) => (x - vr.left - offX) / scale, toVY = (y: number) => (y - vr.top - offY) / scale;
    const mx = br.width * 0.06, my = br.height * 0.35;
    let x0 = toVX(br.left - mx), y0 = toVY(br.top - my), x1 = toVX(br.right + mx), y1 = toVY(br.bottom + my);
    x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(v.videoWidth, x1); y1 = Math.min(v.videoHeight, y1);
    const crop = cropCanvas(v, x0, y0, x1 - x0, y1 - y0);
    const full = cropCanvas(v, 0, 0, v.videoWidth, v.videoHeight);
    await run(crop, true, full.toDataURL('image/jpeg', 0.7));
  };

  const fromGallery = async () => {
    const f = await pickFile('image/*');
    if (!f) return;
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.src = url;
    await img.decode();
    await run(img, false, url);
  };

  const retry = () => { setRes(null); setFrozen(''); setPhase(streamRef.current ? 'live' : 'nocamera'); };

  const clean = kind === 'vin' ? value.toUpperCase().replace(/[^A-Z0-9]/g, '') : value.toUpperCase();
  const vinValid = kind === 'vin' && isValidVinFormat(clean);
  const checkOk = kind === 'vin' && vinValid && vinCheckOk(clean);

  return (
    <div className="scanner" role="dialog" aria-label={g.title}>
      <video ref={videoRef} playsInline muted className="scanner-video" style={{ visibility: frozen ? 'hidden' : 'visible' }} />
      {frozen && <img src={frozen} alt="" className="scanner-video" />}

      {(phase === 'live' || phase === 'busy' || phase === 'starting') && (
        <div className="scanner-mask">
          <div ref={boxRef} className={`scanner-box ${phase === 'busy' ? 'busy' : ''}`} style={{ width: `${g.widthPct * 100}%`, aspectRatio: String(g.ratio) }}>
            <i className="c tl" /><i className="c tr" /><i className="c bl" /><i className="c br" />
            {phase === 'busy' && <div className="scanner-scanline" />}
          </div>
        </div>
      )}

      <div className="scanner-top">
        <button className="iconbtn" aria-label="Zapri" onClick={onClose}><X size={26} color="#fff" /></button>
        <div className="t-b16" style={{ flex: 1, color: '#fff' }}>{g.title}</div>
        {torchOk && phase === 'live' && (
          <button className="iconbtn" aria-label="Svetilka" onClick={toggleTorch}>{torch ? <Zap size={22} color="#ffd54a" /> : <ZapOff size={22} color="#fff" />}</button>
        )}
      </div>

      {phase === 'live' && <div className="scanner-hint">{g.hint}</div>}
      {phase === 'busy' && (
        <div className="scanner-hint">
          Prepoznavam … {Math.round(progress * 100)} %
          <div style={{ height: 3, background: 'rgba(255,255,255,.2)', borderRadius: 2, marginTop: 8 }}>
            <div style={{ height: 3, width: `${progress * 100}%`, background: 'var(--violet)', borderRadius: 2, transition: 'width .3s' }} />
          </div>
        </div>
      )}
      {phase === 'nocamera' && (
        <div className="scanner-hint" style={{ top: '35%' }}>
          <Camera size={32} style={{ marginBottom: 8 }} /><br />
          Kamera ni na voljo. Dovoli dostop do kamere v nastavitvah telefona ali izberi fotografijo iz galerije.
        </div>
      )}
      {err && <div className="scanner-hint" style={{ top: 'auto', bottom: 170, color: 'var(--error)' }}>{err}</div>}

      {(phase === 'live' || phase === 'nocamera' || phase === 'starting') && (
        <div className="scanner-bottom">
          <button className="scanner-side" onClick={fromGallery} aria-label="Iz galerije"><ImageIcon size={24} /><span>Galerija</span></button>
          <button className="scanner-shutter" aria-label="Zajemi" disabled={phase !== 'live'} onClick={capture}><span /></button>
          <span className="scanner-side" />
        </div>
      )}

      {phase === 'result' && res && (
        <div className="sheet" style={{ zIndex: 5 }}>
          <div className="handle" />
          <div className="t-dialog" style={{ marginBottom: 6 }}>{kind === 'vin' ? 'Prebrana šasija' : 'Prebrana registrska'}</div>
          {res.value ? (
            <>
              <div className="t-r13 c2" style={{ marginBottom: 10 }}>Preveri in po potrebi popravi znake.</div>
              <label className="field" style={{ height: 56 }}>
                <input value={value} onChange={(e) => setValue(e.target.value.toUpperCase())} autoCapitalize="characters" spellCheck={false}
                  style={{ fontFamily: 'ui-monospace, "Roboto Mono", monospace', fontSize: 22, letterSpacing: kind === 'vin' ? 1.5 : 2, fontWeight: 600 }} />
              </label>
              <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
                {kind === 'vin' && (vinValid
                  ? <span className={`pill ${checkOk ? 'ok' : 'warn'}`}>{checkOk ? <ShieldCheck size={14} /> : <AlertTriangle size={14} />}{checkOk ? 'Kontrolna številka se ujema' : '17 znakov · kontrolne številke ni mogoče potrditi'}</span>
                  : <span className="pill err"><AlertTriangle size={14} />{clean.length}/17 znakov</span>)}
                {res.confidence < 0.6 && <span className="pill warn"><AlertTriangle size={14} />Nizka zanesljivost – preveri</span>}
              </div>
              {res.alternatives.length > 0 && (
                <>
                  <div className="label" style={{ marginTop: 14 }}>Druge možnosti</div>
                  <div className="chips">{res.alternatives.map((a) => <button key={a} className="chip" onClick={() => setValue(a)} style={{ fontFamily: 'ui-monospace, monospace' }}>{a}</button>)}</div>
                </>
              )}
            </>
          ) : (
            <div className="t-r14 c2" style={{ margin: '6px 0 4px', lineHeight: 1.5 }}>
              Besedila ni bilo mogoče prebrati. Približaj telefon, poskrbi za dobro osvetlitev (svetilka) in poravnaj {kind === 'vin' ? 'šasijo' : 'tablico'} v okvir.
            </div>
          )}
          <div className="row" style={{ gap: 10, marginTop: 18 }}>
            <button className="btn secondary" style={{ flex: 1 }} onClick={retry}><RotateCcw size={18} />Ponovno</button>
            <button className="btn primary" style={{ flex: 1 }} disabled={!clean} onClick={() => { onResult(kind === 'vin' ? clean : clean.trim()); }}><Check size={20} />Uporabi</button>
          </div>
        </div>
      )}
    </div>
  );
}
