import { useState } from 'react';
import { Check, Trash2 } from 'lucide-react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useNav } from './nav';
import { Sheet, SwipeRow, Label, TextField, Button } from './components';
import { FluidGlyph } from './icons';
import { db, patch, softDelete, restore, type FluidType, type ServiceType } from '../lib/db';

type Kind = 'serviceTypes' | 'fluidTypes';
const TXT: Record<Kind, { title: string; one: string; usedIn: string }> = {
  serviceTypes: { title: 'Moje vrste servisa', one: 'vrsto servisa', usedIn: 'servisih' },
  fluidTypes: { title: 'Moje vrste tekočin', one: 'vrsto tekočine', usedIn: 'vnosih tekočin' },
};

/** Upravljanje lastnih vrst (servis / tekočina): enak vzorec kot drugje – povleci v levo → Uredi / Izbriši. */
export function TypeManagerSheet({ kind, open, onClose, onDeleted }: { kind: Kind; open: boolean; onClose: () => void; onDeleted?: (id: string) => void }) {
  const { confirm, toast } = useNav();
  const t = TXT[kind];
  const rows = useLiveQuery(async () => {
    const all = (await (db[kind] as typeof db.serviceTypes).toArray()) as (ServiceType | FluidType)[];
    return all.filter((x) => !x.deleted && !x.builtin).sort((a, b) => a.createdAt - b.createdAt);
  }, [kind]) ?? [];
  const [edit, setEdit] = useState<ServiceType | FluidType | null>(null);
  const [name, setName] = useState('');

  const usage = async (id: string) => kind === 'serviceTypes'
    ? (await db.services.filter((s) => s.typeId === id && !s.deleted).count())
    : (await db.fluids.filter((s) => s.typeId === id && !s.deleted).count());

  const del = async (row: ServiceType | FluidType) => {
    const n = await usage(row.id);
    const ok = await confirm({
      title: `Izbriši ${t.one}?`,
      text: `»${row.name}« ne bo več na voljo za izbiro.${n ? ` Uporabljena je v ${n} ${t.usedIn} – ti ostanejo nespremenjeni.` : ''}`,
      okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} />,
    });
    if (!ok) return;
    await softDelete(db[kind] as typeof db.serviceTypes, row.id);
    onDeleted?.(row.id);
    toast('Vrsta izbrisana', { label: 'Razveljavi', run: () => restore(db[kind] as typeof db.serviceTypes, row.id) });
  };
  const rename = async () => {
    if (!edit || !name.trim()) return;
    await patch(db[kind] as typeof db.serviceTypes, edit.id, { name: name.trim() });
    setEdit(null);
    toast('Spremembe shranjene');
  };

  return (
    <>
      <Sheet open={open && !edit} onClose={onClose} title={t.title}
        footer={<Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Zapri</Button>}>
        {rows.length === 0 && <div className="t-r14 c2" style={{ padding: '8px 0' }}>Še nimaš lastnih vrst. Dodaš jih z gumbom +.</div>}
        {rows.map((r) => (
          <SwipeRow key={r.id} className="card-row" onEdit={() => { setEdit(r); setName(r.name); }} onDelete={() => del(r)}>
            <button className="listrow" style={{ minHeight: 52 }} onClick={() => { setEdit(r); setName(r.name); }}>
              {'icon' in r && <FluidGlyph icon={r.icon} size={22} />}
              <div className="main"><div className="t1">{r.name}</div></div>
            </button>
          </SwipeRow>
        ))}
        {rows.length > 0 && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
      </Sheet>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={`Uredi ${t.one}`}
        footer={<>
          <Button variant="danger" style={{ flex: 1 }} icon={<Trash2 size={18} />} onClick={async () => { const r = edit!; setEdit(null); await del(r); }}>Izbriši</Button>
          <Button style={{ flex: 1 }} icon={<Check size={20} />} disabled={!name.trim()} onClick={rename}>Shrani</Button>
        </>}>
        <Label>Ime</Label>
        <TextField value={name} onChange={setName} autoFocus onEnter={rename} />
      </Sheet>
    </>
  );
}
