"""Pretvori list Specifikacije v CSV za varni Supabase uvoz kataloga."""
from __future__ import annotations

import csv
import sys
from pathlib import Path

from openpyxl import load_workbook


COLUMNS = {
    "id": "ID_zapisa",
    "brand": "Znamka",
    "model": "Model",
    "engine_capacity": "Prostornina motorja (L)",
    "engine_name": "Ime motorja",
    "engine_code": "Koda motorja",
    "fuel": "Gorivo",
    "power": "Moč",
    "period": "Letnik/obdobje",
    "engine_oil_spec": "Motorno olje specifikacija",
    "engine_oil_capacity": "Motorno olje količina (L, s filtrom)",
    "coolant": "Hladilna tekočina (tip + količina)",
    "brake_fluid": "Zavorna tekočina",
    "transmission_oil": "Olje menjalnika/DSG (tip + količina)",
    "ac_refrigerant": "Klima plin + količina (g)",
    "known_faults": "Znane napake motorja/modela",
    "recalls": "Odpoklici",
    "tsb": "TSB (tehnična obvestila)",
    "tyre_pressure": "Tlak pnevmatik spredaj/zadaj (bar)",
    "tyre_sizes": "Dimenzije pnevmatik",
    "sources": "Viri",
    "row_status": "Status_vrstice",
    "verified_fields": "Potrjena_polja_A_S",
    "conditional_fields": "Pogojno_potrjena_polja_A_S",
    "warnings": "Opozorila",
}


def clean(value: object) -> str:
    return "" if value is None else str(value).strip()


def main(source: Path, target: Path) -> None:
    book = load_workbook(source, read_only=True, data_only=True)
    if "Specifikacije" not in book.sheetnames:
        raise SystemExit("Manjka list Specifikacije")
    sheet = book["Specifikacije"]
    headers = {clean(value): index for index, value in enumerate(next(sheet.iter_rows(values_only=True)))}
    missing = [header for header in COLUMNS.values() if header not in headers]
    if missing:
        raise SystemExit("Manjkajo stolpci: " + ", ".join(missing))
    seen: set[str] = set()
    count = 0
    with target.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(COLUMNS))
        writer.writeheader()
        for row_number, values in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
            record = {key: clean(values[headers[header]]) for key, header in COLUMNS.items()}
            # Enako kot uvoz v Admin aplikaciji: upoštevamo le dejanske
            # kataloške vrstice, ki imajo hkrati znamko in model.
            if not record["brand"] or not record["model"]:
                continue
            record["id"] = record["id"] or f"AVT-{count + 1:05d}"
            if record["id"] in seen:
                raise SystemExit(f"Podvojen ID: {record['id']}")
            seen.add(record["id"])
            writer.writerow(record)
            count += 1
    print(f"rows={count}; file={target}; bytes={target.stat().st_size}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Uporaba: catalog_to_csv.py vhod.xlsx izhod.csv")
    main(Path(sys.argv[1]), Path(sys.argv[2]))
