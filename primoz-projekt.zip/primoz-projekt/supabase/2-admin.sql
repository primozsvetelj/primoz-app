-- =====================================================================
--  Korak 2: dodeli administratorske pravice
--  Poženi PO tem, ko si v aplikaciji Primož Admin ustvaril admin račun
--  (»Prva nastavitev«) in ga potrdil s povezavo v e-pošti.
--  E-pošto spodaj zamenjaj, če uporabljaš drugo.
-- =====================================================================
insert into public.admins (user_id)
select id from auth.users where email = lower('primozsvetelj@gmail.com')
on conflict do nothing;

-- preveri: mora vrniti 1 vrstico
select u.email, a.created_at from public.admins a join auth.users u on u.id = a.user_id;
