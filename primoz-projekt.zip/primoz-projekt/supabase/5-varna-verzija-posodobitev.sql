-- Aplikacija sme prejeti samo posodobitev, ki je novejša od nameščene različice.
-- S tem preprečimo, da bi starejši aktivni paket prepisal novejši APK.
create or replace function public.app_latest_update(p_app text, p_version text)
returns jsonb language sql stable security definer set search_path = public as $$
  select case when u.id is null then null else jsonb_strip_nulls(jsonb_build_object(
    'version',u.version,'url',u.url,'checksum',u.checksum,'notes',u.notes)) end
  from (
    select * from app_updates
    where app=p_app and active
      and version ~ '^\d+\.\d+\.\d+$'
      and coalesce(p_version,'0.0.0') ~ '^\d+\.\d+\.\d+$'
      and string_to_array(version,'.')::int[] > string_to_array(coalesce(p_version,'0.0.0'),'.')::int[]
    order by published_at desc
    limit 1
  ) u
  right join (select 1) x on true
$$;

revoke all on function public.app_latest_update(text,text) from public,anon,authenticated;
grant execute on function public.app_latest_update(text,text) to anon,authenticated;
