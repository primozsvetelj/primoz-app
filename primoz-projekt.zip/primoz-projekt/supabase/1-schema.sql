-- =====================================================================
--  Primož App – strežnik (Supabase / PostgreSQL)
--  Računi, naprave, zaklepanje, sporočila, varnostni dogodki.
--
--  Varnostni model:
--   * Vse tabele imajo RLS in NIMAJO pravic za anon/authenticated.
--   * Uporabniška app kliče samo funkcije app_* (SECURITY DEFINER).
--     Po prijavi je vsak zahtevek podpisan s HMAC-SHA256 ključem naprave
--     (ključ je v telefonu shranjen kot neizvozljiv CryptoKey) in ima
--     naraščajoč števec -> ponovitev (replay) ali ponaredek je zaznan.
--   * Admin app kliče funkcije admin_* samo z Supabase Auth sejo
--     uporabnika iz tabele admins IN z opravljeno 2FA (aal2).
--  Skripto lahko poženeš večkrat (idempotentna).
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

create schema if not exists app_private;
revoke all on schema app_private from public;

-- ---------------------------------------------------------------- tabele

create table if not exists public.app_config (
  id int primary key default 1 check (id = 1),
  locked boolean not null default false,
  lock_message text not null default '',
  offline_days int not null default 30 check (offline_days between 1 and 365),
  expected_cert text,               -- SHA-256 podpisnega certifikata APK (null = ne preverjaj)
  allow_unsigned boolean not null default false,  -- dovoli odjemalce brez podatka o podpisu (npr. brskalnik)
  updated_at timestamptz not null default now()
);
insert into public.app_config (id) values (1) on conflict do nothing;

create table if not exists public.admins (
  user_id uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.app_accounts (
  id uuid primary key default gen_random_uuid(),
  email text not null unique check (email = lower(email) and length(email) between 3 and 200),
  name text not null default '' check (length(name) <= 120),
  pw_hash text not null,
  disabled boolean not null default false,
  disabled_reason text not null default '',
  max_devices int check (max_devices is null or max_devices between 1 and 50),
  must_change_pw boolean not null default false,
  note text not null default '',
  failed_count int not null default 0,
  locked_until timestamptz,
  pw_changed_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_login_at timestamptz
);

create table if not exists public.app_devices (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references public.app_accounts (id) on delete cascade,
  install_id text not null,
  hw_id text,
  label text not null default '',
  name text not null default '',
  manufacturer text not null default '',
  model text not null default '',
  platform text not null default '',
  os_version text not null default '',
  app_version text not null default '',
  status text not null default 'active'
    check (status in ('active', 'blocked', 'revoked', 'signed_out', 'wipe', 'wiped')),
  integrity jsonb not null default '{}',
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  last_ip text not null default '',
  unique (account_id, install_id)
);
create index if not exists app_devices_hw on public.app_devices (hw_id);

create table if not exists public.app_device_secrets (
  device_id uuid primary key references public.app_devices (id) on delete cascade,
  secret bytea not null,
  last_ctr bigint not null default 0
);

create table if not exists public.app_blocked_hw (
  hw_id text primary key,
  reason text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.security_events (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  kind text not null,
  severity text not null check (severity in ('info', 'warn', 'high')),
  account_id uuid references public.app_accounts (id) on delete set null,
  device_id uuid references public.app_devices (id) on delete set null,
  email text not null default '',
  ip text not null default '',
  user_agent text not null default '',
  details jsonb not null default '{}',
  seen boolean not null default false
);
create index if not exists security_events_time on public.security_events (created_at desc);
create index if not exists security_events_ip on public.security_events (ip, created_at);
create index if not exists security_events_acc on public.security_events (account_id, created_at);

create table if not exists public.app_messages (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(title) between 1 and 120),
  body text not null default '' check (length(body) <= 4000),
  kind text not null default 'info' check (kind in ('info', 'warning', 'important')),
  buttons jsonb not null,
  target text not null default 'all' check (target in ('all', 'accounts')),
  target_ids uuid[] not null default '{}',
  repeat boolean not null default false,   -- prikaži ob vsakem odprtju (tudi po odgovoru)
  active boolean not null default true,
  starts_at timestamptz,
  ends_at timestamptz,
  sent_at timestamptz not null default now(),  -- odgovori pred tem časom ne štejejo (»pošlji znova«)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.app_message_responses (
  id bigint generated always as identity primary key,
  message_id uuid not null references public.app_messages (id) on delete cascade,
  account_id uuid references public.app_accounts (id) on delete cascade,
  device_id uuid references public.app_devices (id) on delete set null,
  button_id text not null,
  button_label text not null,
  final boolean not null,
  created_at timestamptz not null default now()
);
create index if not exists app_message_responses_msg on public.app_message_responses (message_id, account_id);

create table if not exists public.admin_alert_keys (
  user_id uuid primary key references auth.users (id) on delete cascade,
  key_hash text not null,
  created_at timestamptz not null default now()
);

-- RLS povsod, brez pravic za javne vloge
do $$
declare t text;
begin
  foreach t in array array['app_config','admins','app_accounts','app_devices','app_device_secrets','app_blocked_hw',
                           'security_events','app_messages','app_message_responses','admin_alert_keys'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from public, anon, authenticated', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- pomožne funkcije

create or replace function app_private.headers() returns jsonb
language sql stable as $$
  select coalesce(nullif(current_setting('request.headers', true), ''), '{}')::jsonb
$$;

create or replace function app_private.client_ip() returns text
language sql stable as $$
  select left(coalesce(
    nullif(h ->> 'cf-connecting-ip', ''),
    nullif(trim(split_part(coalesce(h ->> 'x-forwarded-for', ''), ',', 1)), ''),
    nullif(h ->> 'x-real-ip', ''),
    ''), 64)
  from (select app_private.headers() as h) s
$$;

create or replace function app_private.now_ms() returns bigint
language sql stable as $$ select floor(extract(epoch from clock_timestamp()) * 1000)::bigint $$;

create or replace function app_private.safe_bool(v text) returns boolean
language sql immutable as $$ select case lower(coalesce(v, '')) when 'true' then true else false end $$;

create or replace function app_private.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select auth.uid() is not null
     and exists (select 1 from public.admins a where a.user_id = auth.uid())
     and coalesce(auth.jwt() ->> 'aal', '') = 'aal2'
$$;

create or replace function app_private.require_admin() returns void
language plpgsql stable security definer set search_path = public as $$
begin
  if not app_private.is_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;
end $$;

create or replace function app_private.log_event(
  p_kind text, p_sev text, p_account uuid, p_device uuid, p_email text,
  p_details jsonb default '{}', p_dedupe interval default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_ip text := app_private.client_ip();
begin
  if p_dedupe is not null and exists (
      select 1 from security_events e
      where e.kind = p_kind and e.created_at > now() - p_dedupe
        and e.account_id is not distinct from p_account
        and e.device_id is not distinct from p_device
        and (p_account is not null or p_device is not null or e.ip = v_ip)) then
    return;
  end if;
  insert into security_events (kind, severity, account_id, device_id, email, ip, user_agent, details)
  values (p_kind, p_sev, p_account, p_device, left(coalesce(p_email, ''), 200), v_ip,
          left(coalesce(app_private.headers() ->> 'user-agent', ''), 300), coalesce(p_details, '{}'));
end $$;

create or replace function app_private.device_summary(p jsonb) returns jsonb
language sql immutable as $$
  select jsonb_strip_nulls(jsonb_build_object(
    'name', left(p ->> 'name', 80), 'model', left(p ->> 'model', 80), 'manufacturer', left(p ->> 'manufacturer', 80),
    'platform', left(p ->> 'platform', 20), 'os_version', left(p ->> 'os_version', 40), 'app_version', left(p ->> 'app_version', 40),
    'hw_id', left(p ->> 'hw_id', 128), 'install_id', left(p ->> 'install_id', 128), 'integrity', p -> 'integrity'))
$$;

create or replace function app_private.pending_messages(p_account uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', m.id, 'title', m.title, 'body', m.body, 'kind', m.kind, 'buttons', m.buttons)
         order by m.sent_at), '[]'::jsonb)
  from app_messages m
  where m.active
    and (m.starts_at is null or m.starts_at <= now())
    and (m.ends_at is null or m.ends_at > now())
    and (m.target = 'all' or p_account = any (m.target_ids))
    and (m.repeat or not exists (
          select 1 from app_message_responses r
          where r.message_id = m.id and r.account_id = p_account and r.final and r.created_at >= m.sent_at))
$$;

/** Preveri podpisan zahtevek naprave. */
create or replace function app_private.verify(p_payload text, p_sig text, p_action text,
  out ok boolean, out err text, out dev public.app_devices, out acc public.app_accounts, out data jsonb)
language plpgsql security definer set search_path = public, extensions as $$
declare
  j jsonb; v_secret bytea; v_last bigint; v_ctr bigint; v_id uuid;
begin
  ok := false;
  if p_payload is null or p_sig is null or length(p_payload) > 20000 or length(p_sig) <> 64 then
    err := 'bad_request'; return;
  end if;
  begin
    j := p_payload::jsonb;
    v_id := (j ->> 'd')::uuid;
    v_ctr := (j ->> 'c')::bigint;
  exception when others then err := 'bad_request'; return;
  end;
  if v_id is null or v_ctr is null or (j ->> 'a') is distinct from p_action then
    err := 'bad_request'; return;
  end if;
  select * into dev from app_devices where id = v_id;
  if dev.id is null then err := 'invalid_session'; return; end if;
  select s.secret, s.last_ctr into v_secret, v_last from app_device_secrets s where s.device_id = v_id for update;
  if v_secret is null then err := 'invalid_session'; return; end if;
  if encode(hmac(convert_to(p_payload, 'UTF8'), v_secret, 'sha256'), 'hex') <> lower(p_sig) then
    perform app_private.log_event('bad_signature', 'high', dev.account_id, dev.id, null,
      jsonb_build_object('action', p_action), interval '10 minutes');
    err := 'invalid_session'; return;
  end if;
  if v_ctr <= v_last then
    perform app_private.log_event('replay', 'high', dev.account_id, dev.id, null,
      jsonb_build_object('action', p_action, 'ctr', v_ctr, 'last', v_last), interval '10 minutes');
    err := 'replay'; return;
  end if;
  update app_device_secrets set last_ctr = v_ctr where device_id = v_id;
  select * into acc from app_accounts where id = dev.account_id;
  data := coalesce(j -> 'x', '{}'::jsonb);
  ok := true;
end $$;

-- ---------------------------------------------------------------- uporabniška app (anon)

create or replace function public.app_login(p_email text, p_password text, p_device jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  v_email text := lower(trim(coalesce(p_email, '')));
  v_cfg app_config;
  v_acc app_accounts;
  v_dev app_devices;
  v_secret bytea;
  v_install text := left(nullif(trim(coalesce(p_device ->> 'install_id', '')), ''), 128);
  v_hw text := left(nullif(trim(coalesce(p_device ->> 'hw_id', '')), ''), 128);
  v_cert text := lower(nullif(p_device #>> '{integrity,cert}', ''));
  v_sum jsonb := app_private.device_summary(coalesce(p_device, '{}'));
  v_fails int;
  v_others int;
  v_new boolean := false;
  bad constant jsonb := jsonb_build_object('ok', false, 'error', 'invalid_credentials');
begin
  select * into v_cfg from app_config where id = 1;
  if v_install is null or coalesce(p_password, '') = '' or length(p_password) > 200 or length(v_email) > 200 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  begin
    v_secret := decode(p_device ->> 'secret', 'base64');
  exception when others then v_secret := null;
  end;
  if v_secret is null or length(v_secret) <> 32 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;

  -- omejitev po IP (20 napačnih poskusov / 15 min)
  select count(*) into v_fails from security_events
   where ip = app_private.client_ip() and ip <> '' and kind in ('login_failed', 'login_unknown', 'account_temp_locked')
     and created_at > now() - interval '15 minutes';
  if v_fails >= 20 then
    perform app_private.log_event('ip_rate_limited', 'high', null, null, v_email,
      jsonb_build_object('attempts', v_fails, 'device', v_sum), interval '15 minutes');
    return jsonb_build_object('ok', false, 'error', 'rate_limited', 'retry_after', 900);
  end if;

  select * into v_acc from app_accounts where email = v_email;
  if v_acc.id is null then
    perform crypt(p_password, gen_salt('bf', 10));   -- enak čas odziva kot pri obstoječem računu
    perform app_private.log_event('login_unknown', 'info', null, null, v_email, jsonb_build_object('device', v_sum));
    return bad;
  end if;

  if v_acc.locked_until is not null and v_acc.locked_until > now() then
    perform app_private.log_event('login_while_locked', 'high', v_acc.id, null, v_email,
      jsonb_build_object('device', v_sum), interval '5 minutes');
    return jsonb_build_object('ok', false, 'error', 'temporarily_locked',
      'retry_after', ceil(extract(epoch from v_acc.locked_until - now())));
  end if;

  if crypt(p_password, v_acc.pw_hash) <> v_acc.pw_hash then
    update app_accounts set failed_count = failed_count + 1 where id = v_acc.id returning failed_count into v_fails;
    if v_fails >= 5 then
      update app_accounts set failed_count = 0, locked_until = now() + interval '15 minutes' where id = v_acc.id;
      perform app_private.log_event('account_temp_locked', 'high', v_acc.id, null, v_email,
        jsonb_build_object('attempts', v_fails, 'device', v_sum));
    else
      perform app_private.log_event('login_failed', case when v_fails >= 3 then 'high' else 'info' end,
        v_acc.id, null, v_email, jsonb_build_object('attempt', v_fails, 'device', v_sum));
    end if;
    return bad;
  end if;
  update app_accounts set failed_count = 0, locked_until = null where id = v_acc.id;

  if v_acc.disabled then
    perform app_private.log_event('disabled_login', 'warn', v_acc.id, null, v_email,
      jsonb_build_object('device', v_sum), interval '1 hour');
    return jsonb_build_object('ok', false, 'error', 'account_disabled', 'reason', v_acc.disabled_reason);
  end if;

  if v_cfg.locked then
    return jsonb_build_object('ok', false, 'error', 'app_locked', 'message', v_cfg.lock_message);
  end if;

  if v_hw is not null and exists (select 1 from app_blocked_hw where hw_id = v_hw) then
    perform app_private.log_event('blocked_device_attempt', 'high', v_acc.id, null, v_email,
      jsonb_build_object('device', v_sum), interval '1 hour');
    return jsonb_build_object('ok', false, 'error', 'device_blocked');
  end if;

  if v_cfg.expected_cert is not null and (
       (v_cert is null and not v_cfg.allow_unsigned) or (v_cert is not null and v_cert <> lower(v_cfg.expected_cert))) then
    perform app_private.log_event('integrity_fail', 'high', v_acc.id, null, v_email,
      jsonb_build_object('device', v_sum, 'cert', v_cert), interval '1 hour');
    return jsonb_build_object('ok', false, 'error', 'integrity_failed');
  end if;

  select * into v_dev from app_devices where account_id = v_acc.id and install_id = v_install;
  if v_dev.id is null and v_hw is not null then
    select * into v_dev from app_devices where account_id = v_acc.id and hw_id = v_hw order by last_seen desc limit 1;
  end if;

  if v_dev.id is not null and v_dev.status = 'blocked' then
    perform app_private.log_event('blocked_device_attempt', 'high', v_acc.id, v_dev.id, v_email,
      jsonb_build_object('device', v_sum), interval '1 hour');
    return jsonb_build_object('ok', false, 'error', 'device_blocked');
  end if;

  select count(*) into v_others from app_devices
   where account_id = v_acc.id and status = 'active' and id is distinct from v_dev.id;

  if v_dev.id is null then
    if v_acc.max_devices is not null and v_others >= v_acc.max_devices then
      perform app_private.log_event('device_limit', 'high', v_acc.id, null, v_email,
        jsonb_build_object('device', v_sum, 'max', v_acc.max_devices), interval '1 hour');
      return jsonb_build_object('ok', false, 'error', 'device_limit');
    end if;
    insert into app_devices (account_id, install_id, hw_id)
    values (v_acc.id, v_install, v_hw) returning * into v_dev;
    v_new := true;
  end if;

  update app_devices set
    install_id = v_install,
    hw_id = coalesce(v_hw, hw_id),
    name = left(coalesce(nullif(trim(p_device ->> 'name'), ''), trim(coalesce(p_device ->> 'manufacturer', '') || ' ' || coalesce(p_device ->> 'model', ''))), 80),
    manufacturer = left(coalesce(p_device ->> 'manufacturer', ''), 80),
    model = left(coalesce(p_device ->> 'model', ''), 80),
    platform = left(coalesce(p_device ->> 'platform', ''), 20),
    os_version = left(coalesce(p_device ->> 'os_version', ''), 40),
    app_version = left(coalesce(p_device ->> 'app_version', ''), 40),
    integrity = coalesce(p_device -> 'integrity', '{}'),
    status = 'active', last_seen = now(), last_ip = app_private.client_ip()
  where id = v_dev.id;

  insert into app_device_secrets (device_id, secret, last_ctr) values (v_dev.id, v_secret, 0)
  on conflict (device_id) do update set secret = excluded.secret, last_ctr = 0;

  update app_accounts set last_login_at = now() where id = v_acc.id;

  if v_new then
    perform app_private.log_event('new_device', case when v_others > 0 then 'high' else 'warn' end,
      v_acc.id, v_dev.id, v_email, jsonb_build_object('device', v_sum, 'other_active_devices', v_others));
  else
    perform app_private.log_event('login', 'info', v_acc.id, v_dev.id, v_email, jsonb_build_object('device', v_sum));
  end if;

  if app_private.safe_bool(p_device #>> '{integrity,rooted}') or app_private.safe_bool(p_device #>> '{integrity,debuggable}')
     or app_private.safe_bool(p_device #>> '{integrity,emulator}') then
    perform app_private.log_event('risky_device', 'warn', v_acc.id, v_dev.id, v_email,
      jsonb_build_object('integrity', p_device -> 'integrity'), interval '1 day');
  end if;

  return jsonb_build_object(
    'ok', true,
    'account', jsonb_build_object('id', v_acc.id, 'email', v_acc.email, 'name', v_acc.name, 'must_change_pw', v_acc.must_change_pw),
    'device_id', v_dev.id,
    'server_time', app_private.now_ms(),
    'offline_days', v_cfg.offline_days,
    'messages', app_private.pending_messages(v_acc.id));
end $$;

create or replace function public.app_check(p_payload text, p_sig text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  v record;
  v_cfg app_config;
  v_status text := 'ok';
  v_cert text;
  v_int jsonb;
begin
  select * into v from app_private.verify(p_payload, p_sig, 'check');
  if not v.ok then
    return jsonb_build_object('ok', false, 'error', v.err, 'server_time', app_private.now_ms());
  end if;
  select * into v_cfg from app_config where id = 1;
  v_int := case when jsonb_typeof(v.data -> 'integrity') = 'object' then v.data -> 'integrity' else null end;
  v_cert := lower(nullif(v_int ->> 'cert', ''));

  update app_devices set last_seen = now(), last_ip = app_private.client_ip(),
         app_version = coalesce(left(v.data ->> 'app_version', 40), app_version),
         integrity = coalesce(v_int, integrity)
   where id = (v.dev).id;

  if (v.acc).disabled then
    v_status := 'disabled';
    perform app_private.log_event('disabled_account_use', 'warn', (v.acc).id, (v.dev).id, (v.acc).email, '{}', interval '6 hours');
  elsif (v.dev).status = 'blocked' or exists (select 1 from app_blocked_hw where hw_id = (v.dev).hw_id) then
    v_status := 'blocked';
    perform app_private.log_event('blocked_device_attempt', 'high', (v.acc).id, (v.dev).id, (v.acc).email, '{}', interval '6 hours');
  elsif (v.dev).status = 'wipe' then
    v_status := 'wipe';
  elsif (v.dev).status in ('revoked', 'signed_out', 'wiped') then
    v_status := 'revoked';
    delete from app_device_secrets where device_id = (v.dev).id;
  elsif v_cfg.expected_cert is not null and (
          (v_cert is null and not v_cfg.allow_unsigned) or (v_cert is not null and v_cert <> lower(v_cfg.expected_cert))) then
    v_status := 'integrity_failed';
    perform app_private.log_event('integrity_fail', 'high', (v.acc).id, (v.dev).id, (v.acc).email,
      jsonb_build_object('cert', v_cert), interval '6 hours');
  elsif v_cfg.locked then
    v_status := 'app_locked';
  end if;

  if v_status = 'ok' and v_int is not null and (app_private.safe_bool(v_int ->> 'rooted')
       or app_private.safe_bool(v_int ->> 'debuggable') or app_private.safe_bool(v_int ->> 'emulator')) then
    perform app_private.log_event('risky_device', 'warn', (v.acc).id, (v.dev).id, (v.acc).email,
      jsonb_build_object('integrity', v_int), interval '1 day');
  end if;

  return jsonb_build_object(
    'ok', true,
    'status', v_status,
    'reason', case v_status when 'disabled' then (v.acc).disabled_reason when 'app_locked' then v_cfg.lock_message else '' end,
    'account', jsonb_build_object('id', (v.acc).id, 'email', (v.acc).email, 'name', (v.acc).name, 'must_change_pw', (v.acc).must_change_pw),
    'server_time', app_private.now_ms(),
    'offline_days', v_cfg.offline_days,
    'messages', case when v_status = 'ok' then app_private.pending_messages((v.acc).id) else '[]'::jsonb end);
end $$;

create or replace function public.app_answer(p_payload text, p_sig text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v record; m app_messages; b jsonb;
begin
  select * into v from app_private.verify(p_payload, p_sig, 'answer');
  if not v.ok then return jsonb_build_object('ok', false, 'error', v.err); end if;
  begin
    select * into m from app_messages where id = (v.data ->> 'm')::uuid;
  exception when others then return jsonb_build_object('ok', false, 'error', 'bad_request');
  end;
  if m.id is null then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  select e into b from jsonb_array_elements(m.buttons) e where e ->> 'id' = v.data ->> 'b' limit 1;
  if b is null then return jsonb_build_object('ok', false, 'error', 'bad_request'); end if;
  insert into app_message_responses (message_id, account_id, device_id, button_id, button_label, final)
  values (m.id, (v.acc).id, (v.dev).id, b ->> 'id', b ->> 'label', (b ->> 'action') in ('close', 'link'));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.app_password(p_payload text, p_sig text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v record; v_old text; v_new text;
begin
  select * into v from app_private.verify(p_payload, p_sig, 'password');
  if not v.ok then return jsonb_build_object('ok', false, 'error', v.err); end if;
  v_old := coalesce(v.data ->> 'old', ''); v_new := coalesce(v.data ->> 'new', '');
  if (v.acc).disabled or (v.dev).status <> 'active' then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if crypt(v_old, (v.acc).pw_hash) <> (v.acc).pw_hash then
    perform app_private.log_event('password_change_failed', 'warn', (v.acc).id, (v.dev).id, (v.acc).email, '{}');
    return jsonb_build_object('ok', false, 'error', 'wrong_password');
  end if;
  if length(v_new) < 8 or length(v_new) > 200 or v_new = v_old then
    return jsonb_build_object('ok', false, 'error', 'weak_password');
  end if;
  update app_accounts set pw_hash = crypt(v_new, gen_salt('bf', 10)), must_change_pw = false,
         pw_changed_at = now(), updated_at = now() where id = (v.acc).id;
  perform app_private.log_event('password_changed', 'info', (v.acc).id, (v.dev).id, (v.acc).email, '{}');
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.app_signout(p_payload text, p_sig text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v record;
begin
  select * into v from app_private.verify(p_payload, p_sig, 'signout');
  if not v.ok then return jsonb_build_object('ok', false, 'error', v.err); end if;
  delete from app_device_secrets where device_id = (v.dev).id;
  update app_devices set status = case when status = 'active' then 'signed_out' when status = 'wipe' then 'wiped' else status end
   where id = (v.dev).id;
  if (v.dev).status = 'wipe' then
    perform app_private.log_event('device_wiped', 'info', (v.acc).id, (v.dev).id, (v.acc).email, '{}');
  end if;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.app_report(p_payload text, p_sig text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v record; k text;
begin
  select * into v from app_private.verify(p_payload, p_sig, 'report');
  if not v.ok then return jsonb_build_object('ok', false, 'error', v.err); end if;
  k := v.data ->> 'kind';
  if k not in ('clock_tamper', 'offline_expired') then return jsonb_build_object('ok', false, 'error', 'bad_request'); end if;
  perform app_private.log_event(k, 'warn', (v.acc).id, (v.dev).id, (v.acc).email,
    jsonb_build_object('info', left(coalesce(v.data ->> 'info', ''), 300)), interval '1 day');
  return jsonb_build_object('ok', true);
end $$;

-- ---------------------------------------------------------------- admin (authenticated + aal2)

create or replace function public.admin_whoami()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'admin', exists (select 1 from admins where user_id = auth.uid()),
    'aal', coalesce(auth.jwt() ->> 'aal', ''),
    'ok', app_private.is_admin())
$$;

create or replace function public.admin_overview()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  delete from security_events where created_at < now() - interval '365 days';
  return jsonb_build_object(
    'server_time', app_private.now_ms(),
    'config', (select to_jsonb(c) from app_config c where id = 1),
    'unseen', (select count(*) from security_events where not seen and severity in ('warn', 'high')),
    'unseen_high', (select count(*) from security_events where not seen and severity = 'high'),
    'accounts', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', a.id, 'email', a.email, 'name', a.name, 'disabled', a.disabled, 'disabled_reason', a.disabled_reason,
        'max_devices', a.max_devices, 'must_change_pw', a.must_change_pw, 'note', a.note,
        'locked_until', a.locked_until, 'created_at', a.created_at, 'last_login_at', a.last_login_at,
        'devices', coalesce((
          select jsonb_agg(jsonb_build_object(
            'id', d.id, 'label', d.label, 'name', d.name, 'manufacturer', d.manufacturer, 'model', d.model,
            'platform', d.platform, 'os_version', d.os_version, 'app_version', d.app_version, 'status', d.status,
            'first_seen', d.first_seen, 'last_seen', d.last_seen, 'last_ip', d.last_ip, 'integrity', d.integrity,
            'hw_id', d.hw_id, 'hw_blocked', exists (select 1 from app_blocked_hw b where b.hw_id = d.hw_id))
            order by d.last_seen desc)
          from app_devices d where d.account_id = a.id), '[]'::jsonb))
        order by lower(a.name), a.email)
      from app_accounts a), '[]'::jsonb));
end $$;

create or replace function public.admin_events(p_limit int default 100, p_before bigint default null, p_account uuid default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  return coalesce((
    select jsonb_agg(x order by (x ->> 'id')::bigint desc) from (
      select jsonb_build_object('id', e.id, 'created_at', e.created_at, 'kind', e.kind, 'severity', e.severity,
        'account_id', e.account_id, 'device_id', e.device_id, 'email', e.email, 'ip', e.ip, 'user_agent', e.user_agent,
        'details', e.details, 'seen', e.seen,
        'account_name', a.name, 'device_name', coalesce(nullif(d.label, ''), d.name), 'device_status', d.status) as x
      from security_events e
      left join app_accounts a on a.id = e.account_id
      left join app_devices d on d.id = e.device_id
      where (p_before is null or e.id < p_before) and (p_account is null or e.account_id = p_account)
      order by e.id desc
      limit least(greatest(coalesce(p_limit, 100), 1), 500)) s), '[]'::jsonb);
end $$;

create or replace function public.admin_mark_seen(p_ids bigint[] default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  update security_events set seen = true where not seen and (p_ids is null or id = any (p_ids));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_save_account(p jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  v_id uuid; v_email text := lower(trim(coalesce(p ->> 'email', ''))); v_pw text := coalesce(p ->> 'password', '');
  v_max int;
begin
  perform app_private.require_admin();
  if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'invalid_email' using errcode = '22023'; end if;
  begin v_max := nullif(p ->> 'max_devices', '')::int; exception when others then v_max := null; end;
  if p ->> 'id' is null or p ->> 'id' = '' then
    if length(v_pw) < 8 then raise exception 'weak_password' using errcode = '22023'; end if;
    if exists (select 1 from app_accounts where email = v_email) then raise exception 'email_exists' using errcode = '23505'; end if;
    insert into app_accounts (email, name, pw_hash, max_devices, note, must_change_pw)
    values (v_email, left(trim(coalesce(p ->> 'name', '')), 120), crypt(v_pw, gen_salt('bf', 10)), v_max,
            left(coalesce(p ->> 'note', ''), 1000), app_private.safe_bool(p ->> 'must_change_pw'))
    returning id into v_id;
    perform app_private.log_event('account_created', 'info', v_id, null, v_email, jsonb_build_object('by', auth.uid()));
  else
    v_id := (p ->> 'id')::uuid;
    if exists (select 1 from app_accounts where email = v_email and id <> v_id) then raise exception 'email_exists' using errcode = '23505'; end if;
    update app_accounts set email = v_email, name = left(trim(coalesce(p ->> 'name', '')), 120), max_devices = v_max,
           note = left(coalesce(p ->> 'note', ''), 1000), updated_at = now()
     where id = v_id;
    if not found then raise exception 'not_found' using errcode = 'P0002'; end if;
  end if;
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;

create or replace function public.admin_set_password(p_id uuid, p_password text, p_must_change boolean default false, p_signout_all boolean default false)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  perform app_private.require_admin();
  if length(coalesce(p_password, '')) < 8 or length(p_password) > 200 then raise exception 'weak_password' using errcode = '22023'; end if;
  update app_accounts set pw_hash = crypt(p_password, gen_salt('bf', 10)), must_change_pw = coalesce(p_must_change, false),
         pw_changed_at = now(), failed_count = 0, locked_until = null, updated_at = now() where id = p_id;
  if not found then raise exception 'not_found' using errcode = 'P0002'; end if;
  if p_signout_all then
    -- naprava ob naslednjem preverjanju dobi »revoked« (in pokaže obvestilo), nato se ključ izbriše
    update app_devices set status = 'revoked' where account_id = p_id and status = 'active';
  end if;
  perform app_private.log_event('password_reset', 'info', p_id, null, '', jsonb_build_object('signout_all', p_signout_all));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_set_disabled(p_id uuid, p_disabled boolean, p_reason text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  update app_accounts set disabled = coalesce(p_disabled, false), disabled_reason = left(coalesce(p_reason, ''), 500),
         locked_until = case when p_disabled then locked_until else null end,
         failed_count = case when p_disabled then failed_count else 0 end, updated_at = now()
   where id = p_id;
  if not found then raise exception 'not_found' using errcode = 'P0002'; end if;
  perform app_private.log_event(case when p_disabled then 'account_disabled' else 'account_enabled' end, 'info', p_id, null, '', '{}');
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_delete_account(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  delete from app_accounts where id = p_id;
  if not found then raise exception 'not_found' using errcode = 'P0002'; end if;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_device(p_id uuid, p_action text, p_label text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare d app_devices;
begin
  perform app_private.require_admin();
  select * into d from app_devices where id = p_id;
  if d.id is null then raise exception 'not_found' using errcode = 'P0002'; end if;
  case p_action
    when 'block' then
      update app_devices set status = 'blocked' where id = p_id;
      if d.hw_id is not null then
        insert into app_blocked_hw (hw_id, reason) values (d.hw_id, 'device ' || p_id) on conflict do nothing;
        update app_devices set status = 'blocked' where hw_id = d.hw_id;
      end if;
    when 'unblock' then
      if d.hw_id is not null then delete from app_blocked_hw where hw_id = d.hw_id; end if;
      update app_devices x set status = case when exists (select 1 from app_device_secrets s where s.device_id = x.id) then 'active' else 'signed_out' end
       where (x.id = p_id or (d.hw_id is not null and x.hw_id = d.hw_id)) and x.status = 'blocked';
    when 'revoke' then
      update app_devices set status = 'revoked' where id = p_id and status in ('active', 'wipe');
    when 'wipe' then
      update app_devices set status = 'wipe' where id = p_id and status in ('active', 'revoked', 'signed_out');
    when 'rename' then
      update app_devices set label = left(coalesce(p_label, ''), 60) where id = p_id;
    when 'delete' then
      delete from app_devices where id = p_id;
    else
      raise exception 'bad_action' using errcode = '22023';
  end case;
  if p_action <> 'rename' then
    perform app_private.log_event('device_' || p_action, 'info', d.account_id, case when p_action = 'delete' then null else p_id end, '',
      jsonb_build_object('device', d.name));
  end if;
  return jsonb_build_object('ok', true);
end $$;

/** Prepoved strojnega ID neposredno iz opozorila (napadalčeva naprava še nima vnosa v app_devices). */
create or replace function public.admin_block_hw(p_hw text, p_block boolean default true, p_reason text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_hw text := left(nullif(trim(coalesce(p_hw, '')), ''), 128);
begin
  perform app_private.require_admin();
  if v_hw is null then raise exception 'bad_hw' using errcode = '22023'; end if;
  if p_block then
    insert into app_blocked_hw (hw_id, reason) values (v_hw, left(coalesce(p_reason, ''), 300))
    on conflict (hw_id) do update set reason = excluded.reason;
    update app_devices set status = 'blocked' where hw_id = v_hw;
  else
    delete from app_blocked_hw where hw_id = v_hw;
    update app_devices x set status = case when exists (select 1 from app_device_secrets s where s.device_id = x.id) then 'active' else 'signed_out' end
     where x.hw_id = v_hw and x.status = 'blocked';
  end if;
  perform app_private.log_event(case when p_block then 'hw_blocked' else 'hw_unblocked' end, 'info', null, null, '', jsonb_build_object('hw_id', v_hw));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_blocked_hw()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  return coalesce((select jsonb_agg(jsonb_build_object('hw_id', b.hw_id, 'reason', b.reason, 'created_at', b.created_at,
      'devices', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'name', coalesce(nullif(d.label, ''), d.name), 'model', d.model, 'account', a.name, 'email', a.email)), '[]'::jsonb)
                  from app_devices d join app_accounts a on a.id = d.account_id where d.hw_id = b.hw_id),
      'last_attempt', (select max(e.created_at) from security_events e where e.details #>> '{device,hw_id}' = b.hw_id))
    order by b.created_at desc) from app_blocked_hw b), '[]'::jsonb);
end $$;

create or replace function public.admin_messages()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  return coalesce((
    select jsonb_agg(to_jsonb(m) || jsonb_build_object(
      'responses', (select count(*) from app_message_responses r where r.message_id = m.id and r.created_at >= m.sent_at),
      'answered_accounts', (select count(distinct r.account_id) from app_message_responses r where r.message_id = m.id and r.final and r.created_at >= m.sent_at),
      'recipients', case when m.target = 'all' then (select count(*) from app_accounts where not disabled) else cardinality(m.target_ids) end,
      'by_button', coalesce((select jsonb_object_agg(button_id, n) from (
          select r.button_id, count(distinct r.account_id) n from app_message_responses r
          where r.message_id = m.id and r.created_at >= m.sent_at group by r.button_id) q), '{}'::jsonb))
      order by m.created_at desc)
    from app_messages m), '[]'::jsonb);
end $$;

create or replace function public.admin_message_responses(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  return coalesce((
    select jsonb_agg(jsonb_build_object('id', r.id, 'created_at', r.created_at, 'button_id', r.button_id, 'button_label', r.button_label,
      'final', r.final, 'account_id', r.account_id, 'account_name', a.name, 'email', a.email,
      'device_name', coalesce(nullif(d.label, ''), d.name)) order by r.created_at desc)
    from app_message_responses r
    join app_messages m on m.id = r.message_id
    left join app_accounts a on a.id = r.account_id
    left join app_devices d on d.id = r.device_id
    where r.message_id = p_id and r.created_at >= m.sent_at), '[]'::jsonb);
end $$;

create or replace function public.admin_save_message(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_id uuid; b jsonb; n int := 0; v_buttons jsonb := '[]'; v_ids uuid[] := '{}'; v_resend boolean := app_private.safe_bool(p ->> 'resend');
begin
  perform app_private.require_admin();
  if jsonb_typeof(p -> 'buttons') <> 'array' then raise exception 'bad_buttons' using errcode = '22023'; end if;
  for b in select * from jsonb_array_elements(p -> 'buttons') loop
    n := n + 1;
    if n > 4 or length(coalesce(b ->> 'label', '')) not between 1 and 30
       or coalesce(b ->> 'style', '') not in ('primary', 'secondary', 'danger')
       or coalesce(b ->> 'action', '') not in ('close', 'later', 'link', 'exit')
       or (b ->> 'action' = 'link' and (coalesce(b ->> 'url', '') !~ '^https://[^\s]{3,}$' or length(b ->> 'url') > 500)) then
      raise exception 'bad_buttons' using errcode = '22023';
    end if;
    v_buttons := v_buttons || jsonb_build_array(jsonb_strip_nulls(jsonb_build_object(
      'id', coalesce(nullif(b ->> 'id', ''), 'b' || n), 'label', b ->> 'label', 'style', b ->> 'style', 'action', b ->> 'action',
      'url', case when b ->> 'action' = 'link' then b ->> 'url' end)));
  end loop;
  if n = 0 then raise exception 'bad_buttons' using errcode = '22023'; end if;
  if jsonb_typeof(p -> 'target_ids') = 'array' then
    select coalesce(array_agg(x::uuid), '{}') into v_ids from jsonb_array_elements_text(p -> 'target_ids') x;
  end if;
  if coalesce(p ->> 'target', 'all') = 'accounts' and cardinality(v_ids) = 0 then
    raise exception 'no_recipients' using errcode = '22023';
  end if;
  if p ->> 'id' is null or p ->> 'id' = '' then
    insert into app_messages (title, body, kind, buttons, target, target_ids, repeat, active, starts_at, ends_at)
    values (trim(p ->> 'title'), coalesce(p ->> 'body', ''), coalesce(p ->> 'kind', 'info'), v_buttons,
            coalesce(p ->> 'target', 'all'), v_ids, app_private.safe_bool(p ->> 'repeat'),
            coalesce((p ->> 'active')::boolean, true), nullif(p ->> 'starts_at', '')::timestamptz, nullif(p ->> 'ends_at', '')::timestamptz)
    returning id into v_id;
  else
    v_id := (p ->> 'id')::uuid;
    update app_messages set title = trim(p ->> 'title'), body = coalesce(p ->> 'body', ''), kind = coalesce(p ->> 'kind', 'info'),
           buttons = v_buttons, target = coalesce(p ->> 'target', 'all'), target_ids = v_ids,
           repeat = app_private.safe_bool(p ->> 'repeat'), active = coalesce((p ->> 'active')::boolean, active),
           starts_at = nullif(p ->> 'starts_at', '')::timestamptz, ends_at = nullif(p ->> 'ends_at', '')::timestamptz,
           sent_at = case when v_resend then now() else sent_at end, updated_at = now()
     where id = v_id;
    if not found then raise exception 'not_found' using errcode = 'P0002'; end if;
  end if;
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;

create or replace function public.admin_message_state(p_id uuid, p_active boolean default null, p_resend boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  update app_messages set active = coalesce(p_active, active),
         sent_at = case when p_resend then now() else sent_at end, updated_at = now()
   where id = p_id;
  if not found then raise exception 'not_found' using errcode = 'P0002'; end if;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_delete_message(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  delete from app_messages where id = p_id;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_set_config(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform app_private.require_admin();
  update app_config set
    locked = coalesce((p ->> 'locked')::boolean, locked),
    lock_message = left(coalesce(p ->> 'lock_message', lock_message), 1000),
    offline_days = coalesce((p ->> 'offline_days')::int, offline_days),
    expected_cert = case when p ? 'expected_cert' then nullif(lower(regexp_replace(coalesce(p ->> 'expected_cert', ''), '[^0-9a-fA-F]', '', 'g')), '') else expected_cert end,
    allow_unsigned = coalesce((p ->> 'allow_unsigned')::boolean, allow_unsigned),
    updated_at = now()
  where id = 1;
  perform app_private.log_event('config_changed', 'info', null, null, '', p);
  return (select to_jsonb(c) from app_config c where id = 1);
end $$;

/** Ključ za obvestila v ozadju (admin telefon) – vrne se samo enkrat, shrani se le zgoščena vrednost. */
create or replace function public.admin_alert_key()
returns text language plpgsql security definer set search_path = public, extensions as $$
declare k text := encode(gen_random_bytes(32), 'hex');
begin
  perform app_private.require_admin();
  insert into admin_alert_keys (user_id, key_hash) values (auth.uid(), encode(digest(k, 'sha256'), 'hex'))
  on conflict (user_id) do update set key_hash = excluded.key_hash, created_at = now();
  return k;
end $$;

create or replace function public.admin_alerts_poll(p_key text, p_since bigint default 0)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if p_key is null or length(p_key) <> 64 or not exists (
       select 1 from admin_alert_keys where key_hash = encode(digest(p_key, 'sha256'), 'hex')) then
    return jsonb_build_object('ok', false);
  end if;
  return jsonb_build_object('ok', true,
    'last_id', (select coalesce(max(id), 0) from security_events),
    'unseen', (select count(*) from security_events where not seen and severity in ('warn', 'high')),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', e.id, 'kind', e.kind, 'severity', e.severity,
                 'name', coalesce(nullif(a.name, ''), e.email)) order by e.id)
               from (select * from security_events where id > coalesce(p_since, 0) and severity in ('warn', 'high')
                     order by id limit 20) e left join app_accounts a on a.id = e.account_id), '[]'::jsonb));
end $$;

-- ---------------------------------------------------------------- pravice

revoke execute on all functions in schema app_private from public, anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;

grant usage on schema app_private to authenticated;
grant execute on function app_private.is_admin() to authenticated;

grant execute on function public.app_login(text, text, jsonb) to anon, authenticated;
grant execute on function public.app_check(text, text) to anon, authenticated;
grant execute on function public.app_answer(text, text) to anon, authenticated;
grant execute on function public.app_password(text, text) to anon, authenticated;
grant execute on function public.app_signout(text, text) to anon, authenticated;
grant execute on function public.app_report(text, text) to anon, authenticated;
grant execute on function public.admin_alerts_poll(text, bigint) to anon, authenticated;

grant execute on function public.admin_whoami() to authenticated;
grant execute on function public.admin_overview() to authenticated;
grant execute on function public.admin_events(int, bigint, uuid) to authenticated;
grant execute on function public.admin_mark_seen(bigint[]) to authenticated;
grant execute on function public.admin_save_account(jsonb) to authenticated;
grant execute on function public.admin_set_password(uuid, text, boolean, boolean) to authenticated;
grant execute on function public.admin_set_disabled(uuid, boolean, text) to authenticated;
grant execute on function public.admin_delete_account(uuid) to authenticated;
grant execute on function public.admin_device(uuid, text, text) to authenticated;
grant execute on function public.admin_messages() to authenticated;
grant execute on function public.admin_block_hw(text, boolean, text) to authenticated;
grant execute on function public.admin_blocked_hw() to authenticated;
grant execute on function public.admin_message_responses(uuid) to authenticated;
grant execute on function public.admin_save_message(jsonb) to authenticated;
grant execute on function public.admin_message_state(uuid, boolean, boolean) to authenticated;
grant execute on function public.admin_delete_message(uuid) to authenticated;
grant execute on function public.admin_set_config(jsonb) to authenticated;
grant execute on function public.admin_alert_key() to authenticated;

-- Realtime: admin vidi nove varnostne dogodke v živo (samo prek RLS politike)
grant select on public.security_events to authenticated;
drop policy if exists admin_read_events on public.security_events;
create policy admin_read_events on public.security_events for select to authenticated using (app_private.is_admin());

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'security_events') then
    alter publication supabase_realtime add table public.security_events;
  end if;
end $$;

-- PostgREST naj ponovno prebere shemo
notify pgrst, 'reload schema';
