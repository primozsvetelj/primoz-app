-- =====================================================================
--  Neobvezno: sprejmi samo uradno podpisan APK aplikacije Primož app.
--  (Enako vklopiš v Primož Admin → Nastavitve → Samo uradna aplikacija.)
--  SHA-256 certifikata ključa android/primoz-release.jks:
-- =====================================================================
update public.app_config
   set expected_cert = '53ce2dc9ecaef05b23681bd8897bcc60af106f7e89b35260c0f7d361e99ade6c'
 where id = 1;
