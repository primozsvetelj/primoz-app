import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'si.onebase.primoz.admin',
  appName: 'Primož Admin',
  webDir: 'dist',
  backgroundColor: '#0B0B10',
  android: {
    backgroundColor: '#0B0B10',
    webContentsDebuggingEnabled: false,
    allowMixedContent: false,
  },
  plugins: {
    CapacitorUpdater: { autoUpdate: false, statsUrl: '', appReadyTimeout: 15_000, resetWhenUpdate: true },
    SystemBars: { insetsHandling: 'css', initialViewportFitValueHint: 'cover', style: 'DARK' },
    SplashScreen: { launchShowDuration: 600, backgroundColor: '#0B0B10', showSpinner: false },
    LocalNotifications: { smallIcon: 'ic_stat_notify', iconColor: '#FF5C6C' },
    Keyboard: { resize: 'native' },
    BackgroundRunner: {
      label: 'si.onebase.primoz.admin.alerts',
      src: 'runners/alerts.js',
      event: 'checkAlerts',
      repeat: true,
      interval: 15,
      autoStart: true,
    },
  },
};

export default config;
