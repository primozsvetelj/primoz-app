// Primož Admin – preverjanje varnostnih opozoril v ozadju (Capacitor Background Runner).
// Teče brez dostopa do seje admina: uporablja ločen ključ, ki vrne samo povzetek.
function kvGet(k) {
  var r = CapacitorKV.get(k);
  return r && typeof r === 'object' ? r.value : r;
}

addEventListener('configure', function (resolve, reject, args) {
  try {
    if (!args || args.off) { CapacitorKV.remove('cfg'); resolve(); return; }
    CapacitorKV.set('cfg', JSON.stringify({ url: args.url, anon: args.anon, key: args.key }));
    CapacitorKV.set('since', String(args.since || 0));
    resolve();
  } catch (e) { reject(e); }
});

addEventListener('seen', function (resolve, reject, args) {
  try {
    var cur = Number(kvGet('since') || 0);
    if (args && args.since > cur) CapacitorKV.set('since', String(args.since));
    resolve();
  } catch (e) { reject(e); }
});

addEventListener('checkAlerts', async function (resolve, reject) {
  try {
    var raw = kvGet('cfg');
    if (!raw) { resolve(); return; }
    var cfg = JSON.parse(raw);
    var since = Number(kvGet('since') || 0);
    var res = await fetch(cfg.url + '/rest/v1/rpc/admin_alerts_poll', {
      method: 'POST',
      headers: cfg.anon.indexOf('sb_') === 0 ? { 'Content-Type': 'application/json', apikey: cfg.anon } : { 'Content-Type': 'application/json', apikey: cfg.anon, Authorization: 'Bearer ' + cfg.anon },
      body: JSON.stringify({ p_key: cfg.key, p_since: since }),
    });
    var j = await res.json();
    if (!j || !j.ok) { resolve(); return; }
    var items = j.items || [];
    if (items.length) {
      var high = items.filter(function (i) { return i.severity === 'high'; }).length;
      var first = items[items.length - 1];
      CapacitorNotifications.schedule([{
        id: Math.floor(Math.random() * 2000000000),
        title: high ? '⚠ ' + high + ' varnostnih opozoril' : items.length + ' novih opozoril',
        body: (first.name ? first.name + ': ' : '') + 'odpri Primož Admin za podrobnosti.',
        scheduleAt: new Date(Date.now() + 1000),
        channelId: 'alerts',
      }]);
    }
    CapacitorKV.set('since', String(j.last_id || since));
    resolve();
  } catch (e) {
    reject(e);
  }
});
