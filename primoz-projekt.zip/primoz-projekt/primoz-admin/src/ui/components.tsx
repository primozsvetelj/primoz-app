import { useEffect, useRef, useState, type ReactNode, type CSSProperties } from 'react';
import { ArrowLeft, Check, X, Copy, Pencil, Trash2 } from 'lucide-react';
import { useNav } from './nav';
import { copyText, tap } from '../lib/native';

type BtnVariant = 'primary' | 'secondary' | 'danger' | 'ghost';

export function Screen({ children, nav, className = '', animate = true }: { children: ReactNode; nav?: boolean; className?: string; animate?: boolean }) {
  return <div className={`screen ${nav ? 'with-nav' : ''} ${animate ? 'push-enter' : ''} ${className}`}>{children}</div>;
}

export function TopBar({ title, onBack, close, actions, obrazec }: { title: ReactNode; onBack?: () => void; close?: boolean; actions?: ReactNode; obrazec?: boolean }) {
  const { back } = useNav();
  return (
    <div className="topbar">
      <button className="iconbtn" aria-label={close ? 'Zapri' : 'Nazaj'} onClick={onBack ?? (() => back())}>
        {close ? <X size={24} /> : <ArrowLeft size={24} />}
      </button>
      <div className={`title ${obrazec ? 'obrazec' : ''}`}>{title}</div>
      {actions}
    </div>
  );
}

export function Button({ variant = 'primary', size, icon, children, onClick, disabled, loading, style, type = 'button' }: {
  variant?: BtnVariant; size?: 'm' | 's'; icon?: ReactNode; children?: ReactNode; onClick?: () => void; disabled?: boolean; loading?: boolean; style?: CSSProperties; type?: 'button' | 'submit';
}) {
  return (
    <button type={type} className={`btn ${variant} ${size ?? ''}`} onClick={onClick} disabled={disabled || loading} style={style}>
      {loading ? <span className="spin" style={{ width: 20, height: 20, border: '2px solid currentColor', borderRightColor: 'transparent', borderRadius: 10 }} /> : icon}
      {children}
    </button>
  );
}

export function Chip({ on, children, onClick, lg }: { on?: boolean; children: ReactNode; onClick?: () => void; lg?: boolean }) {
  return (
    <button className={`chip ${on ? 'on' : ''} ${lg ? 'lg' : ''}`} onClick={() => { tap(); onClick?.(); }}>
      {on && <Check size={16} />}
      {children}
    </button>
  );
}

export function ChipGroup<T extends string>({ value, options, onChange, segment }: { value: T; options: { id: T; label: string }[]; onChange: (v: T) => void; segment?: boolean }) {
  return (
    <div className={segment ? 'segment' : 'chips'}>
      {options.map((o) => (
        <Chip key={o.id} on={value === o.id} onClick={() => onChange(o.id)}>{o.label}</Chip>
      ))}
    </div>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} className={`switch ${on ? 'on' : ''}`} onClick={() => { tap(); onChange(!on); }}>
      {on && <Check size={14} className="chk" strokeWidth={3} />}
    </button>
  );
}

export function Radio({ on }: { on: boolean }) {
  return <span className={`radio ${on ? 'on' : ''}`}>{on && <Check size={14} strokeWidth={3} />}</span>;
}

export function Label({ children }: { children: ReactNode }) {
  return <span className="label">{children}</span>;
}

export function TextField({ value, onChange, placeholder, icon, type = 'text', error, inputMode, autoFocus, maxLength, onEnter, autoCapitalize, trailing }: {
  value: string; onChange: (v: string) => void; placeholder?: string; icon?: ReactNode; type?: string; error?: string; trailing?: ReactNode;
  inputMode?: 'text' | 'numeric' | 'decimal' | 'email' | 'tel'; autoFocus?: boolean; maxLength?: number; onEnter?: () => void; autoCapitalize?: string;
}) {
  const [focus, setFocus] = useState(false);
  return (
    <>
      <label className={`field ${focus ? 'focus' : ''} ${error ? 'error' : ''}`}>
        {icon}
        <input
          value={value} type={type} placeholder={placeholder} inputMode={inputMode} autoFocus={autoFocus} maxLength={maxLength}
          autoCapitalize={autoCapitalize}
          onChange={(e) => onChange(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          onKeyDown={(e) => { if (e.key === 'Enter') { (e.target as HTMLInputElement).blur(); onEnter?.(); } }}
        />
        {value && focus && (
          <button className="iconbtn" style={{ width: 28, height: 28, marginRight: -6 }} onMouseDown={(e) => e.preventDefault()} onClick={() => onChange('')} aria-label="Počisti">
            <X size={16} color="var(--text-2)" />
          </button>
        )}
        {trailing}
      </label>
      {error && <div className="errtext">{error}</div>}
    </>
  );
}

export function useBackClose(open: boolean, onClose: () => void) {
  const { registerBackHandler } = useNav();
  const ref = useRef(onClose);
  ref.current = onClose;
  useEffect(() => {
    if (!open) return;
    return registerBackHandler(() => { ref.current(); return true; });
  }, [open, registerBackHandler]);
}

export function Sheet({ open, onClose, title, children, footer }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; footer?: ReactNode }) {
  useBackClose(open, onClose);
  if (!open) return null;
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <div className="sheet" role="dialog">
        <div className="handle" style={{ alignSelf: 'flex-start' }} />
        {title && <div className="t-dialog" style={{ marginBottom: 12 }}>{title}</div>}
        <div style={{ overflowY: 'auto', flex: 1, margin: '0 -4px', padding: '0 4px' }}>{children}</div>
        {footer && <div className="row" style={{ gap: 10, marginTop: 16 }}>{footer}</div>}
      </div>
    </>
  );
}

export function ConfirmHost() {
  const { confirmState, closeConfirm } = useNav();
  if (!confirmState) return null;
  const c = confirmState;
  return (
    <>
      <div className="scrim" onClick={() => closeConfirm(false)} />
      <div className="dialog" role="alertdialog">
        {c.icon && (
          <div style={{ width: 48, height: 48, borderRadius: 24, background: 'var(--error-bg)', color: 'var(--error)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
            {c.icon}
          </div>
        )}
        <div className="t-dialog" style={{ marginBottom: 12 }}>{c.title}</div>
        {c.text && <div className="t-r14 c2" style={{ lineHeight: 1.45, marginBottom: 20 }}>{c.text}</div>}
        <div className="row" style={{ gap: 10 }}>
          <Button variant="secondary" style={{ flex: 1 }} onClick={() => closeConfirm(false)}>Prekliči</Button>
          <Button variant={c.danger ? 'danger' : 'primary'} style={{ flex: 1 }} icon={c.danger && c.icon ? <Trash2 size={18} /> : undefined} onClick={() => closeConfirm(true)}>
            {c.okLabel}
          </Button>
        </div>
      </div>
    </>
  );
}

export function ToastHost({ bottom }: { bottom: number }) {
  const { toastState } = useNav();
  if (!toastState) return null;
  return (
    <div key={toastState.id} className="snackbar" style={{ bottom }}>
      <span style={{ flex: 1 }}>{toastState.text}</span>
      {toastState.action && (
        <button className="btn ghost s" onClick={toastState.action.run}>{toastState.action.label}</button>
      )}
    </div>
  );
}

export function SwipeRow({ children, onEdit, onDelete, className }: { children: ReactNode; onEdit: () => void; onDelete: () => void; className?: string }) {
  const [x, setX] = useState(0);
  const start = useRef<{ x: number; y: number; base: number; locked?: 'h' | 'v' } | null>(null);
  const swallowClick = useRef(false);
  const W = 148;
  return (
    <div className={`swipe ${className ?? ''}`}>
      <div className="actions">
        <button style={{ background: 'var(--bg-selected)', color: 'var(--violet)', border: '1px solid var(--violet)' }} onClick={() => { setX(0); onEdit(); }}>
          <Pencil size={18} />Uredi
        </button>
        <button style={{ background: 'var(--error-bg)', color: 'var(--error)', border: '1px solid #4a1f28' }} onClick={() => { setX(0); onDelete(); }}>
          <Trash2 size={18} />Izbriši
        </button>
      </div>
      <div
        className="content"
        style={{ transform: `translateX(${x}px)`, transition: start.current ? 'none' : undefined }}
        onClickCapture={(e) => { if (swallowClick.current) { e.stopPropagation(); e.preventDefault(); swallowClick.current = false; } }}
        onPointerDown={(e) => { swallowClick.current = x !== 0; start.current = { x: e.clientX, y: e.clientY, base: x }; }}
        onPointerMove={(e) => {
          const s = start.current; if (!s) return;
          const dx = e.clientX - s.x, dy = e.clientY - s.y;
          if (!s.locked) { if (Math.abs(dx) > 8) s.locked = 'h'; else if (Math.abs(dy) > 8) s.locked = 'v'; }
          if (s.locked === 'h') setX(Math.max(-W, Math.min(0, s.base + dx)));
        }}
        onPointerUp={() => { const s = start.current; start.current = null; if (s?.locked === 'h') { swallowClick.current = true; setX(x < -W / 2 ? -W : 0); } else if (x !== 0) setX(0); }}
        onPointerCancel={() => { start.current = null; setX(x < -W / 2 ? -W : 0); }}
      >
        {children}
      </div>
    </div>
  );
}

export function Empty({ icon, title, text, action }: { icon: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="empty fade-enter">
      <div className="ico">{icon}</div>
      <div className="t-b16" style={{ color: 'var(--text)' }}>{title}</div>
      {text && <div>{text}</div>}
      {action}
    </div>
  );
}

export function CopyBtn({ text, label = 'Kopirano' }: { text: string; label?: string }) {
  const { toast } = useNav();
  return (
    <button className="iconbtn" style={{ width: 32, height: 32 }} aria-label="Kopiraj" onClick={async () => { await copyText(text); toast(label); }}>
      <Copy size={18} color="var(--text-2)" />
    </button>
  );
}
