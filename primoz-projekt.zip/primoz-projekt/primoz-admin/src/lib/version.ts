export const ADMIN_VERSION = '1.1.0';
