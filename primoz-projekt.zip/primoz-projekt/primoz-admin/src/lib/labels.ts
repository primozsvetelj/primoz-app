import type { SecEvent, Device } from './api';

export const EVENT_LABEL: Record<string, string> = {
  login: 'Prijava',
  new_device: 'Prijava z nove naprave',
  login_failed: 'Napačno geslo',
  login_unknown: 'Prijava z neobstoječim računom',
  account_temp_locked: 'Račun začasno zaklenjen (5 napačnih gesel)',
  login_while_locked: 'Poskus prijave med zaklepom',
  ip_rate_limited: 'Preveč poskusov z istega omrežja',
  disabled_login: 'Poskus prijave v onemogočen račun',
  disabled_account_use: 'Uporaba onemogočenega računa',
  blocked_device_attempt: 'Poskus vstopa s prepovedane naprave',
  device_limit: 'Presežena omejitev naprav',
  integrity_fail: 'Predelana / neuradna aplikacija',
  bad_signature: 'Ponarejen zahtevek (napačen podpis)',
  replay: 'Ponovljen (prestrežen) zahtevek',
  risky_device: 'Tvegana naprava (root / emulator / razhroščevanje)',
  clock_tamper: 'Prestavljena ura na napravi',
  offline_expired: 'Predolgo brez povezave',
  password_changed: 'Uporabnik je spremenil geslo',
  password_change_failed: 'Napačno trenutno geslo pri menjavi',
  password_reset: 'Admin je ponastavil geslo',
  account_created: 'Račun ustvarjen',
  account_disabled: 'Račun onemogočen',
  account_enabled: 'Račun omogočen',
  device_block: 'Naprava prepovedana',
  device_unblock: 'Naprava odblokirana',
  device_revoke: 'Naprava odjavljena',
  device_wipe: 'Naročen izbris podatkov',
  device_delete: 'Naprava odstranjena',
  device_wiped: 'Podatki na napravi izbrisani',
  hw_blocked: 'Strojni ID prepovedan',
  hw_unblocked: 'Strojni ID odblokiran',
  config_changed: 'Spremenjene nastavitve',
};
export const eventLabel = (k: string) => EVENT_LABEL[k] ?? k;

/** napadalni dogodki (za filter »Vdori«) */
export const ATTACK_KINDS = new Set(['login_failed', 'login_unknown', 'account_temp_locked', 'login_while_locked', 'ip_rate_limited', 'blocked_device_attempt',
  'integrity_fail', 'bad_signature', 'replay', 'disabled_login', 'device_limit', 'clock_tamper', 'risky_device', 'new_device', 'disabled_account_use']);

export const DEVICE_STATUS: Record<Device['status'], { label: string; cls: string }> = {
  active: { label: 'Aktivna', cls: 'ok' },
  blocked: { label: 'Prepovedana', cls: 'err' },
  revoked: { label: 'Odjavljena', cls: 'warn' },
  signed_out: { label: 'Odjavljena (sama)', cls: '' },
  wipe: { label: 'Čaka izbris', cls: 'warn' },
  wiped: { label: 'Podatki izbrisani', cls: '' },
};

export function deviceTitle(d: Pick<Device, 'label' | 'name' | 'manufacturer' | 'model'>) {
  return d.label || d.name || [d.manufacturer, d.model].filter(Boolean).join(' ') || 'Neznana naprava';
}

export function eventDevice(e: SecEvent): { title: string; hw?: string; os?: string } | null {
  if (e.device_name) return { title: e.device_name, hw: e.details?.device?.hw_id };
  const d = e.details?.device;
  if (!d) return null;
  return { title: [d.manufacturer, d.model].filter(Boolean).join(' ') || d.name || 'Neznana naprava', hw: d.hw_id, os: [d.platform, d.os_version].filter(Boolean).join(' ') };
}

export function ago(iso: string | null | undefined) {
  if (!iso) return '—';
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return 'pravkar';
  if (s < 3600) return `pred ${Math.floor(s / 60)} min`;
  if (s < 86400) return `pred ${Math.floor(s / 3600)} h`;
  if (s < 86400 * 30) return `pred ${Math.floor(s / 86400)} d`;
  return fmtDate(iso);
}
export const fmtDate = (iso: string) => new Date(iso).toLocaleDateString('sl-SI', { day: 'numeric', month: 'numeric', year: 'numeric' });
export const fmtDateTime = (iso: string) => new Date(iso).toLocaleString('sl-SI', { day: 'numeric', month: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
export const dayKey = (iso: string) => new Date(iso).toLocaleDateString('sl-SI', { weekday: 'long', day: 'numeric', month: 'long' });
