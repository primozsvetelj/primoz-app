import { Capacitor } from '@capacitor/core';
import { CapacitorUpdater } from '@capgo/capacitor-updater';

export interface UpdateManifest {
  version: string;
  url: string;
  checksum?: string;
  notes?: string;
}

let running: Promise<string | null> | null = null;

export function prepareUpdate(load: () => Promise<UpdateManifest | null>) {
  if (!Capacitor.isNativePlatform()) return Promise.resolve(null);
  if (running) return running;
  running = (async () => {
    await CapacitorUpdater.notifyAppReady().catch(() => undefined);
    const manifest = await load();
    if (!manifest?.version || !manifest.url) return null;
    const current = await CapacitorUpdater.current().catch(() => null);
    if (current?.bundle?.version === manifest.version) return null;
    const bundle = await CapacitorUpdater.download({
      version: manifest.version,
      url: manifest.url,
      ...(manifest.checksum ? { checksum: manifest.checksum } : {}),
    });
    await CapacitorUpdater.next({ id: bundle.id });
    return manifest.version;
  })().catch(() => null).finally(() => { running = null; });
  return running;
}

export function markUpdateReady() {
  if (!Capacitor.isNativePlatform()) return Promise.resolve();
  return CapacitorUpdater.notifyAppReady().then(() => undefined).catch(() => undefined);
}
