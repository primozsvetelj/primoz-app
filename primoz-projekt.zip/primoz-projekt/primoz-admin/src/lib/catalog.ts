import * as XLSX from 'xlsx';

export interface CatalogImportRow {
  id: string;
  brand: string;
  model: string;
  engine_capacity: string;
  engine_name: string;
  engine_code: string;
  fuel: string;
  power: string;
  period: string;
  engine_oil_spec: string;
  engine_oil_capacity: string;
  coolant: string;
  brake_fluid: string;
  transmission_oil: string;
  ac_refrigerant: string;
  known_faults: string;
  recalls: string;
  tsb: string;
  tyre_pressure: string;
  tyre_sizes: string;
  sources: string;
  row_status: string;
  verified_fields: string;
  conditional_fields: string;
  warnings: string;
}

const H: Record<keyof Omit<CatalogImportRow, 'id'>, string> = {
  brand: 'Znamka',
  model: 'Model',
  engine_capacity: 'Prostornina motorja (L)',
  engine_name: 'Ime motorja',
  engine_code: 'Koda motorja',
  fuel: 'Gorivo',
  power: 'Moč',
  period: 'Letnik/obdobje',
  engine_oil_spec: 'Motorno olje specifikacija',
  engine_oil_capacity: 'Motorno olje količina (L, s filtrom)',
  coolant: 'Hladilna tekočina (tip + količina)',
  brake_fluid: 'Zavorna tekočina',
  transmission_oil: 'Olje menjalnika/DSG (tip + količina)',
  ac_refrigerant: 'Klima plin + količina (g)',
  known_faults: 'Znane napake motorja/modela',
  recalls: 'Odpoklici',
  tsb: 'TSB (tehnična obvestila)',
  tyre_pressure: 'Tlak pnevmatik spredaj/zadaj (bar)',
  tyre_sizes: 'Dimenzije pnevmatik',
  sources: 'Viri',
  row_status: 'Status_vrstice',
  verified_fields: 'Potrjena_polja_A_S',
  conditional_fields: 'Pogojno_potrjena_polja_A_S',
  warnings: 'Opozorila',
};

const text = (v: unknown) => v == null ? '' : String(v).trim();

export async function parseCatalogFile(file: File): Promise<CatalogImportRow[]> {
  const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: false });
  const ws = wb.Sheets.Specifikacije;
  if (!ws) throw new Error('missing_sheet');
  const raw = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: '' });
  const rows = raw.map((r, i) => {
    const row = { id: text(r.ID_zapisa) || `AVT-${String(i + 1).padStart(5, '0')}` } as CatalogImportRow;
    for (const [key, header] of Object.entries(H)) row[key as keyof CatalogImportRow] = text(r[header]);
    return row;
  }).filter((r) => r.brand && r.model);
  if (!rows.length) throw new Error('empty_catalog');
  const ids = new Set<string>();
  for (const row of rows) {
    if (ids.has(row.id)) throw new Error('duplicate_id');
    ids.add(row.id);
  }
  return rows;
}

export function chunks<T>(rows: T[], size = 75) {
  const out: T[][] = [];
  for (let i = 0; i < rows.length; i += size) out.push(rows.slice(i, i + size));
  return out;
}
