import { LocalNotifications } from '@capacitor/local-notifications';
import { BackgroundRunner } from '@capacitor/background-runner';
import { Preferences } from '@capacitor/preferences';
import { supabase, SUPABASE_URL, SUPABASE_ANON } from './supabase';
import { api, type SecEvent } from './api';
import { eventLabel } from './labels';
import { isNative } from './native';

const RUNNER = 'si.onebase.primoz.admin.alerts';

/** Opozorila v živo, dokler je aplikacija odprta (Supabase Realtime, samo za admina prek RLS). */
export function subscribeEvents(onEvent: (e: Partial<SecEvent>) => void) {
  const ch = supabase
    .channel('security-events')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'security_events' }, (p) => onEvent(p.new as Partial<SecEvent>))
    .subscribe();
  return () => { supabase.removeChannel(ch); };
}

export async function notify(e: Partial<SecEvent>, who?: string) {
  if (!isNative) return;
  try {
    await LocalNotifications.schedule({ notifications: [{
      id: Math.floor(Math.random() * 2_000_000_000),
      title: e.severity === 'high' ? '⚠ Varnostno opozorilo' : 'Opozorilo',
      body: `${eventLabel(e.kind ?? '')}${who ? ' – ' + who : ''}`,
      channelId: 'alerts',
      smallIcon: 'ic_stat_notify',
    }] });
  } catch { /* ignore */ }
}

export async function setupNotifications() {
  if (!isNative) return false;
  const p = await LocalNotifications.requestPermissions().catch(() => ({ display: 'denied' }));
  await LocalNotifications.createChannel({ id: 'alerts', name: 'Varnostna opozorila', importance: 5, visibility: 1, vibration: true }).catch(() => {});
  return p.display === 'granted';
}

/**
 * Obvestila tudi, ko je aplikacija zaprta: sistem vsakih ~15 min zažene kratek
 * preverjevalnik, ki z ločenim ključem (samo za branje povzetka) vpraša strežnik.
 */
export async function enableBackgroundAlerts(on: boolean) {
  await Preferences.set({ key: 'bgAlerts', value: on ? '1' : '0' });
  if (!isNative) return;
  if (!on) {
    await BackgroundRunner.dispatchEvent({ label: RUNNER, event: 'configure', details: { off: true } }).catch(() => {});
    return;
  }
  const key = await api.alertKey();
  const last = (await api.events(1))[0]?.id ?? 0;
  await BackgroundRunner.dispatchEvent({ label: RUNNER, event: 'configure', details: { url: SUPABASE_URL, anon: SUPABASE_ANON, key, since: last } });
}

/** ob odjavi admina: ustavi preverjanje v ozadju (ključ se zavrže), nastavitev ostane */
export async function stopBackgroundAlerts() {
  if (!isNative) return;
  await BackgroundRunner.dispatchEvent({ label: RUNNER, event: 'configure', details: { off: true } }).catch(() => {});
}

export async function backgroundAlertsOn() {
  return (await Preferences.get({ key: 'bgAlerts' })).value !== '0';
}

/** ko admin v aplikaciji vidi dogodke, preverjevalnik v ozadju ne obvešča znova */
export async function markBackgroundSeen(lastId: number) {
  if (!isNative || !(await backgroundAlertsOn())) return;
  await BackgroundRunner.dispatchEvent({ label: RUNNER, event: 'seen', details: { since: lastId } }).catch(() => {});
}
