import { Preferences } from '@capacitor/preferences';

/** PIN za odklep admin aplikacije (zgoščen s PBKDF2, 5 napačnih -> odjava). */
const enc = new TextEncoder();
const hex = (b: ArrayBuffer | Uint8Array) => Array.from(new Uint8Array(b), (x) => x.toString(16).padStart(2, '0')).join('');

async function derive(pin: string, salt: string) {
  const key = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 210000, hash: 'SHA-256' }, key, 256));
}

export async function hasPin() { return !!(await Preferences.get({ key: 'pin' })).value; }

export async function setPin(pin: string) {
  const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
  await Preferences.set({ key: 'pin', value: JSON.stringify({ salt, hash: await derive(pin, salt) }) });
  await Preferences.set({ key: 'pinFails', value: '0' });
}

export async function clearPin() {
  await Preferences.remove({ key: 'pin' });
  await Preferences.remove({ key: 'pinFails' });
}

/** vrne: 'ok' | število preostalih poskusov | 'wipe' (preveč napak) */
export async function checkPin(pin: string): Promise<'ok' | 'wipe' | number> {
  const raw = (await Preferences.get({ key: 'pin' })).value;
  if (!raw) return 'wipe';
  const { salt, hash } = JSON.parse(raw);
  const h = await derive(pin, salt);
  let diff = h.length ^ hash.length;
  for (let i = 0; i < h.length; i++) diff |= h.charCodeAt(i) ^ hash.charCodeAt(i);
  if (diff === 0) { await Preferences.set({ key: 'pinFails', value: '0' }); return 'ok'; }
  const fails = Number((await Preferences.get({ key: 'pinFails' })).value ?? '0') + 1;
  await Preferences.set({ key: 'pinFails', value: String(fails) });
  return fails >= 5 ? 'wipe' : 5 - fails;
}
