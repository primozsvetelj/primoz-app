import { supabase } from './supabase';

export interface Integrity { cert?: string; debuggable?: boolean; rooted?: boolean; emulator?: boolean; installer?: string }
export interface Device {
  id: string; label: string; name: string; manufacturer: string; model: string; platform: string; os_version: string; app_version: string;
  status: 'active' | 'blocked' | 'revoked' | 'signed_out' | 'wipe' | 'wiped';
  first_seen: string; last_seen: string; last_ip: string; integrity: Integrity; hw_id: string | null; hw_blocked: boolean;
}
export interface Account {
  id: string; email: string; name: string; disabled: boolean; disabled_reason: string; max_devices: number | null; must_change_pw: boolean;
  note: string; locked_until: string | null; created_at: string; last_login_at: string | null; devices: Device[];
}
export interface AppConfig { locked: boolean; lock_message: string; offline_days: number; expected_cert: string | null; allow_unsigned: boolean; updated_at: string }
export interface Overview { server_time: number; config: AppConfig; unseen: number; unseen_high: number; accounts: Account[] }
export interface SecEvent {
  id: number; created_at: string; kind: string; severity: 'info' | 'warn' | 'high'; account_id: string | null; device_id: string | null;
  email: string; ip: string; user_agent: string; details: Record<string, any>; seen: boolean; account_name: string | null; device_name: string | null; device_status: string | null;
}
export interface MsgButton { id?: string; label: string; style: 'primary' | 'secondary' | 'danger'; action: 'close' | 'later' | 'link' | 'exit'; url?: string }
export interface Message {
  id: string; title: string; body: string; kind: 'info' | 'warning' | 'important'; buttons: MsgButton[]; target: 'all' | 'accounts'; target_ids: string[];
  repeat: boolean; active: boolean; starts_at: string | null; ends_at: string | null; sent_at: string; created_at: string;
  responses: number; answered_accounts: number; recipients: number; by_button: Record<string, number>;
}
export interface MsgResponse { id: number; created_at: string; button_id: string; button_label: string; final: boolean; account_id: string; account_name: string; email: string; device_name: string }
export interface BlockedHw { hw_id: string; reason: string; created_at: string; devices: { id: string; name: string; model: string; account: string; email: string }[]; last_attempt: string | null }

export class ApiError extends Error {
  constructor(public code: string) { super(code); }
}

const KNOWN = ['weak_password', 'email_exists', 'invalid_email', 'not_found', 'bad_buttons', 'no_recipients', 'forbidden', 'bad_action', 'bad_hw'];

async function call<T>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  const { data, error } = await supabase.rpc(fn, args);
  if (error) {
    const code = KNOWN.find((k) => error.message?.includes(k)) ?? (error.code === '23505' ? 'email_exists' : /fetch|network/i.test(error.message) ? 'network' : 'server');
    throw new ApiError(code);
  }
  return data as T;
}

export const api = {
  whoami: () => call<{ admin: boolean; aal: string; ok: boolean }>('admin_whoami'),
  overview: () => call<Overview>('admin_overview'),
  events: (limit = 100, before?: number, account?: string) => call<SecEvent[]>('admin_events', { p_limit: limit, p_before: before ?? null, p_account: account ?? null }),
  markSeen: (ids?: number[]) => call('admin_mark_seen', { p_ids: ids ?? null }),
  saveAccount: (p: Partial<Account> & { password?: string }) => call<{ ok: boolean; id: string }>('admin_save_account', { p }),
  setPassword: (id: string, password: string, mustChange: boolean, signoutAll: boolean) => call('admin_set_password', { p_id: id, p_password: password, p_must_change: mustChange, p_signout_all: signoutAll }),
  setDisabled: (id: string, disabled: boolean, reason = '') => call('admin_set_disabled', { p_id: id, p_disabled: disabled, p_reason: reason }),
  deleteAccount: (id: string) => call('admin_delete_account', { p_id: id }),
  device: (id: string, action: 'block' | 'unblock' | 'revoke' | 'wipe' | 'rename' | 'delete', label?: string) => call('admin_device', { p_id: id, p_action: action, p_label: label ?? null }),
  blockHw: (hw: string, block: boolean, reason = '') => call('admin_block_hw', { p_hw: hw, p_block: block, p_reason: reason }),
  blockedHw: () => call<BlockedHw[]>('admin_blocked_hw'),
  messages: () => call<Message[]>('admin_messages'),
  responses: (id: string) => call<MsgResponse[]>('admin_message_responses', { p_id: id }),
  saveMessage: (p: Partial<Message> & { resend?: boolean }) => call<{ ok: boolean; id: string }>('admin_save_message', { p }),
  messageState: (id: string, active: boolean | null, resend = false) => call('admin_message_state', { p_id: id, p_active: active, p_resend: resend }),
  deleteMessage: (id: string) => call('admin_delete_message', { p_id: id }),
  setConfig: (p: Partial<AppConfig>) => call<AppConfig>('admin_set_config', { p }),
  alertKey: () => call<string>('admin_alert_key'),
};

export const ERR: Record<string, string> = {
  weak_password: 'Geslo mora imeti vsaj 8 znakov.',
  email_exists: 'Račun s to e-pošto že obstaja.',
  invalid_email: 'Neveljaven e-poštni naslov.',
  not_found: 'Zapis ne obstaja več.',
  bad_buttons: 'Preveri gumbe (1–4, vsak z napisom; povezava mora biti https://).',
  no_recipients: 'Izberi vsaj enega prejemnika.',
  forbidden: 'Ni dovoljenja – prijavi se znova.',
  network: 'Ni povezave s strežnikom.',
  server: 'Napaka strežnika.',
};
export const errText = (e: unknown) => ERR[(e as ApiError)?.code] ?? ERR.server;

/** močno naključno geslo brez dvoumnih znakov */
export function generatePassword(len = 12) {
  const a = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const r = crypto.getRandomValues(new Uint32Array(len));
  let p = Array.from(r, (x) => a[x % a.length]).join('');
  if (!/\d/.test(p)) p = p.slice(0, -1) + '7';
  return p;
}
