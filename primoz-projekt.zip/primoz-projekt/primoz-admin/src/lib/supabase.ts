import { createClient } from '@supabase/supabase-js';
import { Preferences } from '@capacitor/preferences';
import { isNative } from './native';

export const SUPABASE_URL = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.replace(/\/$/, '') ?? '';
export const SUPABASE_ANON = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined) ?? '';
export const configured = !!SUPABASE_URL && !!SUPABASE_ANON;

/** Seja admina je shranjena v zasebnih nastavitvah aplikacije (ne v brskalniškem localStorage). */
const storage = isNative
  ? {
      getItem: async (k: string) => (await Preferences.get({ key: k })).value,
      setItem: async (k: string, v: string) => { await Preferences.set({ key: k, value: v }); },
      removeItem: async (k: string) => { await Preferences.remove({ key: k }); },
    }
  : undefined;

export const supabase = createClient(SUPABASE_URL || 'https://not-configured.invalid', SUPABASE_ANON || 'x', {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, storage, storageKey: 'primoz-admin-auth' },
  realtime: { params: { eventsPerSecond: 5 } },
});
