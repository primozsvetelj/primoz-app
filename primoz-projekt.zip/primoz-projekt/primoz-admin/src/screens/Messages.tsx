import { useEffect, useState } from 'react';
import { Plus, Megaphone, Info, AlertTriangle, ChevronRight, Trash2, Pencil, Eye, Send, RotateCcw, Pause, Play, ArrowUp, ArrowDown, X, Users, Check } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, TopBar, Button, Sheet, Label, TextField, Toggle, ChipGroup, Chip, Empty, SwipeRow, Radio } from '../ui/components';
import { api, errText, type Message, type MsgButton, type MsgResponse } from '../lib/api';
import { ago, fmtDateTime } from '../lib/labels';
import { useData } from '../data';

const KIND_OPTS = [{ id: 'info', label: 'Obvestilo' }, { id: 'warning', label: 'Opozorilo' }, { id: 'important', label: 'Pomembno' }] as const;
const KIND_ICON = { info: <Info size={30} />, warning: <AlertTriangle size={30} />, important: <Megaphone size={30} /> };
const KIND_COLOR = { info: ['var(--violet)', 'var(--bg-selected)'], warning: ['var(--orange)', 'var(--orange-bg)'], important: ['var(--error)', 'var(--error-bg)'] };

const ACTIONS: { id: MsgButton['action']; label: string; hint: string }[] = [
  { id: 'close', label: 'Zapre sporočilo', hint: 'odgovor se shrani, sporočilo se ne pokaže več' },
  { id: 'later', label: 'Pokaži znova', hint: 'sporočilo se pokaže ob naslednjem odprtju' },
  { id: 'link', label: 'Odpre povezavo', hint: 'odpre spletno stran (https)' },
  { id: 'exit', label: 'Zapre aplikacijo', hint: 'uporabnik ne more naprej, dokler ne izbere drugega gumba' },
];
const STYLE_OPTS = [{ id: 'primary', label: 'Glavni' }, { id: 'secondary', label: 'Navaden' }, { id: 'danger', label: 'Rdeč' }] as const;

const PRESETS: MsgButton[] = [
  { label: 'Potrdi', style: 'primary', action: 'close' },
  { label: 'Zavrni', style: 'danger', action: 'close' },
  { label: 'V redu', style: 'primary', action: 'close' },
  { label: 'Kasneje', style: 'secondary', action: 'later' },
  { label: 'Več o tem', style: 'secondary', action: 'link', url: 'https://' },
  { label: 'Zapri aplikacijo', style: 'secondary', action: 'exit' },
];

/** Enak izgled kot v aplikaciji Primož app (zasede večino zaslona). */
export function MessagePreview({ m, onClose }: { m: Pick<Message, 'title' | 'body' | 'kind' | 'buttons'>; onClose?: () => void }) {
  const [c, bg] = KIND_COLOR[m.kind];
  return (
    <div className="msg-overlay" onClick={onClose}>
      <div className="msg-card" onClick={(e) => e.stopPropagation()}>
        <div className="msg-icon" style={{ color: c, background: bg }}>{KIND_ICON[m.kind]}</div>
        <div className="msg-title">{m.title || 'Naslov sporočila'}</div>
        <div className="msg-body">{m.body}</div>
        <div className="msg-buttons">{m.buttons.map((b, i) => <Button key={i} variant={b.style}>{b.label || '…'}</Button>)}</div>
        {onClose && <button className="btn ghost s" style={{ marginTop: 12, alignSelf: 'center' }} onClick={onClose}><X size={16} />Zapri predogled</button>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ seznam */

export function MessagesScreen() {
  const { push, confirm, toast } = useNav();
  const { messages, reloadMessages } = useData();
  useEffect(() => { reloadMessages(); }, [reloadMessages]);
  const del = async (m: Message) => {
    if (!(await confirm({ title: 'Izbriši sporočilo?', text: `»${m.title}« in vsi odgovori bodo izbrisani.`, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> }))) return;
    try { await api.deleteMessage(m.id); await reloadMessages(); toast('Sporočilo izbrisano'); } catch (e) { toast(errText(e)); }
  };
  return (
    <Screen nav animate={false}>
      <div className="searchrow" style={{ justifyContent: 'flex-end' }}>
        <button className="fabplus" aria-label="Novo sporočilo" onClick={() => push({ name: 'messageForm' })}><Plus size={26} /></button>
      </div>
      <div className="scroll">
        <div className="h-big">Sporočila</div>
        <div className="t-r14 c2" style={{ marginTop: -6, marginBottom: 12 }}>Prikažejo se uporabnikom ob odprtju aplikacije Primož app.</div>
        {messages && messages.length === 0 && <Empty icon={<Megaphone size={30} />} title="Ni sporočil" text="Pošlji obvestilo z gumbi, npr. Potrdi / Zavrni, in spremljaj odgovore." action={<Button size="m" onClick={() => push({ name: 'messageForm' })}>Novo sporočilo</Button>} />}
        {messages?.map((m) => (
          <SwipeRow key={m.id} className="card-row" onEdit={() => push({ name: 'messageForm', id: m.id })} onDelete={() => del(m)}>
            <button className="listrow" onClick={() => push({ name: 'message', id: m.id })}>
              <div className="ico" style={{ color: KIND_COLOR[m.kind][0], background: KIND_COLOR[m.kind][1] }}>{m.kind === 'important' ? <Megaphone size={20} /> : m.kind === 'warning' ? <AlertTriangle size={20} /> : <Info size={20} />}</div>
              <div className="main">
                <div className="t1">{m.title}</div>
                <div className="t2">{m.target === 'all' ? 'Vsi' : `${m.target_ids.length} ${m.target_ids.length === 1 ? 'račun' : 'računi'}`} · odgovorilo {m.answered_accounts}/{m.recipients} · {ago(m.sent_at)}</div>
              </div>
              <span className={`pill ${m.active ? 'ok' : ''}`}>{m.active ? 'Aktivno' : 'Ustavljeno'}</span>
              <ChevronRight size={20} />
            </button>
          </SwipeRow>
        ))}
        {!!messages?.length && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
      </div>
    </Screen>
  );
}

/* ------------------------------------------------------------ podrobnosti */

export function MessageScreen({ id }: { id: string }) {
  const { push, back, confirm, toast } = useNav();
  const { messages, reloadMessages } = useData();
  const m = messages?.find((x) => x.id === id);
  const [resp, setResp] = useState<MsgResponse[] | null>(null);
  const [preview, setPreview] = useState(false);
  useEffect(() => { api.responses(id).then(setResp).catch(() => setResp([])); }, [id, messages]);
  if (!messages) return <Screen nav><TopBar title="" /></Screen>;
  if (!m) return <Screen nav><TopBar title="Sporočilo" /><div className="empty">Sporočilo ne obstaja več.</div></Screen>;

  const del = async () => {
    if (!(await confirm({ title: 'Izbriši sporočilo?', text: `»${m.title}« in vsi odgovori bodo izbrisani.`, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> }))) return;
    try { await api.deleteMessage(id); back(); await reloadMessages(); toast('Sporočilo izbrisano'); } catch (e) { toast(errText(e)); }
  };
  const state = async (active: boolean | null, resend = false) => {
    try { await api.messageState(id, active, resend); await reloadMessages(); toast(resend ? 'Poslano znova – vsi ga bodo videli ponovno' : active ? 'Sporočilo aktivno' : 'Sporočilo ustavljeno'); } catch (e) { toast(errText(e)); }
  };
  const finals = (resp ?? []).filter((r) => r.final);
  const latest = new Map<string, MsgResponse>();
  for (const r of resp ?? []) if (!latest.has(r.account_id)) latest.set(r.account_id, r);

  return (
    <Screen nav>
      <TopBar title="Sporočilo" actions={<>
        <button className="iconbtn violet" aria-label="Uredi sporočilo" onClick={() => push({ name: 'messageForm', id })}><Pencil size={22} /></button>
        <button className="iconbtn danger" aria-label="Izbriši sporočilo" onClick={del}><Trash2 size={20} /></button>
      </>} />
      <div className="scroll">
        <div className="t-kartica" style={{ fontSize: 22, marginTop: 4 }}>{m.title}</div>
        <div className="t-r14 c2" style={{ marginTop: 4 }}>{m.active ? 'Aktivno' : 'Ustavljeno'} · {m.target === 'all' ? 'vsi uporabniki' : `${m.target_ids.length} izbranih računov`} · poslano {fmtDateTime(m.sent_at)}</div>
        <div className="row" style={{ gap: 10, marginTop: 14 }}>
          <Button variant="secondary" size="m" style={{ flex: 1 }} icon={<Eye size={18} />} onClick={() => setPreview(true)}>Predogled</Button>
          <Button variant="secondary" size="m" style={{ flex: 1 }} icon={m.active ? <Pause size={18} /> : <Play size={18} />} onClick={() => state(!m.active)}>{m.active ? 'Ustavi' : 'Aktiviraj'}</Button>
        </div>
        <Button variant="ghost" style={{ width: '100%', marginTop: 4 }} icon={<RotateCcw size={18} />} onClick={async () => { if (await confirm({ title: 'Pošlji znova?', text: 'Sporočilo se ponovno prikaže vsem prejemnikom, tudi tistim, ki so že odgovorili. Novi odgovori se štejejo od začetka.', okLabel: 'Pošlji znova' })) state(true, true); }}>Pošlji znova vsem</Button>

        <div className="card" style={{ padding: '14px 16px', marginTop: 12 }}>
          <div className="row"><span className="t-sekcija" style={{ flex: 1 }}>Odgovori</span><span className="t-b15">{m.answered_accounts}/{m.recipients}</span></div>
          <div className="bar"><span style={{ width: `${m.recipients ? (m.answered_accounts / m.recipients) * 100 : 0}%` }} /></div>
          {m.buttons.map((b) => {
            const n = m.by_button[b.id ?? ''] ?? 0;
            return <div key={b.id} className="kv"><span className="k"><span className={`dot sm ${b.style}`} />{b.label}</span><span className="v">{n}</span></div>;
          })}
        </div>

        <div className="label" style={{ marginTop: 18 }}>Kdo je kaj izbral</div>
        {resp && latest.size === 0 && <div className="t-r14 c2">Še ni odgovorov.</div>}
        {[...latest.values()].map((r) => (
          <div key={r.id} className="listrow" style={{ cursor: 'default' }}>
            <div className="main"><div className="t1">{r.account_name || r.email}</div><div className="t2">{r.device_name || ''}{r.device_name ? ' · ' : ''}{fmtDateTime(r.created_at)}</div></div>
            <span className={`pill ${r.final ? (m.buttons.find((b) => b.id === r.button_id)?.style === 'danger' ? 'err' : 'ok') : 'warn'}`}>{r.button_label}</span>
          </div>
        ))}
        {finals.length !== (resp?.length ?? 0) && <div className="t-r12 cdis" style={{ marginTop: 8 }}>Prikazan je zadnji odgovor vsakega uporabnika ({resp?.length} vseh klikov).</div>}
        <div style={{ height: 24 }} />
      </div>
      {preview && <MessagePreview m={m} onClose={() => setPreview(false)} />}
    </Screen>
  );
}

/* ------------------------------------------------------------ obrazec */

/** novi gumbi dobijo ID, ki se ne ponovi (odgovori se vežejo na ID) */
function withIds(bs: MsgButton[]): MsgButton[] {
  const used = new Set(bs.map((b) => b.id).filter(Boolean));
  let n = 1;
  return bs.map((b) => {
    if (b.id) return { ...b, label: b.label.trim() };
    while (used.has('b' + n)) n++;
    used.add('b' + n);
    return { ...b, id: 'b' + n, label: b.label.trim() };
  });
}

export function MessageFormScreen({ id }: { id?: string }) {
  const { back, replace, toast, confirm, pop, stack } = useNav();
  const { messages, overview, reloadMessages } = useData();
  const existing = id ? messages?.find((m) => m.id === id) : undefined;
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [kind, setKind] = useState<Message['kind']>('info');
  const [buttons, setButtons] = useState<MsgButton[]>([{ label: 'Potrdi', style: 'primary', action: 'close' }, { label: 'Zavrni', style: 'danger', action: 'close' }]);
  const [target, setTarget] = useState<'all' | 'accounts'>('all');
  const [ids, setIds] = useState<string[]>([]);
  const [repeat, setRepeat] = useState(false);
  const [endsAt, setEndsAt] = useState('');
  const [editBtn, setEditBtn] = useState<number | null>(null);
  const [pick, setPick] = useState(false);
  const [preview, setPreview] = useState(false);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!existing) return;
    setTitle(existing.title); setBody(existing.body); setKind(existing.kind); setButtons(existing.buttons.map((b) => ({ ...b })));
    setTarget(existing.target); setIds(existing.target_ids); setRepeat(existing.repeat); setEndsAt(existing.ends_at ? existing.ends_at.slice(0, 10) : '');
  }, [existing?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const accounts = overview?.accounts ?? [];
  const setBtn = (i: number, p: Partial<MsgButton>) => setButtons((bs) => bs.map((b, j) => (j === i ? { ...b, ...p } : b)));
  const move = (i: number, d: number) => setButtons((bs) => { const c = [...bs]; const [x] = c.splice(i, 1); c.splice(i + d, 0, x); return c; });

  const submit = async () => {
    setErr('');
    if (!title.trim()) return setErr('Vpiši naslov.');
    if (!buttons.length) return setErr('Dodaj vsaj en gumb.');
    if (buttons.some((b) => !b.label.trim())) return setErr('Vsak gumb potrebuje napis.');
    if (buttons.some((b) => b.action === 'link' && !/^https:\/\/\S{3,}$/.test(b.url ?? ''))) return setErr('Povezava mora začeti s https://');
    if (buttons.every((b) => b.action === 'exit' || b.action === 'later')) return setErr('Vsaj en gumb naj sporočilo zapre (Potrdi, V redu …) ali odpre povezavo.');
    if (target === 'accounts' && !ids.length) return setErr('Izberi vsaj en račun.');
    setBusy(true);
    try {
      const r = await api.saveMessage({
        id, title: title.trim(), body: body.trim(), kind, target, target_ids: target === 'accounts' ? ids : [], repeat,
        buttons: withIds(buttons),
        ends_at: endsAt ? new Date(endsAt + 'T23:59:59').toISOString() : null,
        active: existing ? existing.active : true,
      });
      await reloadMessages();
      toast(id ? 'Spremembe shranjene' : 'Sporočilo poslano');
      if (id) back(); else replace({ name: 'message', id: r.id });
    } catch (e) { setErr(errText(e)); }
    setBusy(false);
  };
  const del = async () => {
    if (!existing) return;
    if (!(await confirm({ title: 'Izbriši sporočilo?', text: `»${existing.title}« in vsi odgovori bodo izbrisani.`, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> }))) return;
    try {
      await api.deleteMessage(existing.id); await reloadMessages(); toast('Sporočilo izbrisano');
      const prev = stack[stack.length - 2] as { name: string; id?: string } | undefined;
      pop(prev?.name === 'message' && prev.id === existing.id ? 2 : 1);
    } catch (e) { toast(errText(e)); }
  };

  const b = editBtn !== null ? buttons[editBtn] : null;
  const unused = PRESETS.filter((p) => !buttons.some((x) => x.label === p.label));

  return (
    <Screen>
      <TopBar close title={id ? 'Uredi sporočilo' : 'Novo sporočilo'} obrazec actions={id ? <button className="iconbtn danger" aria-label="Izbriši sporočilo" onClick={del}><Trash2 size={20} /></button> : undefined} />
      <div className="scroll">
        <Label>Naslov</Label>
        <TextField value={title} onChange={setTitle} placeholder="npr. Nova pravila uporabe" maxLength={120} />
        <Label>Besedilo</Label>
        <textarea className="field area" value={body} onChange={(e) => setBody(e.target.value)} placeholder="Kaj želiš sporočiti uporabnikom …" maxLength={4000} rows={5} />
        <Label>Vrsta</Label>
        <ChipGroup value={kind} options={[...KIND_OPTS]} onChange={(k) => setKind(k as Message['kind'])} />

        <Label>Gumbi ({buttons.length}/4)</Label>
        <div className="card" style={{ padding: 6 }}>
          {buttons.length === 0 && <div className="t-r14 c2" style={{ padding: 10 }}>Dodaj vsaj en gumb.</div>}
          {buttons.map((x, i) => (
            <div key={i} className="row btnrow">
              <span className={`dot sm ${x.style}`} />
              <button className="main" onClick={() => setEditBtn(i)}>
                <div className="t-b15">{x.label || '(brez napisa)'}</div>
                <div className="t-r12 c2">{ACTIONS.find((a) => a.id === x.action)?.label}{x.action === 'link' && x.url ? ` · ${x.url}` : ''}</div>
              </button>
              <button className="iconbtn" aria-label="Gor" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp size={18} /></button>
              <button className="iconbtn" aria-label="Dol" disabled={i === buttons.length - 1} onClick={() => move(i, 1)}><ArrowDown size={18} /></button>
              <button className="iconbtn danger" aria-label="Odstrani gumb" onClick={() => setButtons(buttons.filter((_, j) => j !== i))}><X size={18} /></button>
            </div>
          ))}
        </div>
        {buttons.length < 4 && (
          <div className="chips" style={{ marginTop: 10 }}>
            {unused.map((p) => <Chip key={p.label} onClick={() => setButtons([...buttons, { ...p }])}>+ {p.label}</Chip>)}
            <Chip onClick={() => { setButtons([...buttons, { label: '', style: 'secondary', action: 'close' }]); setEditBtn(buttons.length); }}>+ Lasten gumb</Chip>
          </div>
        )}

        <Label>Prejemniki</Label>
        <div className="segment">
          <Chip on={target === 'all'} onClick={() => setTarget('all')}>Vsi uporabniki</Chip>
          <Chip on={target === 'accounts'} onClick={() => { setTarget('accounts'); if (!ids.length) setPick(true); }}>Izbrani računi</Chip>
        </div>
        {target === 'accounts' && (
          <button className="field" style={{ marginTop: 10 }} onClick={() => setPick(true)}>
            <Users size={18} color="var(--text-2)" />
            <span className="t-r15" style={{ flex: 1, textAlign: 'left' }}>{ids.length ? accounts.filter((a) => ids.includes(a.id)).map((a) => a.name || a.email).join(', ') : 'Izberi račune …'}</span>
            <ChevronRight size={20} />
          </button>
        )}
        <div className="row" style={{ marginTop: 16, gap: 12 }}>
          <div style={{ flex: 1 }}><div className="t-r15">Pokaži ob vsakem odprtju</div><div className="t-r12 c2">tudi po odgovoru (npr. stalno obvestilo)</div></div>
          <Toggle on={repeat} onChange={setRepeat} label="Ponavljaj" />
        </div>
        <Label>Velja do (neobvezno)</Label>
        <input className="field" type="date" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} style={{ colorScheme: 'dark' }} />
        {err && <div className="errtext" style={{ fontSize: 14 }}>{err}</div>}
        <div style={{ height: 16 }} />
      </div>
      <div className="footer">
        <Button variant="secondary" icon={<Eye size={18} />} onClick={() => setPreview(true)}>Predogled</Button>
        <Button icon={id ? <Check size={20} /> : <Send size={18} />} loading={busy} onClick={submit}>{id ? 'Shrani' : 'Pošlji'}</Button>
      </div>

      <Sheet open={b !== null} onClose={() => setEditBtn(null)} title="Gumb" footer={<Button style={{ flex: 1 }} onClick={() => setEditBtn(null)}>Končano</Button>}>
        {b && editBtn !== null && (
          <>
            <Label>Napis</Label>
            <TextField value={b.label} onChange={(v) => setBtn(editBtn, { label: v })} placeholder="npr. Potrdi" maxLength={30} autoFocus={!b.label} />
            <Label>Videz</Label>
            <ChipGroup value={b.style} options={[...STYLE_OPTS]} onChange={(s) => setBtn(editBtn, { style: s as MsgButton['style'] })} />
            <Label>Ob kliku</Label>
            <div className="card" style={{ padding: 4, background: 'var(--bg-field)' }}>
              {ACTIONS.map((a) => (
                <button key={a.id} className="row" onClick={() => setBtn(editBtn, { action: a.id, url: a.id === 'link' ? (b.url || 'https://') : undefined })}
                  style={{ width: '100%', padding: '10px 12px', borderRadius: 10, background: b.action === a.id ? 'var(--bg-selected)' : 'transparent', textAlign: 'left', gap: 12 }}>
                  <div style={{ flex: 1 }}><div className={b.action === a.id ? 't-b15' : 't-r15'}>{a.label}</div><div className="t-r12 c2">{a.hint}</div></div>
                  <Radio on={b.action === a.id} />
                </button>
              ))}
            </div>
            {b.action === 'link' && <><Label>Povezava</Label><TextField value={b.url ?? ''} onChange={(v) => setBtn(editBtn, { url: v.trim() })} placeholder="https://…" type="url" /></>}
          </>
        )}
      </Sheet>

      <Sheet open={pick} onClose={() => setPick(false)} title="Prejemniki" footer={<Button style={{ flex: 1 }} onClick={() => setPick(false)}>Izberi ({ids.length})</Button>}>
        {accounts.length === 0 && <div className="t-r14 c2">Ni računov.</div>}
        {accounts.map((a) => {
          const on = ids.includes(a.id);
          return (
            <button key={a.id} className="row" onClick={() => setIds(on ? ids.filter((x) => x !== a.id) : [...ids, a.id])}
              style={{ width: '100%', padding: '10px 6px', textAlign: 'left', gap: 12, borderBottom: '1px solid var(--border)' }}>
              <span className={`checkbox ${on ? 'on' : ''}`}>{on && <Check size={14} strokeWidth={3} />}</span>
              <div style={{ flex: 1, minWidth: 0 }}><div className="t-b15">{a.name || a.email}</div><div className="t-r12 c2">{a.email}{a.disabled ? ' · onemogočen' : ''}</div></div>
            </button>
          );
        })}
      </Sheet>

      {preview && <MessagePreview m={{ title, body, kind, buttons }} onClose={() => setPreview(false)} />}
    </Screen>
  );
}
