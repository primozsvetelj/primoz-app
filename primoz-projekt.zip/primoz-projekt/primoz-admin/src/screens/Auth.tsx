import { useEffect, useState } from 'react';
import { ShieldCheck, Mail, KeyRound, Smartphone, Copy, Delete, LogOut, ShieldAlert, ExternalLink } from 'lucide-react';
import QRCode from 'qrcode';
import { Preferences } from '@capacitor/preferences';
import { Label, TextField, Button } from '../ui/components';
import { supabase } from '../lib/supabase';
import { copyText, tap } from '../lib/native';
import { checkPin, setPin } from '../lib/pin';

function AuthFrame({ icon, title, text, children }: { icon: React.ReactNode; title: string; text?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="screen fade-enter">
      <div className="scroll" style={{ display: 'flex', flexDirection: 'column', paddingTop: 64 }}>
        <div style={{ width: 64, height: 64, borderRadius: 32, background: 'var(--bg-selected)', color: 'var(--violet)', display: 'flex', alignItems: 'center', justifyContent: 'center', alignSelf: 'center' }}>{icon}</div>
        <div style={{ textAlign: 'center', fontSize: 26, fontWeight: 600, marginTop: 18 }}>{title}</div>
        {text && <div className="t-r15 c2" style={{ textAlign: 'center', marginTop: 10, lineHeight: 1.5 }}>{text}</div>}
        {children}
      </div>
    </div>
  );
}

const authErr = (m: string) =>
  /invalid login/i.test(m) ? 'Napačna e-pošta ali geslo.'
  : /not confirmed/i.test(m) ? 'E-pošta še ni potrjena – odpri povezavo v potrditvenem e-sporočilu.'
  : /rate|too many/i.test(m) ? 'Preveč poskusov. Počakaj nekaj minut.'
  : /signups? not allowed|disabled/i.test(m) ? 'Ustvarjanje novih admin računov je izklopljeno.'
  : /password/i.test(m) && /short|least|weak/i.test(m) ? 'Geslo je prešibko (vsaj 10 znakov).'
  : /already registered/i.test(m) ? 'Ta e-pošta je že registrirana – prijavi se.'
  : /fetch|network/i.test(m) ? 'Ni povezave s strežnikom.'
  : 'Prijava ni uspela.';

/* ------------------------------------------------------------ prijava */

export function AdminLogin({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [setupDone, setSetupDone] = useState(true);
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { Preferences.get({ key: 'setupDone' }).then((r) => setSetupDone(r.value === '1')); }, []);

  const submit = async () => {
    setErr(''); setInfo('');
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) return setErr('Vpiši veljaven e-poštni naslov.');
    if (mode === 'signup') {
      if (pw.length < 10) return setErr('Geslo naj ima vsaj 10 znakov.');
      if (pw !== pw2) return setErr('Gesli se ne ujemata.');
      setBusy(true);
      const { data, error } = await supabase.auth.signUp({ email: email.trim(), password: pw });
      setBusy(false);
      if (error) return setErr(authErr(error.message));
      if (data.session) { onDone(); return; }
      setMode('login'); setPw(''); setPw2('');
      setInfo('Račun je ustvarjen. Potrdi ga s povezavo v e-sporočilu, nato se prijavi. Administratorske pravice ti dodeli nastavitev strežnika.');
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw });
    setBusy(false);
    if (error) return setErr(authErr(error.message));
    setPw('');
    onDone();
  };

  return (
    <AuthFrame icon={<ShieldCheck size={30} />} title="Primož Admin" text={mode === 'signup' ? 'Prva nastavitev – ustvari račun administratorja' : 'Upravljanje računov, naprav in sporočil'}>
      {info && <div className="card t-r14" style={{ padding: 12, marginTop: 18, background: 'var(--success-bg)', borderColor: '#1f4a35', lineHeight: 1.45 }}>{info}</div>}
      <Label>E-pošta</Label>
      <TextField value={email} onChange={setEmail} type="email" inputMode="email" placeholder="admin@primer.si" icon={<Mail size={20} color="var(--text-2)" />} />
      <Label>Geslo</Label>
      <TextField value={pw} onChange={setPw} type="password" placeholder="••••••••••" icon={<KeyRound size={20} color="var(--text-2)" />} onEnter={mode === 'login' ? submit : undefined} />
      {mode === 'signup' && <><Label>Ponovi geslo</Label><TextField value={pw2} onChange={setPw2} type="password" placeholder="••••••••••" icon={<KeyRound size={20} color="var(--text-2)" />} onEnter={submit} /></>}
      {err && <div className="errtext" style={{ fontSize: 14 }}>{err}</div>}
      <Button style={{ marginTop: 20 }} onClick={submit} loading={busy}>{mode === 'signup' ? 'Ustvari admin račun' : 'Prijava'}</Button>
      {(!setupDone || mode === 'signup') && (
        <button className="btn ghost s" style={{ marginTop: 18, alignSelf: 'center' }} onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setErr(''); }}>
          {mode === 'login' ? 'Prva nastavitev? Ustvari admin račun' : 'Nazaj na prijavo'}
        </button>
      )}
      <div className="t-r12 cdis" style={{ textAlign: 'center', marginTop: 'auto', paddingTop: 24 }}>Zaščiteno z dvostopenjsko prijavo (2FA) in PIN kodo.</div>
    </AuthFrame>
  );
}

/* ------------------------------------------------------------ 2FA */

export function MfaEnroll({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const [f, setF] = useState<{ id: string; secret: string; uri: string; qr: string } | null>(null);
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: list } = await supabase.auth.mfa.listFactors();
      for (const x of list?.all ?? []) if (x.status !== 'verified') await supabase.auth.mfa.unenroll({ factorId: x.id });
      const { data, error } = await supabase.auth.mfa.enroll({ factorType: 'totp', friendlyName: `Primož Admin ${new Date().toISOString().slice(0, 16)}`, issuer: 'Primož Admin' });
      if (error || !data) return setErr('2FA ni mogoče nastaviti: ' + (error?.message ?? ''));
      const qr = await QRCode.toDataURL(data.totp.uri, { margin: 1, width: 220, color: { dark: '#000000', light: '#ffffff' } });
      setF({ id: data.id, secret: data.totp.secret, uri: data.totp.uri, qr });
    })();
  }, []);

  const verify = async () => {
    if (!f || !/^\d{6}$/.test(code)) return setErr('Vpiši 6-mestno kodo.');
    setBusy(true); setErr('');
    const { error } = await supabase.auth.mfa.challengeAndVerify({ factorId: f.id, code });
    setBusy(false);
    if (error) return setErr('Koda ni pravilna. Preveri čas na telefonu in poskusi z novo kodo.');
    onDone();
  };

  return (
    <AuthFrame icon={<Smartphone size={30} />} title="Vklopi 2FA" text="Za vstop v admin aplikacijo je obvezna dodatna koda iz aplikacije za avtentikacijo (Google Authenticator, Microsoft Authenticator …).">
      {!f && !err && <div className="t-r14 c2" style={{ textAlign: 'center', marginTop: 24 }}>Pripravljam …</div>}
      {f && (
        <>
          <div className="card" style={{ padding: 16, marginTop: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <div className="t-b15">1. Dodaj račun v aplikacijo za avtentikacijo</div>
            <a className="btn primary m" style={{ width: '100%' }} href={f.uri}><ExternalLink size={18} />Odpri aplikacijo za avtentikacijo</a>
            <div className="t-r13 c2">ali skeniraj kodo z drugim telefonom</div>
            <img src={f.qr} alt="QR koda za 2FA" width={180} height={180} style={{ borderRadius: 12, background: '#fff', padding: 6 }} />
            <div className="t-r13 c2">ali ročno vpiši ključ:</div>
            <button className="row" style={{ gap: 8, fontFamily: 'ui-monospace, monospace', fontSize: 14, letterSpacing: 1, wordBreak: 'break-all', textAlign: 'left' }} onClick={() => copyText(f.secret)}>
              <span>{f.secret}</span><Copy size={16} color="var(--violet)" style={{ flex: 'none' }} />
            </button>
          </div>
          <Label>2. Vpiši 6-mestno kodo iz aplikacije</Label>
          <TextField value={code} onChange={(v) => setCode(v.replace(/\D/g, '').slice(0, 6))} inputMode="numeric" placeholder="123456" onEnter={verify} />
        </>
      )}
      {err && <div className="errtext" style={{ fontSize: 14 }}>{err}</div>}
      <Button style={{ marginTop: 20 }} onClick={verify} loading={busy} disabled={!f}>Potrdi in vklopi 2FA</Button>
      <Button variant="ghost" style={{ marginTop: 8 }} onClick={onCancel}>Odjava</Button>
    </AuthFrame>
  );
}

export function MfaVerify({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const verify = async () => {
    if (!/^\d{6}$/.test(code)) return setErr('Vpiši 6-mestno kodo.');
    setBusy(true); setErr('');
    const { data } = await supabase.auth.mfa.listFactors();
    const factor = data?.totp?.[0];
    if (!factor) { setBusy(false); return setErr('2FA ni nastavljen.'); }
    const { error } = await supabase.auth.mfa.challengeAndVerify({ factorId: factor.id, code });
    setBusy(false);
    if (error) { setCode(''); return setErr(/rate|too many/i.test(error.message) ? 'Preveč poskusov – počakaj.' : 'Koda ni pravilna.'); }
    onDone();
  };
  return (
    <AuthFrame icon={<Smartphone size={30} />} title="Dvostopenjska prijava" text="Vpiši 6-mestno kodo iz aplikacije za avtentikacijo.">
      <Label>Koda</Label>
      <TextField value={code} onChange={(v) => setCode(v.replace(/\D/g, '').slice(0, 6))} inputMode="numeric" placeholder="123456" autoFocus onEnter={verify} />
      {err && <div className="errtext" style={{ fontSize: 14 }}>{err}</div>}
      <Button style={{ marginTop: 20 }} onClick={verify} loading={busy}>Potrdi</Button>
      <Button variant="ghost" style={{ marginTop: 8 }} onClick={onCancel}>Odjava</Button>
    </AuthFrame>
  );
}

export function NotAdmin({ onLogout }: { onLogout: () => void }) {
  return (
    <AuthFrame icon={<ShieldAlert size={30} />} title="Ni administratorskih pravic" text="Ta račun ni administrator. Če si ravnokar ustvaril admin račun, mora biti še dodan med administratorje na strežniku.">
      <Button style={{ marginTop: 28 }} icon={<LogOut size={18} />} onClick={onLogout}>Odjava</Button>
    </AuthFrame>
  );
}

/* ------------------------------------------------------------ PIN */

function PinPad({ title, text, error, onComplete, footer }: { title: string; text?: string; error?: string; onComplete: (pin: string) => void; footer?: React.ReactNode }) {
  const [pin, setPinVal] = useState('');
  useEffect(() => { if (error) setPinVal(''); }, [error]);
  const press = (d: string) => {
    tap();
    const next = (pin + d).slice(0, 6);
    setPinVal(next);
    if (next.length === 6) setTimeout(() => { onComplete(next); setPinVal(''); }, 120);
  };
  return (
    <div className="screen fade-enter">
      <div className="scroll" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 70 }}>
        <div style={{ width: 56, height: 56, borderRadius: 28, background: 'var(--bg-selected)', color: 'var(--violet)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><KeyRound size={26} /></div>
        <div style={{ fontSize: 22, fontWeight: 600, marginTop: 16 }}>{title}</div>
        {text && <div className="t-r14 c2" style={{ marginTop: 8, textAlign: 'center' }}>{text}</div>}
        <div className="pin-dots" aria-label={`${pin.length} od 6`}>{Array.from({ length: 6 }, (_, i) => <span key={i} className={i < pin.length ? 'on' : ''} />)}</div>
        <div className="errtext" style={{ minHeight: 18, fontSize: 14 }}>{error}</div>
        <div className="pin-pad">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => <button key={d} onClick={() => press(d)}>{d}</button>)}
          <span />
          <button onClick={() => press('0')}>0</button>
          <button aria-label="Briši" onClick={() => setPinVal(pin.slice(0, -1))}><Delete size={24} /></button>
        </div>
        {footer}
      </div>
    </div>
  );
}

export function PinSetup({ onDone }: { onDone: () => void }) {
  const [first, setFirst] = useState('');
  const [err, setErr] = useState('');
  return (
    <PinPad
      title={first ? 'Ponovi PIN' : 'Nastavi PIN'}
      text={first ? '' : '6-mestni PIN zaklene admin aplikacijo ob vsakem odprtju.'}
      error={err}
      onComplete={async (p) => {
        if (!first) {
          if (/^(\d)\1{5}$/.test(p) || '0123456789'.includes(p) || '9876543210'.includes(p)) { setErr('PIN je prelahek za ugibanje.'); return; }
          setErr(''); setFirst(p); return;
        }
        if (p !== first) { setFirst(''); setErr('PIN-a se ne ujemata. Poskusi znova.'); return; }
        await setPin(p);
        onDone();
      }}
    />
  );
}

export function PinLock({ onUnlock, onWipe }: { onUnlock: () => void; onWipe: () => void }) {
  const [err, setErr] = useState('');
  return (
    <PinPad
      title="Vpiši PIN"
      error={err}
      onComplete={async (p) => {
        const r = await checkPin(p);
        if (r === 'ok') return onUnlock();
        if (r === 'wipe') return onWipe();
        setErr(`Napačen PIN. Še ${r} ${r === 1 ? 'poskus' : r === 2 ? 'poskusa' : 'poskusi'}, nato odjava.`);
      }}
    />
  );
}
