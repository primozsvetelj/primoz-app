import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ChevronRight, Lock, Unlock, WifiOff, ShieldCheck, Bell, KeyRound, LogOut, Ban, Server, Smartphone, Check, Database, FileUp } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, TopBar, Toggle, Button, Sheet, Label, TextField, ChipGroup } from '../ui/components';
import { api, errText, type BlockedHw } from '../lib/api';
import { backgroundAlertsOn, enableBackgroundAlerts, setupNotifications } from '../lib/alerts';
import { supabase, SUPABASE_URL } from '../lib/supabase';
import { ago } from '../lib/labels';
import { useData } from '../data';
import { chunks, parseCatalogFile } from '../lib/catalog';
import { ADMIN_VERSION } from '../lib/version';

export { ADMIN_VERSION };
/** SHA-256 podpisnega certifikata uradnega APK (android/primoz-release.jks) */
export const OFFICIAL_CERT = '53ce2dc9ecaef05b23681bd8897bcc60af106f7e89b35260c0f7d361e99ade6c';

function Row({ icon, title, sub, value, onClick, right, danger }: { icon: ReactNode; title: string; sub?: string; value?: string; onClick?: () => void; right?: ReactNode; danger?: boolean }) {
  return (
    <div role="button" tabIndex={0} className="row" style={{ width: '100%', padding: '12px 14px', minHeight: 56, gap: 14, cursor: onClick ? 'pointer' : 'default' }} onClick={onClick}>
      <span style={{ width: 32, height: 32, borderRadius: 8, background: danger ? 'var(--error-bg)' : 'var(--bg-field)', color: danger ? 'var(--error)' : undefined, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}>{icon}</span>
      <span style={{ flex: 1, minWidth: 0 }}><span className="t-b16" style={{ display: 'block' }}>{title}</span>{sub && <span className="t-r12 c2">{sub}</span>}</span>
      {value && <span className="t-r14 c2">{value}</span>}
      {right ?? (onClick ? <ChevronRight size={20} /> : null)}
    </div>
  );
}

export function SettingsScreen({ onLogout, onLock, onChangePin }: { onLogout: () => void; onLock: () => void; onChangePin: () => void }) {
  const { push, confirm, toast } = useNav();
  const { overview, reload } = useData();
  const cfg = overview?.config;
  const [bg, setBg] = useState(true);
  const [email, setEmail] = useState('');
  const [blockedOpen, setBlockedOpen] = useState(false);
  const [offlineOpen, setOfflineOpen] = useState(false);
  const [catalogCount, setCatalogCount] = useState(0);
  const [catalogBusy, setCatalogBusy] = useState(false);
  const [catalogProgress, setCatalogProgress] = useState('');
  const catalogInput = useRef<HTMLInputElement>(null);
  useEffect(() => { backgroundAlertsOn().then(setBg); supabase.auth.getUser().then((r) => setEmail(r.data.user?.email ?? '')); }, []);
  useEffect(() => { api.catalogStatus().then((x) => setCatalogCount(x.count)).catch(() => {}); }, []);

  const setCfg = async (p: Parameters<typeof api.setConfig>[0], msg: string) => {
    try { await api.setConfig(p); await reload(); toast(msg); } catch (e) { toast(errText(e)); }
  };
  const toggleIntegrity = async (on: boolean) => {
    if (on && !(await confirm({ title: 'Sprejmi samo uradno aplikacijo?', text: 'Naprave s predelano ali drugače podpisano različico aplikacije Primož app bodo zaklenjene. Vklopi šele, ko imajo vsi uporabniki nameščen uradni APK (podpisan z vašim ključem).', okLabel: 'Vklopi' }))) return;
    setCfg({ expected_cert: on ? OFFICIAL_CERT : '' }, on ? 'Zaščita pred predelano aplikacijo vklopljena' : 'Izklopljeno');
  };
  const toggleBg = async (on: boolean) => {
    try {
      if (on) await setupNotifications();
      await enableBackgroundAlerts(on); setBg(on); toast(on ? 'Obvestila v ozadju vklopljena' : 'Obvestila v ozadju izklopljena');
    } catch (e) { toast(errText(e)); }
  };

  const importCatalog = async (file?: File) => {
    if (!file) return;
    setCatalogBusy(true);
    setCatalogProgress('Berem Excel …');
    try {
      const rows = await parseCatalogFile(file);
      const ok = await confirm({
        title: 'Zamenjaj katalog vozil?',
        text: `Excel vsebuje ${rows.length.toLocaleString('sl-SI')} veljavnih vrstic. Obstoječi katalog bo zamenjan šele, ko bodo vsi deli varno naloženi. Opozorila in status preverjenosti se ohranijo.`,
        okLabel: 'Uvozi',
      });
      if (!ok) return;
      const { batch } = await api.catalogBegin();
      const parts = chunks(rows);
      for (let i = 0; i < parts.length; i++) {
        setCatalogProgress(`Nalaganje ${Math.min((i + 1) * 75, rows.length).toLocaleString('sl-SI')} / ${rows.length.toLocaleString('sl-SI')}`);
        await api.catalogChunk(batch, parts[i]);
      }
      const result = await api.catalogCommit(batch);
      setCatalogCount(result.count);
      toast(`Katalog posodobljen: ${result.count.toLocaleString('sl-SI')} vozil`);
    } catch (e) {
      const code = (e as Error)?.message;
      toast(code === 'missing_sheet' ? 'V Excelu manjka list Specifikacije.' : code === 'duplicate_id' ? 'Excel vsebuje podvojene ID-je.' : errText(e));
    } finally {
      setCatalogBusy(false);
      setCatalogProgress('');
      if (catalogInput.current) catalogInput.current.value = '';
    }
  };

  return (
    <Screen nav animate={false}>
      <div className="scroll" style={{ paddingTop: 12 }}>
        <div className="h-big">Nastavitve</div>

        <div className="label">Aplikacija Primož app</div>
        <div className="card">
          <Row icon={cfg?.locked ? <Lock size={18} /> : <Unlock size={18} />} danger={cfg?.locked} title="Zaklep aplikacije" sub={cfg?.locked ? 'Zaklenjeno za vse uporabnike' : 'Zakleni na daljavo za vse uporabnike'} onClick={() => push({ name: 'appLock' })} value={cfg?.locked ? 'Vklopljen' : 'Izklopljen'} />
          <div className="divider" />
          <Row icon={<WifiOff size={18} />} title="Delovanje brez interneta" sub="Po tem času mora naprava preveriti račun" value={cfg ? `${cfg.offline_days} dni` : ''} onClick={() => setOfflineOpen(true)} />
          <div className="divider" />
          <Row icon={<ShieldCheck size={18} />} title="Samo uradna aplikacija" sub="Zaklene predelane APK-je (preverjanje podpisa)" right={<span onClick={(e) => e.stopPropagation()}><Toggle on={!!cfg?.expected_cert} onChange={toggleIntegrity} label="Samo uradna aplikacija" /></span>} />
          <div className="divider" />
          <Row icon={<Ban size={18} />} title="Prepovedane naprave" sub="Strojni ID-ji, ki ne morejo vstopiti" onClick={() => setBlockedOpen(true)} />
          <div className="divider" />
          <Row icon={<Database size={18} />} title="Katalog vozil" sub={catalogBusy ? catalogProgress : `${catalogCount.toLocaleString('sl-SI')} zapisov · uvoz iz Excela`} onClick={() => !catalogBusy && catalogInput.current?.click()} right={<FileUp size={20} />} />
          <input ref={catalogInput} type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" hidden onChange={(e) => importCatalog(e.target.files?.[0])} />
        </div>

        <div className="label" style={{ marginTop: 20 }}>Admin aplikacija</div>
        <div className="card">
          <Row icon={<Bell size={18} />} title="Opozorila, ko je aplikacija zaprta" sub="Preverjanje vsakih ~15 minut" right={<span onClick={(e) => e.stopPropagation()}><Toggle on={bg} onChange={toggleBg} label="Obvestila v ozadju" /></span>} />
          <div className="divider" />
          <Row icon={<KeyRound size={18} />} title="Spremeni PIN" onClick={onChangePin} />
          <div className="divider" />
          <Row icon={<Lock size={18} />} title="Zakleni zdaj" onClick={onLock} />
        </div>

        <div className="label" style={{ marginTop: 20 }}>Račun administratorja</div>
        <div className="card">
          <Row icon={<Smartphone size={18} />} title={email || 'Admin'} sub="Prijava z geslom + 2FA koda + PIN" />
          <div className="divider" />
          <Row icon={<Server size={18} />} title="Strežnik" sub={SUPABASE_URL.replace(/^https:\/\//, '')} />
        </div>
        <Button variant="danger" style={{ width: '100%', marginTop: 20 }} icon={<LogOut size={20} />} onClick={async () => { if (await confirm({ title: 'Odjava', text: 'Za ponovno prijavo potrebuješ geslo in 2FA kodo.', okLabel: 'Odjava', danger: true })) onLogout(); }}>Odjava</Button>
        <div className="t-r12 cdis" style={{ textAlign: 'center', marginTop: 16, marginBottom: 20 }}>Primož Admin {ADMIN_VERSION}</div>
      </div>
      <OfflineSheet open={offlineOpen} value={cfg?.offline_days ?? 30} onClose={() => setOfflineOpen(false)} onSave={(d) => { setOfflineOpen(false); setCfg({ offline_days: d }, 'Shranjeno'); }} />
      <BlockedSheet open={blockedOpen} onClose={() => setBlockedOpen(false)} />
    </Screen>
  );
}

const DAYS = [{ id: '7', label: '7 dni' }, { id: '14', label: '14 dni' }, { id: '30', label: '30 dni' }, { id: '60', label: '60 dni' }, { id: '90', label: '90 dni' }];
function OfflineSheet({ open, value, onClose, onSave }: { open: boolean; value: number; onClose: () => void; onSave: (d: number) => void }) {
  const [v, setV] = useState(String(value));
  useEffect(() => { if (open) setV(String(value)); }, [open, value]);
  return (
    <Sheet open={open} onClose={onClose} title="Delovanje brez interneta"
      footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Prekliči</Button><Button style={{ flex: 1 }} icon={<Check size={18} />} onClick={() => onSave(Number(v))}>Shrani</Button></>}>
      <div className="t-r14 c2" style={{ lineHeight: 1.5, marginBottom: 12 }}>Uporabnik ostane prijavljen za vedno. Ko je telefon toliko dni brez interneta, mora le enkrat preveriti račun (brez ponovne prijave). V tem času ga ne moreš zakleniti na daljavo.</div>
      <ChipGroup value={v} options={DAYS} onChange={setV} />
    </Sheet>
  );
}

function BlockedSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { toast, confirm } = useNav();
  const { reload } = useData();
  const [list, setList] = useState<BlockedHw[] | null>(null);
  const load = () => api.blockedHw().then(setList).catch(() => setList([]));
  useEffect(() => { if (open) load(); }, [open]);
  const unblock = async (b: BlockedHw) => {
    if (!(await confirm({ title: 'Prekliči prepoved?', text: 'Naprava bo spet lahko vstopila (s pravilnim geslom).', okLabel: 'Prekliči prepoved' }))) return;
    try { await api.blockHw(b.hw_id, false); await load(); await reload(); toast('Prepoved preklicana'); } catch (e) { toast(errText(e)); }
  };
  return (
    <Sheet open={open} onClose={onClose} title="Prepovedane naprave" footer={<Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Zapri</Button>}>
      {list && list.length === 0 && <div className="t-r14 c2">Ni prepovedanih naprav.</div>}
      {list?.map((b) => (
        <div key={b.hw_id} className="listrow" style={{ cursor: 'default' }}>
          <div className="ico" style={{ background: 'var(--error-bg)' }}><Ban size={20} color="var(--error)" /></div>
          <div className="main">
            <div className="t1">{b.devices[0] ? `${b.devices[0].name || b.devices[0].model}` : 'Neznana naprava'}</div>
            <div className="t2">{b.reason || 'brez razloga'} · {b.last_attempt ? `zadnji poskus ${ago(b.last_attempt)}` : `prepovedano ${ago(b.created_at)}`}</div>
            <div className="t2 mono" style={{ fontSize: 11 }}>{b.hw_id}</div>
          </div>
          <Button variant="secondary" size="s" onClick={() => unblock(b)}>Prekliči</Button>
        </div>
      ))}
    </Sheet>
  );
}

export function AppLockScreen() {
  const { back, toast } = useNav();
  const { overview, reload } = useData();
  const cfg = overview?.config;
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (cfg) setMsg(cfg.lock_message); }, [cfg?.lock_message]); // eslint-disable-line react-hooks/exhaustive-deps
  const set = async (locked: boolean) => {
    setBusy(true);
    try { await api.setConfig({ locked, lock_message: msg.trim() }); await reload(); toast(locked ? 'Aplikacija zaklenjena za vse' : 'Aplikacija odklenjena'); back(); } catch (e) { toast(errText(e)); }
    setBusy(false);
  };
  return (
    <Screen>
      <TopBar close title="Zaklep aplikacije" obrazec />
      <div className="scroll">
        <div className={`card row statusbar ${cfg?.locked ? 'bad' : 'good'}`} style={{ marginTop: 8 }}>{cfg?.locked ? <Lock size={22} /> : <Unlock size={22} />}<span className="t-b15">{cfg?.locked ? 'Aplikacija je zaklenjena za vse uporabnike' : 'Aplikacija deluje normalno'}</span></div>
        <div className="t-r14 c2" style={{ lineHeight: 1.5, marginTop: 14 }}>Ko zakleneš aplikacijo, vsi uporabniki ob naslednji povezavi (najkasneje v 5 minutah, ko je odprta) vidijo zaklenjen zaslon s tvojim sporočilom. Podatki na telefonih ostanejo. Posamezne račune ali naprave zakleneš v zavihku Računi.</div>
        <Label>Sporočilo na zaklenjenem zaslonu</Label>
        <TextField value={msg} onChange={setMsg} placeholder="npr. Vzdrževanje do 14:00" />
      </div>
      <div className="footer">
        {cfg?.locked
          ? <><Button variant="secondary" loading={busy} onClick={() => set(true)}>Shrani sporočilo</Button><Button icon={<Unlock size={18} />} loading={busy} onClick={() => set(false)}>Odkleni</Button></>
          : <Button variant="danger" icon={<Lock size={18} />} loading={busy} onClick={() => set(true)}>Zakleni za vse</Button>}
      </div>
    </Screen>
  );
}
