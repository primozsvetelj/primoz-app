import { useEffect, useMemo, useState } from 'react';
import { Search, Plus, ChevronRight, Users, Smartphone, Ban, LogOut, Eraser, Trash2, Pencil, KeyRound, UserX, UserCheck, Check, Copy, RefreshCw, Eye, EyeOff, ShieldAlert, Lock, Unlock } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, TopBar, Button, Sheet, Label, TextField, Toggle, ChipGroup, Empty, SwipeRow } from '../ui/components';
import { api, errText, generatePassword, type Account, type Device } from '../lib/api';
import { DEVICE_STATUS, deviceTitle, ago, fmtDate, fmtDateTime } from '../lib/labels';
import { copyText } from '../lib/native';
import { useData } from '../data';
import { EventRow, EventSheet } from './Alerts';
import type { SecEvent } from '../lib/api';

export function accountState(a: Account): { label: string; cls: string } {
  if (a.disabled) return { label: 'Onemogočen', cls: 'err' };
  if (a.locked_until && new Date(a.locked_until) > new Date()) return { label: 'Začasno zaklenjen', cls: 'warn' };
  return { label: 'Aktiven', cls: 'ok' };
}

function Avatar({ name, size = 44 }: { name: string; size?: number }) {
  return <span className="avatar" style={{ width: size, height: size, borderRadius: size / 2, fontSize: size * 0.4 }}>{(name || '?').trim()[0]?.toUpperCase() ?? '?'}</span>;
}

/* ------------------------------------------------------------ seznam */

export function AccountsScreen() {
  const { push, confirm, toast } = useNav();
  const { overview, reload } = useData();
  const [q, setQ] = useState('');
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return (overview?.accounts ?? []).filter((a) => !s || `${a.name} ${a.email}`.toLowerCase().includes(s));
  }, [overview, q]);

  const del = async (a: Account) => {
    if (!(await confirm({ title: 'Izbriši račun?', text: `${a.name || a.email} bo trajno izbrisan. Vse njegove naprave se takoj odjavijo. Tega ni mogoče razveljaviti.`, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> }))) return;
    try { await api.deleteAccount(a.id); await reload(); toast('Račun izbrisan'); } catch (e) { toast(errText(e)); }
  };

  return (
    <Screen nav animate={false}>
      <div className="searchrow">
        <label className="searchbar" style={{ cursor: 'text' }}>
          <Search size={22} color="var(--text)" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Išči račun …" style={{ flex: 1, background: 'none', border: 0, color: 'var(--text)', fontSize: 15, outline: 'none' }} />
        </label>
        <button className="fabplus" aria-label="Nov račun" onClick={() => push({ name: 'accountForm' })}><Plus size={26} /></button>
      </div>
      <div className="scroll">
        <div className="h-big">Računi</div>
        {overview && overview.accounts.length === 0 && (
          <Empty icon={<Users size={30} />} title="Ni še računov" text="Ustvari račun za vsakega uporabnika aplikacije Primož app."
            action={<Button size="m" onClick={() => push({ name: 'accountForm' })}>Nov račun</Button>} />
        )}
        {list.map((a) => {
          const st = accountState(a);
          const active = a.devices.filter((d) => d.status === 'active').length;
          const risky = a.devices.some((d) => d.status === 'active' && (d.integrity?.rooted || d.integrity?.emulator));
          return (
            <SwipeRow key={a.id} className="card-row" onEdit={() => push({ name: 'accountForm', id: a.id })} onDelete={() => del(a)}>
              <button className="listrow" onClick={() => push({ name: 'account', id: a.id })}>
                <Avatar name={a.name || a.email} />
                <div className="main">
                  <div className="t1">{a.name || a.email}</div>
                  <div className="t2">{a.name ? a.email : ''}{a.name ? ' · ' : ''}{active} {active === 1 ? 'naprava' : active === 2 ? 'napravi' : active < 5 && active > 0 ? 'naprave' : 'naprav'}{risky ? ' · ⚠' : ''}</div>
                </div>
                <span className={`pill ${st.cls}`}>{st.label}</span>
                <ChevronRight size={20} />
              </button>
            </SwipeRow>
          );
        })}
        {list.length > 0 && <div className="swipehint">Povleci vrstico v levo za urejanje ali brisanje.</div>}
      </div>
    </Screen>
  );
}

/* ------------------------------------------------------------ podrobnosti */

export function AccountScreen({ id }: { id: string }) {
  const { push, back, confirm, toast } = useNav();
  const { overview, reload } = useData();
  const a = overview?.accounts.find((x) => x.id === id);
  const [dev, setDev] = useState<Device | null>(null);
  const [disableOpen, setDisableOpen] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const [events, setEvents] = useState<SecEvent[]>([]);
  const [ev, setEv] = useState<SecEvent | null>(null);
  useEffect(() => { api.events(15, undefined, id).then(setEvents).catch(() => {}); }, [id, overview]);

  if (!overview) return <Screen nav><TopBar title="" /></Screen>;
  if (!a) return <Screen nav><TopBar title="Račun" /><div className="empty">Račun ne obstaja več.</div></Screen>;
  const st = accountState(a);
  const devices = a.devices;

  const del = async () => {
    if (!(await confirm({ title: 'Izbriši račun?', text: `${a.name || a.email} bo trajno izbrisan. Vse njegove naprave se takoj odjavijo.`, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> }))) return;
    try { await api.deleteAccount(a.id); back(); await reload(); toast('Račun izbrisan'); } catch (e) { toast(errText(e)); }
  };
  const enable = async () => {
    try { await api.setDisabled(a.id, false); await reload(); toast('Račun omogočen – naprave se odklenejo'); } catch (e) { toast(errText(e)); }
  };
  const unlock = async () => {
    try { await api.setDisabled(a.id, false); await reload(); toast('Začasni zaklep odstranjen'); } catch (e) { toast(errText(e)); }
  };

  return (
    <Screen nav>
      <TopBar title="Račun" actions={<>
        <button className="iconbtn violet" aria-label="Uredi račun" onClick={() => push({ name: 'accountForm', id })}><Pencil size={22} /></button>
        <button className="iconbtn danger" aria-label="Izbriši račun" onClick={del}><Trash2 size={20} /></button>
      </>} />
      <div className="scroll">
        <div className="row" style={{ gap: 14, marginTop: 6 }}>
          <Avatar name={a.name || a.email} size={56} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="t-kartica" style={{ fontSize: 22, overflowWrap: 'anywhere' }}>{a.name || '—'}</div>
            <div className="t-r14 c2" style={{ overflowWrap: 'anywhere' }}>{a.email}</div>
          </div>
          <span className={`pill ${st.cls}`}>{st.label}</span>
        </div>

        {a.disabled && a.disabled_reason && <div className="card t-r14" style={{ padding: 12, marginTop: 12, background: 'var(--error-bg)', borderColor: '#4a1f28' }}>Razlog: {a.disabled_reason}</div>}

        <div className="row" style={{ gap: 10, marginTop: 16 }}>
          {a.disabled
            ? <Button style={{ flex: 1 }} icon={<UserCheck size={18} />} onClick={enable}>Omogoči račun</Button>
            : <Button variant="danger" style={{ flex: 1 }} icon={<UserX size={18} />} onClick={() => setDisableOpen(true)}>Onemogoči</Button>}
          <Button variant="secondary" style={{ flex: 1 }} icon={<KeyRound size={18} />} onClick={() => setPwOpen(true)}>Novo geslo</Button>
        </div>
        {st.cls === 'warn' && <Button variant="ghost" style={{ width: '100%', marginTop: 6 }} icon={<Unlock size={18} />} onClick={unlock}>Odstrani začasni zaklep</Button>}

        <div className="card" style={{ padding: '10px 16px', marginTop: 14 }}>
          <div className="kv"><span className="k">Ustvarjen</span><span className="v">{fmtDate(a.created_at)}</span></div>
          <div className="kv"><span className="k">Zadnja prijava</span><span className="v">{a.last_login_at ? fmtDateTime(a.last_login_at) : 'še nikoli'}</span></div>
          <div className="kv"><span className="k">Največ naprav</span><span className="v">{a.max_devices ?? 'brez omejitve'}</span></div>
          {a.must_change_pw && <div className="kv"><span className="k">Geslo</span><span className="v">mora ga spremeniti ob prijavi</span></div>}
          {a.note && <div className="kv"><span className="k">Opomba</span><span className="v">{a.note}</span></div>}
        </div>

        <div className="label" style={{ marginTop: 20 }}>Naprave ({devices.length})</div>
        {devices.length === 0 && <div className="t-r14 c2" style={{ padding: '6px 2px' }}>Ta račun se še ni prijavil na nobeni napravi.</div>}
        {devices.map((d) => <DeviceRow key={d.id} d={d} onClick={() => setDev(d)} />)}

        <div className="label" style={{ marginTop: 20 }}>Zadnji dogodki</div>
        {events.length === 0 && <div className="t-r14 c2" style={{ padding: '6px 2px' }}>Ni dogodkov.</div>}
        {events.map((e) => <EventRow key={e.id} e={e} onClick={() => setEv(e)} />)}
        <div style={{ height: 24 }} />
      </div>
      <DeviceSheet d={dev} account={a} onClose={() => setDev(null)} />
      <DisableSheet open={disableOpen} account={a} onClose={() => setDisableOpen(false)} />
      <PasswordSheet open={pwOpen} account={a} onClose={() => setPwOpen(false)} />
      <EventSheet e={ev} onClose={() => setEv(null)} />
    </Screen>
  );
}

function DeviceRow({ d, onClick }: { d: Device; onClick: () => void }) {
  const st = DEVICE_STATUS[d.status];
  const risky = d.integrity?.rooted || d.integrity?.emulator;
  return (
    <button className="listrow" onClick={onClick}>
      <div className="ico" style={{ background: d.status === 'blocked' ? 'var(--error-bg)' : undefined }}>{d.status === 'blocked' ? <Ban size={20} color="var(--error)" /> : <Smartphone size={20} />}</div>
      <div className="main">
        <div className="t1">{deviceTitle(d)}{risky ? ' ⚠' : ''}</div>
        <div className="t2">{[d.platform === 'android' ? `Android ${d.os_version}` : d.platform, d.app_version && `v${d.app_version}`, `zadnjič ${ago(d.last_seen)}`].filter(Boolean).join(' · ')}</div>
      </div>
      <span className={`pill ${st.cls}`}>{st.label}</span>
    </button>
  );
}

function DeviceSheet({ d, account, onClose }: { d: Device | null; account: Account; onClose: () => void }) {
  const { confirm, toast } = useNav();
  const { reload } = useData();
  const [rename, setRename] = useState<string | null>(null);
  if (!d) return null;
  const run = async (action: 'block' | 'unblock' | 'revoke' | 'wipe' | 'delete' | 'rename', msg: string, label?: string) => {
    try { await api.device(d.id, action, label); await reload(); toast(msg); onClose(); setRename(null); } catch (e) { toast(errText(e)); }
  };
  const ask = async (title: string, text: string, ok: string, icon: React.ReactNode, then: () => void) => {
    if (await confirm({ title, text, okLabel: ok, danger: true, icon })) then();
  };
  const name = deviceTitle(d);
  const integ = d.integrity ?? {};
  return (
    <>
      <Sheet open={rename === null} onClose={onClose} title={name} footer={<Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Zapri</Button>}>
        <div className="kvlist">
          <div className="kv"><span className="k">Stanje</span><span className="v"><span className={`pill ${DEVICE_STATUS[d.status].cls}`}>{DEVICE_STATUS[d.status].label}</span></span></div>
          <div className="kv"><span className="k">Model</span><span className="v">{[d.manufacturer, d.model].filter(Boolean).join(' ') || '—'}</span></div>
          <div className="kv"><span className="k">Sistem</span><span className="v">{d.platform} {d.os_version}</span></div>
          <div className="kv"><span className="k">Aplikacija</span><span className="v">{d.app_version || '—'}</span></div>
          <div className="kv"><span className="k">Prva prijava</span><span className="v">{fmtDateTime(d.first_seen)}</span></div>
          <div className="kv"><span className="k">Zadnja uporaba</span><span className="v">{fmtDateTime(d.last_seen)}</span></div>
          <div className="kv"><span className="k">Zadnji IP</span><span className="v">{d.last_ip || '—'}</span></div>
          <div className="kv"><span className="k">Varnost</span><span className="v">{[integ.rooted && 'root ⚠', integ.emulator && 'emulator ⚠', integ.debuggable && 'razhroščevanje ⚠'].filter(Boolean).join(', ') || 'brez posebnosti'}</span></div>
          {d.hw_id && <div className="kv"><span className="k">Strojni ID</span><span className="v mono">{d.hw_id}</span></div>}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
          {d.status !== 'blocked'
            ? <Button variant="danger" icon={<Ban size={18} />} onClick={() => ask('Prepovej napravo?', `${name} ne bo mogla več vstopiti v aplikacijo – z nobenim računom, tudi po ponovni namestitvi.`, 'Prepovej', <Ban size={22} />, () => run('block', 'Naprava prepovedana'))}>Prepovej napravo</Button>
            : <Button icon={<Unlock size={18} />} onClick={() => run('unblock', 'Prepoved preklicana')}>Prekliči prepoved</Button>}
          {d.status === 'active' && <Button variant="secondary" icon={<LogOut size={18} />} onClick={() => ask('Odjavi napravo?', `${name} bo odjavljena ob naslednji povezavi. Uporabnik se lahko ponovno prijavi z geslom.`, 'Odjavi', <LogOut size={22} />, () => run('revoke', 'Naprava bo odjavljena'))}>Odjavi s te naprave</Button>}
          {['active', 'revoked', 'signed_out'].includes(d.status) && <Button variant="secondary" icon={<Eraser size={18} />} onClick={() => ask('Izbriši podatke na napravi?', `Ob naslednji povezavi z internetom se na napravi ${name} izbrišejo vsi podatki aplikacije (vozila, servisi …) in naprava se odjavi. Uporabno ob izgubi ali kraji telefona.`, 'Izbriši podatke', <Eraser size={22} />, () => run('wipe', 'Izbris naročen'))}>Izbriši podatke na napravi</Button>}
          <Button variant="secondary" icon={<Pencil size={18} />} onClick={() => setRename(d.label || name)}>Preimenuj</Button>
          <Button variant="ghost" icon={<Trash2 size={18} />} onClick={() => ask('Odstrani napravo s seznama?', 'Naprava se odjavi in izgine s seznama. Prepovedi strojnega ID-ja ostanejo.', 'Odstrani', <Trash2 size={22} />, () => run('delete', 'Naprava odstranjena'))}>Odstrani s seznama</Button>
        </div>
        <div className="t-r12 cdis" style={{ marginTop: 10 }}>Račun: {account.name || account.email}</div>
      </Sheet>
      <Sheet open={rename !== null} onClose={() => setRename(null)} title="Preimenuj napravo"
        footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={() => setRename(null)}>Prekliči</Button><Button style={{ flex: 1 }} icon={<Check size={18} />} onClick={() => run('rename', 'Shranjeno', rename ?? '')}>Shrani</Button></>}>
        <Label>Ime naprave</Label>
        <TextField value={rename ?? ''} onChange={setRename} placeholder="npr. Službeni telefon" autoFocus />
      </Sheet>
    </>
  );
}

function DisableSheet({ open, account, onClose }: { open: boolean; account: Account; onClose: () => void }) {
  const { toast } = useNav();
  const { reload } = useData();
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    try { await api.setDisabled(account.id, true, reason.trim()); await reload(); toast('Račun onemogočen – naprave se zaklenejo'); onClose(); setReason(''); } catch (e) { toast(errText(e)); }
    setBusy(false);
  };
  return (
    <Sheet open={open} onClose={onClose} title="Onemogoči račun"
      footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Prekliči</Button><Button variant="danger" style={{ flex: 1 }} icon={<Lock size={18} />} loading={busy} onClick={go}>Onemogoči</Button></>}>
      <div className="t-r14 c2" style={{ lineHeight: 1.5 }}>Aplikacija se na vseh napravah tega računa zaklene ob naslednji povezavi (najkasneje v 5 minutah, ko je aplikacija odprta). Prijava ne bo mogoča. Podatki na napravah ostanejo; račun lahko kadarkoli ponovno omogočiš.</div>
      <Label>Sporočilo uporabniku (neobvezno)</Label>
      <TextField value={reason} onChange={setReason} placeholder="npr. Pogodba je potekla." />
    </Sheet>
  );
}

function PasswordSheet({ open, account, onClose }: { open: boolean; account: Account; onClose: () => void }) {
  const { toast } = useNav();
  const { reload } = useData();
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(true);
  const [must, setMust] = useState(true);
  const [signout, setSignout] = useState(false);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  useEffect(() => { if (open) { setPw(generatePassword()); setDone(false); setSignout(false); setMust(true); } }, [open]);
  const go = async () => {
    if (pw.length < 8) return toast('Geslo mora imeti vsaj 8 znakov.');
    setBusy(true);
    try { await api.setPassword(account.id, pw, must, signout); await reload(); setDone(true); } catch (e) { toast(errText(e)); }
    setBusy(false);
  };
  const share = `Primož app – prijava\nE-pošta: ${account.email}\nGeslo: ${pw}`;
  return (
    <Sheet open={open} onClose={onClose} title={done ? 'Geslo nastavljeno' : 'Novo geslo'}
      footer={done
        ? <><Button variant="secondary" style={{ flex: 1 }} icon={<Copy size={18} />} onClick={() => { copyText(share); toast('Podatki za prijavo kopirani'); }}>Kopiraj</Button><Button style={{ flex: 1 }} onClick={onClose}>Končano</Button></>
        : <><Button variant="secondary" style={{ flex: 1 }} onClick={onClose}>Prekliči</Button><Button style={{ flex: 1 }} icon={<KeyRound size={18} />} loading={busy} onClick={go}>Nastavi</Button></>}>
      {done ? (
        <div className="card" style={{ padding: 14, fontFamily: 'ui-monospace, monospace', fontSize: 15, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>{share}</div>
      ) : (
        <>
          <Label>Novo geslo</Label>
          <TextField value={pw} onChange={setPw} type={show ? 'text' : 'password'} trailing={<>
            <button type="button" className="iconbtn trail" aria-label="Prikaži" onClick={() => setShow(!show)}>{show ? <EyeOff size={20} /> : <Eye size={20} />}</button>
            <button type="button" className="iconbtn violet trail" aria-label="Ustvari geslo" onClick={() => setPw(generatePassword())}><RefreshCw size={20} /></button>
          </>} />
          <div className="row" style={{ marginTop: 14, gap: 12 }}><span className="t-r15" style={{ flex: 1 }}>Ob prijavi naj ga spremeni</span><Toggle on={must} onChange={setMust} label="Zahtevaj menjavo" /></div>
          <div className="row" style={{ marginTop: 14, gap: 12 }}><span className="t-r15" style={{ flex: 1 }}>Odjavi vse naprave tega računa</span><Toggle on={signout} onChange={setSignout} label="Odjavi vse" /></div>
          {signout && <div className="t-r12 c2" style={{ marginTop: 6 }}>Priporočeno, če sumiš, da je geslo poznal nekdo drug.</div>}
        </>
      )}
    </Sheet>
  );
}

/* ------------------------------------------------------------ obrazec */

const MAX_OPTS = [{ id: '', label: 'Brez omejitve' }, { id: '1', label: '1' }, { id: '2', label: '2' }, { id: '3', label: '3' }, { id: '5', label: '5' }];

export function AccountFormScreen({ id }: { id?: string }) {
  const { back, replace, toast, confirm, pop, stack } = useNav();
  const { overview, reload } = useData();
  const existing = id ? overview?.accounts.find((a) => a.id === id) : undefined;
  const [f, setF] = useState({ name: '', email: '', password: generatePassword(), max: '', note: '', must: true });
  const [show, setShow] = useState(true);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState<{ id: string; email: string; password: string } | null>(null);
  useEffect(() => { if (existing) setF((p) => ({ ...p, name: existing.name, email: existing.email, max: existing.max_devices ? String(existing.max_devices) : '', note: existing.note })); }, [existing?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = async () => {
    setErr('');
    if (!f.name.trim()) return setErr('Vpiši ime in priimek.');
    if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) return setErr('Vpiši veljaven e-poštni naslov.');
    if (!id && f.password.length < 8) return setErr('Geslo mora imeti vsaj 8 znakov.');
    setBusy(true);
    try {
      const r = await api.saveAccount({ id, name: f.name.trim(), email: f.email.trim(), max_devices: f.max ? Number(f.max) : null, note: f.note, ...(id ? {} : { password: f.password, must_change_pw: f.must }) });
      await reload();
      if (id) { toast('Spremembe shranjene'); back(); } else setCreated({ id: r.id, email: f.email.trim().toLowerCase(), password: f.password });
    } catch (e) { setErr(errText(e)); }
    setBusy(false);
  };
  const del = async () => {
    if (!existing) return;
    if (!(await confirm({ title: 'Izbriši račun?', text: `${existing.name || existing.email} bo trajno izbrisan. Vse njegove naprave se takoj odjavijo.`, okLabel: 'Izbriši', danger: true, icon: <Trash2 size={22} /> }))) return;
    try {
      await api.deleteAccount(existing.id); await reload(); toast('Račun izbrisan');
      const prev = stack[stack.length - 2] as { name: string; id?: string } | undefined;
      pop(prev?.name === 'account' && prev.id === existing.id ? 2 : 1);
    } catch (e) { toast(errText(e)); }
  };

  if (created) {
    const share = `Primož app – prijava\nE-pošta: ${created.email}\nGeslo: ${created.password}${f.must ? '\n(ob prvi prijavi si nastaviš svoje geslo)' : ''}`;
    return (
      <Screen>
        <TopBar close title="Račun ustvarjen" onBack={() => replace({ name: 'account', id: created.id })} />
        <div className="scroll" style={{ paddingTop: 20 }}>
          <div style={{ width: 72, height: 72, borderRadius: 36, background: 'var(--success-bg)', color: 'var(--success)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto' }}><Check size={36} /></div>
          <div className="t-r15 c2" style={{ textAlign: 'center', margin: '16px 0', lineHeight: 1.5 }}>Pošlji uporabniku podatke za prijavo. Geslo je prikazano samo zdaj.</div>
          <div className="card" style={{ padding: 16, fontFamily: 'ui-monospace, monospace', fontSize: 15, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{share}</div>
        </div>
        <div className="footer">
          <Button variant="secondary" icon={<Copy size={18} />} onClick={() => { copyText(share); toast('Podatki za prijavo kopirani'); }}>Kopiraj</Button>
          <Button onClick={() => replace({ name: 'account', id: created.id })}>Odpri račun</Button>
        </div>
      </Screen>
    );
  }

  return (
    <Screen>
      <TopBar close title={id ? 'Uredi račun' : 'Nov račun'} obrazec actions={id ? <button className="iconbtn danger" aria-label="Izbriši račun" onClick={del}><Trash2 size={20} /></button> : undefined} />
      <div className="subtitle">{id ? 'Posodobi podatke računa' : 'Uporabnik se bo s temi podatki prijavil v Primož app'}</div>
      <div className="scroll">
        <div className="card" style={{ padding: '4px 16px 18px' }}>
          <Label>Ime in priimek</Label>
          <TextField value={f.name} onChange={(v) => setF({ ...f, name: v })} placeholder="npr. Janez Novak" autoCapitalize="words" />
          <Label>E-pošta (za prijavo)</Label>
          <TextField value={f.email} onChange={(v) => setF({ ...f, email: v })} placeholder="janez@podjetje.si" type="email" inputMode="email" />
          {!id && (
            <>
              <Label>Začetno geslo</Label>
              <TextField value={f.password} onChange={(v) => setF({ ...f, password: v })} type={show ? 'text' : 'password'} trailing={<>
                <button type="button" className="iconbtn trail" aria-label="Prikaži" onClick={() => setShow(!show)}>{show ? <EyeOff size={20} /> : <Eye size={20} />}</button>
                <button type="button" className="iconbtn violet trail" aria-label="Ustvari geslo" onClick={() => setF({ ...f, password: generatePassword() })}><RefreshCw size={20} /></button>
              </>} />
              <div className="row" style={{ marginTop: 14, gap: 12 }}><span className="t-r15" style={{ flex: 1 }}>Ob prvi prijavi naj si nastavi svoje geslo</span><Toggle on={f.must} onChange={(v) => setF({ ...f, must: v })} label="Zahtevaj menjavo gesla" /></div>
            </>
          )}
          <Label>Največ naprav</Label>
          <ChipGroup value={f.max} options={MAX_OPTS} onChange={(v) => setF({ ...f, max: v })} />
          <Label>Opomba (vidiš samo ti)</Label>
          <TextField value={f.note} onChange={(v) => setF({ ...f, note: v })} placeholder="npr. servisna delavnica Kranj" />
          {err && <div className="errtext" style={{ fontSize: 14 }}>{err}</div>}
        </div>
        {!id && <div className="row t-r12 c2" style={{ gap: 6, marginTop: 10 }}><ShieldAlert size={14} />Geslo je na strežniku shranjeno samo kot zgoščena vrednost (bcrypt).</div>}
      </div>
      <div className="footer">
        <Button variant="secondary" onClick={() => back()}>Prekliči</Button>
        <Button icon={<Check size={20} />} loading={busy} onClick={submit}>{id ? 'Shrani spremembe' : 'Ustvari račun'}</Button>
      </div>
    </Screen>
  );
}
