import { useMemo, useState } from 'react';
import { ShieldAlert, AlertTriangle, Info, CheckCheck, Ban, UserX, ChevronRight, ShieldCheck, LogIn } from 'lucide-react';
import { useNav } from '../ui/nav';
import { Screen, Sheet, Button, Chip, Empty, Label, TextField } from '../ui/components';
import { api, errText, type SecEvent } from '../lib/api';
import { eventLabel, eventDevice, ATTACK_KINDS, ago, fmtDateTime, dayKey } from '../lib/labels';
import { useData } from '../data';

type Filter = 'attacks' | 'important' | 'all';

export function SevIcon({ s, size = 20 }: { s: SecEvent['severity']; size?: number }) {
  if (s === 'high') return <ShieldAlert size={size} color="var(--error)" />;
  if (s === 'warn') return <AlertTriangle size={size} color="var(--orange)" />;
  return <Info size={size} color="var(--text-2)" />;
}

export function EventRow({ e, onClick }: { e: SecEvent; onClick: () => void }) {
  const dev = eventDevice(e);
  const who = e.account_name || e.email || 'Neznan račun';
  return (
    <button className={`listrow ev ${!e.seen && e.severity !== 'info' ? 'unseen' : ''}`} onClick={onClick}>
      <div className="ico" style={{ background: e.severity === 'high' ? 'var(--error-bg)' : e.severity === 'warn' ? 'var(--orange-bg)' : 'var(--bg-field)' }}><SevIcon s={e.severity} /></div>
      <div className="main">
        <div className="t1" style={{ whiteSpace: 'normal' }}>{eventLabel(e.kind)}</div>
        <div className="t2">{who}{dev ? ' · ' + dev.title : ''}{e.ip ? ' · ' + e.ip : ''}</div>
      </div>
      <span className="t-r12 c2" style={{ flex: 'none' }}>{ago(e.created_at)}</span>
    </button>
  );
}

export function AlertsScreen() {
  const { events, overview, reloadEvents, reload, loadMoreEvents, hasMoreEvents } = useData();
  const [filter, setFilter] = useState<Filter>('attacks');
  const [open, setOpen] = useState<SecEvent | null>(null);
  const list = useMemo(() => (events ?? []).filter((e) => filter === 'all' || (filter === 'important' ? e.severity !== 'info' : ATTACK_KINDS.has(e.kind))), [events, filter]);
  const groups = useMemo(() => {
    const g: { day: string; items: SecEvent[] }[] = [];
    for (const e of list) { const d = dayKey(e.created_at); if (g[g.length - 1]?.day !== d) g.push({ day: d, items: [] }); g[g.length - 1].items.push(e); }
    return g;
  }, [list]);
  const unseen = overview?.unseen ?? 0;

  const markAll = async () => { await api.markSeen(); await Promise.all([reloadEvents(), reload()]); };

  return (
    <Screen nav animate={false}>
      <div className="scroll" style={{ paddingTop: 12 }}>
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div className="h-big" style={{ flex: 1 }}>Opozorila</div>
          {unseen > 0 && <Button variant="secondary" size="s" icon={<CheckCheck size={16} />} onClick={markAll}>Prebrano</Button>}
        </div>
        {overview && (
          <div className={`card row statusbar ${overview.unseen_high ? 'bad' : unseen ? 'warn' : 'good'}`}>
            {overview.unseen_high ? <ShieldAlert size={22} /> : unseen ? <AlertTriangle size={22} /> : <ShieldCheck size={22} />}
            <span className="t-b15" style={{ flex: 1 }}>{overview.unseen_high ? `${overview.unseen_high} resnih opozoril čaka pregled` : unseen ? `${unseen} neprebranih opozoril` : 'Vse je v redu – ni neprebranih opozoril'}</span>
          </div>
        )}
        <div className="segment" style={{ marginTop: 14 }}>
          <Chip on={filter === 'attacks'} onClick={() => setFilter('attacks')}>Vdori</Chip>
          <Chip on={filter === 'important'} onClick={() => setFilter('important')}>Pomembno</Chip>
          <Chip on={filter === 'all'} onClick={() => setFilter('all')}>Vse</Chip>
        </div>
        {events && list.length === 0 && <Empty icon={<ShieldCheck size={30} />} title="Ni dogodkov" text="Tukaj se pokažejo poskusi vdora, nove naprave in druga varnostna opozorila." />}
        {groups.map((g) => (
          <div key={g.day}>
            <div className="label" style={{ marginTop: 18 }}>{g.day}</div>
            {g.items.map((e) => <EventRow key={e.id} e={e} onClick={() => setOpen(e)} />)}
          </div>
        ))}
        {hasMoreEvents && list.length > 0 && <Button variant="ghost" style={{ width: '100%', marginTop: 12 }} onClick={loadMoreEvents}>Naloži starejše</Button>}
      </div>
      <EventSheet e={open} onClose={() => setOpen(null)} />
    </Screen>
  );
}

export function EventSheet({ e, onClose }: { e: SecEvent | null; onClose: () => void }) {
  const { push, setTab, confirm, toast } = useNav();
  const { overview, reload, reloadEvents } = useData();
  const [reason, setReason] = useState('');
  const [askBlock, setAskBlock] = useState(false);
  if (!e) return null;
  const dev = eventDevice(e);
  const acc = overview?.accounts.find((a) => a.id === e.account_id);
  const knownDev = acc?.devices.find((d) => d.id === e.device_id);
  const hw = dev?.hw;
  const hwBlocked = !!(hw && (overview?.accounts.some((a) => a.devices.some((d) => d.hw_id === hw && d.hw_blocked)) || e.device_status === 'blocked'));
  const d = e.details ?? {};

  const after = async (msg: string) => { await api.markSeen([e.id]).catch(() => {}); await Promise.all([reload(), reloadEvents()]); toast(msg); onClose(); };
  const block = async () => {
    try {
      if (knownDev) await api.device(knownDev.id, 'block');
      else if (hw) await api.blockHw(hw, true, reason || eventLabel(e.kind));
      await after('Naprava prepovedana');
    } catch (err) { toast(errText(err)); }
    setAskBlock(false);
  };
  const disable = async () => {
    if (!acc) return;
    if (!(await confirm({ title: 'Onemogoči račun?', text: `${acc.name || acc.email}: vse naprave se zaklenejo, prijava ni več mogoča.`, okLabel: 'Onemogoči', danger: true, icon: <UserX size={22} /> }))) return;
    try { await api.setDisabled(acc.id, true, 'Varnostni razlog'); await after('Račun onemogočen'); } catch (err) { toast(errText(err)); }
  };

  return (
    <>
      <Sheet open={!askBlock} onClose={onClose} title={<span className="row" style={{ gap: 10 }}><SevIcon s={e.severity} size={22} />{eventLabel(e.kind)}</span>}
        footer={<Button variant="secondary" style={{ flex: 1 }} onClick={async () => { await api.markSeen([e.id]).catch(() => {}); reloadEvents(); reload(); onClose(); }}>Zapri</Button>}>
        <div className="kvlist">
          <div className="kv"><span className="k">Čas</span><span className="v">{fmtDateTime(e.created_at)}</span></div>
          <div className="kv"><span className="k">Račun</span><span className="v">{acc ? `${acc.name || '—'} · ${acc.email}` : e.email || '—'}</span></div>
          {dev && <div className="kv"><span className="k">Naprava</span><span className="v">{dev.title}{dev.os ? ` · ${dev.os}` : ''}</span></div>}
          {d.device?.app_version && <div className="kv"><span className="k">Aplikacija</span><span className="v">{d.device.app_version}</span></div>}
          {e.ip && <div className="kv"><span className="k">IP naslov</span><span className="v">{e.ip}</span></div>}
          {d.attempt && <div className="kv"><span className="k">Poskus</span><span className="v">{d.attempt}. napačno geslo</span></div>}
          {d.attempts && <div className="kv"><span className="k">Poskusov</span><span className="v">{d.attempts}</span></div>}
          {d.other_active_devices !== undefined && <div className="kv"><span className="k">Druge naprave</span><span className="v">{d.other_active_devices} aktivnih na tem računu</span></div>}
          {d.integrity && <div className="kv"><span className="k">Naprava</span><span className="v">{[d.integrity.rooted && 'root', d.integrity.emulator && 'emulator', d.integrity.debuggable && 'razhroščevanje'].filter(Boolean).join(', ') || '—'}</span></div>}
          {hw && <div className="kv"><span className="k">Strojni ID</span><span className="v mono">{hw}</span></div>}
          {e.user_agent && <div className="kv"><span className="k">Odjemalec</span><span className="v" style={{ fontSize: 12 }}>{e.user_agent}</span></div>}
        </div>
        {e.kind === 'new_device' && <div className="t-r13 c2" style={{ marginTop: 10, lineHeight: 1.45 }}>Nekdo se je s pravilnim geslom prijavil na novi napravi. Če to nisi dovolil, napravo prepovej in ponastavi geslo računa.</div>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
          {hw && !hwBlocked && <Button variant="danger" icon={<Ban size={18} />} onClick={() => { setReason(''); setAskBlock(true); }}>Prepovej to napravo</Button>}
          {hwBlocked && <div className="pill err" style={{ alignSelf: 'flex-start' }}><Ban size={14} />Naprava je prepovedana</div>}
          {acc && !acc.disabled && <Button variant="danger" icon={<UserX size={18} />} onClick={disable}>Onemogoči račun</Button>}
          {acc && <Button variant="secondary" icon={<ChevronRight size={18} />} onClick={() => { onClose(); setTab('racuni'); push({ name: 'account', id: acc.id }); }}>Odpri račun</Button>}
          {!acc && e.email && <div className="row t-r13 c2" style={{ gap: 6 }}><LogIn size={14} />Račun s to e-pošto ne obstaja.</div>}
        </div>
      </Sheet>
      <Sheet open={askBlock} onClose={() => setAskBlock(false)} title="Prepovej napravo?"
        footer={<><Button variant="secondary" style={{ flex: 1 }} onClick={() => setAskBlock(false)}>Prekliči</Button><Button variant="danger" style={{ flex: 1 }} icon={<Ban size={18} />} onClick={block}>Prepovej</Button></>}>
        <div className="t-r14 c2" style={{ lineHeight: 1.5 }}>Naprava <b style={{ color: 'var(--text)' }}>{dev?.title}</b> ne bo mogla več vstopiti v aplikacijo – z nobenim računom, tudi po ponovni namestitvi. Prepoved lahko kadarkoli prekličeš.</div>
        <Label>Razlog (neobvezno)</Label>
        <TextField value={reason} onChange={setReason} placeholder="npr. poskus vdora" />
      </Sheet>
    </>
  );
}
