import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { App as CapApp } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { Preferences } from '@capacitor/preferences';
import { ShieldAlert, Users, Megaphone, Settings as Cog, WifiOff, RefreshCw, X } from 'lucide-react';
import { NavProvider, useNav, routeHasNav, type Route, type TabId } from './ui/nav';
import { ConfirmHost, ToastHost, Button } from './ui/components';
import { supabase, configured } from './lib/supabase';
import { api } from './lib/api';
import { clearPin, hasPin } from './lib/pin';
import { backgroundAlertsOn, enableBackgroundAlerts, setupNotifications, stopBackgroundAlerts } from './lib/alerts';
import { isNative, tap } from './lib/native';
import { DataProvider, useData, liveText } from './data';
import { AdminLogin, MfaEnroll, MfaVerify, NotAdmin, PinSetup, PinLock } from './screens/Auth';
import { AlertsScreen } from './screens/Alerts';
import { AccountsScreen, AccountScreen, AccountFormScreen } from './screens/Accounts';
import { MessagesScreen, MessageScreen, MessageFormScreen } from './screens/Messages';
import { SettingsScreen, AppLockScreen } from './screens/Settings';

type Phase = 'boot' | 'offline' | 'login' | 'not-admin' | 'mfa-enroll' | 'mfa-verify' | 'pin-setup' | 'pin-lock' | 'pin-change' | 'app';

const TABS: { id: TabId; label: string; icon: ReactNode }[] = [
  { id: 'opozorila', label: 'Opozorila', icon: <ShieldAlert size={22} /> },
  { id: 'racuni', label: 'Računi', icon: <Users size={22} /> },
  { id: 'sporocila', label: 'Sporočila', icon: <Megaphone size={22} /> },
  { id: 'nastavitve', label: 'Nastavitve', icon: <Cog size={22} /> },
];

function renderRoute(r: Route) {
  switch (r.name) {
    case 'account': return <AccountScreen id={r.id} />;
    case 'accountForm': return <AccountFormScreen id={r.id} />;
    case 'message': return <MessageScreen id={r.id} />;
    case 'messageForm': return <MessageFormScreen id={r.id} />;
    case 'appLock': return <AppLockScreen />;
  }
}

function Shell({ onLogout, onLock, onChangePin }: { onLogout: () => void; onLock: () => void; onChangePin: () => void }) {
  const { tab, stacks, setTab, back } = useNav();
  const { overview, live, clearLive, error } = useData();

  useEffect(() => {
    if (!isNative) return;
    const h = CapApp.addListener('backButton', () => { if (!back()) CapApp.minimizeApp(); });
    return () => { h.then((x) => x.remove()); };
  }, [back]);

  useEffect(() => { if (!live) return; const t = setTimeout(clearLive, 6000); return () => clearTimeout(t); }, [live, clearLive]);

  const stack = stacks[tab];
  const top = stack[stack.length - 1];
  const showNav = !top || routeHasNav(top);
  const root = (t: TabId) => t === 'opozorila' ? <AlertsScreen /> : t === 'racuni' ? <AccountsScreen /> : t === 'sporocila' ? <MessagesScreen /> : <SettingsScreen onLogout={onLogout} onLock={onLock} onChangePin={onChangePin} />;

  return (
    <div className="app">
      {TABS.map((t) => (
        <div key={t.id} style={{ display: t.id === tab ? 'contents' : 'none' }}>
          <div style={{ display: stacks[t.id].length ? 'none' : 'contents' }}>{root(t.id)}</div>
          {stacks[t.id].map((r, i) => <div key={i + r.name} style={{ display: i === stacks[t.id].length - 1 ? 'contents' : 'none' }}>{renderRoute(r)}</div>)}
        </div>
      ))}
      {live && (
        <div className={`live-alert ${live.severity}`} role="alert" onClick={() => { clearLive(); setTab('opozorila'); }}>
          <ShieldAlert size={22} />
          <span style={{ flex: 1 }}>{liveText(live)}</span>
          <button className="iconbtn" aria-label="Zapri" onClick={(e) => { e.stopPropagation(); clearLive(); }}><X size={18} /></button>
        </div>
      )}
      {error && <div className="netbar"><WifiOff size={16} />{error}</div>}
      {showNav && (
        <nav className="bottomnav">
          {TABS.map((t) => (
            <button key={t.id} className={`navitem ${tab === t.id ? 'active' : ''}`} onClick={() => { tap(); setTab(t.id); }}>
              <span className="pill">{t.icon}{t.id === 'opozorila' && !!overview?.unseen && <span className={`navbadge ${overview.unseen_high ? 'high' : ''}`}>{overview.unseen > 99 ? '99+' : overview.unseen}</span>}</span>
              {t.label}
            </button>
          ))}
        </nav>
      )}
      <ToastHost bottom={showNav ? 116 : 96} />
      <ConfirmHost />
    </div>
  );
}

const LOCK_AFTER = 30_000;

export default function App() {
  const [phase, setPhase] = useState<Phase>('boot');
  const pausedAt = useRef(0);
  const phaseRef = useRef(phase);
  phaseRef.current = phase;

  /** določi naslednji korak varne prijave: geslo -> admin? -> 2FA -> PIN */
  const resolve = useCallback(async (afterPin = false) => {
    if (!configured) return setPhase('offline');
    const { data } = await supabase.auth.getSession();
    if (!data.session) return setPhase('login');
    let who;
    try { who = await api.whoami(); } catch { return setPhase('offline'); }
    if (!who.admin) return setPhase('not-admin');
    await Preferences.set({ key: 'setupDone', value: '1' });
    const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
    if (aal?.currentLevel !== 'aal2') {
      const { data: f } = await supabase.auth.mfa.listFactors();
      return setPhase(f?.totp?.length ? 'mfa-verify' : 'mfa-enroll');
    }
    if (!(await hasPin())) return setPhase('pin-setup');
    setPhase(afterPin ? 'app' : 'pin-lock');
  }, []);

  useEffect(() => {
    resolve().finally(() => { if (isNative) SplashScreen.hide().catch(() => {}); });
    const { data: sub } = supabase.auth.onAuthStateChange((ev) => { if (ev === 'SIGNED_OUT') setPhase('login'); });
    if (!isNative) return () => sub.subscription.unsubscribe();
    const p = CapApp.addListener('pause', () => { pausedAt.current = Date.now(); });
    const r = CapApp.addListener('resume', () => {
      if (phaseRef.current === 'app' && Date.now() - pausedAt.current > LOCK_AFTER) setPhase('pin-lock');
    });
    return () => { sub.subscription.unsubscribe(); p.then((x) => x.remove()); r.then((x) => x.remove()); };
  }, [resolve]);

  const logout = useCallback(async () => {
    await stopBackgroundAlerts().catch(() => {});
    await supabase.auth.signOut().catch(() => {});
    await clearPin();
    setPhase('login');
  }, []);

  const unlocked = useCallback(async () => {
    setPhase('app');
    if (await backgroundAlertsOn()) { await setupNotifications(); enableBackgroundAlerts(true).catch(() => {}); }
  }, []);

  const wrap = (n: ReactNode) => <div className="app">{n}</div>;
  switch (phase) {
    case 'boot': return <div className="app" />;
    case 'offline':
      return wrap(
        <div className="screen"><div className="scroll" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', paddingTop: 120 }}>
          <WifiOff size={40} color="var(--text-2)" />
          <div className="t-dialog" style={{ marginTop: 16 }}>{configured ? 'Ni povezave s strežnikom' : 'Strežnik ni nastavljen'}</div>
          <div className="t-r14 c2" style={{ marginTop: 8 }}>Admin aplikacija potrebuje internet.</div>
          <Button style={{ marginTop: 24 }} icon={<RefreshCw size={18} />} onClick={() => resolve()}>Poskusi znova</Button>
        </div></div>,
      );
    case 'login': return wrap(<AdminLogin onDone={() => resolve(true)} />);
    case 'not-admin': return wrap(<NotAdmin onLogout={logout} />);
    case 'mfa-enroll': return wrap(<MfaEnroll onDone={() => resolve(true)} onCancel={logout} />);
    case 'mfa-verify': return wrap(<MfaVerify onDone={() => resolve(true)} onCancel={logout} />);
    case 'pin-setup': return wrap(<PinSetup onDone={unlocked} />);
    case 'pin-change': return wrap(<PinSetup onDone={() => setPhase('app')} />);
    case 'pin-lock': return wrap(<PinLock onUnlock={unlocked} onWipe={logout} />);
  }
  return (
    <NavProvider initialTab="opozorila">
      <DataProvider onForbidden={() => resolve(true)}>
        <Shell onLogout={logout} onLock={() => setPhase('pin-lock')} onChangePin={() => setPhase('pin-change')} />
      </DataProvider>
    </NavProvider>
  );
}
