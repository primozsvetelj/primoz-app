import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { api, type Overview, type SecEvent, type Message } from './lib/api';
import { subscribeEvents, notify, markBackgroundSeen } from './lib/alerts';
import { eventLabel } from './lib/labels';

interface DataCtx {
  overview: Overview | null;
  events: SecEvent[] | null;
  messages: Message[] | null;
  hasMoreEvents: boolean;
  error: string;
  reload: () => Promise<void>;
  reloadEvents: () => Promise<void>;
  reloadMessages: () => Promise<void>;
  loadMoreEvents: () => Promise<void>;
  live: SecEvent | null;
  clearLive: () => void;
}

const Ctx = createContext<DataCtx>(null as unknown as DataCtx);
export const useData = () => useContext(Ctx);

const PAGE = 100;

export function DataProvider({ children, onForbidden }: { children: ReactNode; onForbidden: () => void }) {
  const [overview, setOverview] = useState<Overview | null>(null);
  const [events, setEvents] = useState<SecEvent[] | null>(null);
  const [messages, setMessages] = useState<Message[] | null>(null);
  const [hasMoreEvents, setHasMore] = useState(false);
  const [error, setError] = useState('');
  const [live, setLive] = useState<SecEvent | null>(null);
  const timer = useRef(0);

  const guard = useCallback(async <T,>(p: Promise<T>): Promise<T | null> => {
    try { const r = await p; setError(''); return r; } catch (e) {
      const code = (e as { code?: string }).code;
      if (code === 'forbidden') onForbidden();
      setError(code === 'network' ? 'Ni povezave s strežnikom.' : 'Napaka pri nalaganju.');
      return null;
    }
  }, [onForbidden]);

  const reload = useCallback(async () => { const o = await guard(api.overview()); if (o) setOverview(o); }, [guard]);
  const reloadEvents = useCallback(async () => {
    const e = await guard(api.events(PAGE));
    if (e) { setEvents(e); setHasMore(e.length === PAGE); if (e[0]) markBackgroundSeen(e[0].id); }
  }, [guard]);
  const reloadMessages = useCallback(async () => { const m = await guard(api.messages()); if (m) setMessages(m); }, [guard]);
  const loadMoreEvents = useCallback(async () => {
    const last = events?.[events.length - 1];
    if (!last) return;
    const e = await guard(api.events(PAGE, last.id));
    if (e) { setEvents((cur) => [...(cur ?? []), ...e]); setHasMore(e.length === PAGE); }
  }, [events, guard]);

  useEffect(() => {
    reload(); reloadEvents(); reloadMessages();
    const unsub = subscribeEvents((ev) => {
      if (ev.severity && ev.severity !== 'info') {
        const who = ev.email || '';
        notify(ev, who);
        setLive({ ...(ev as SecEvent), account_name: null, device_name: null, device_status: null });
      }
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => { reload(); reloadEvents(); }, 600);
    });
    const poll = window.setInterval(() => { reload(); reloadEvents(); }, 60_000);
    return () => { unsub(); clearInterval(poll); };
  }, [reload, reloadEvents, reloadMessages]);

  return (
    <Ctx.Provider value={{ overview, events, messages, hasMoreEvents, error, reload, reloadEvents, reloadMessages, loadMoreEvents, live, clearLive: () => setLive(null) }}>
      {children}
    </Ctx.Provider>
  );
}

export const liveText = (e: SecEvent) => `${eventLabel(e.kind)}${e.email ? ' – ' + e.email : ''}`;
